import {Injectable, Injector} from '@angular/core';

import {take, tap, takeUntil} from 'rxjs/operators';
import {BehaviorSubject, Observable} from 'rxjs';

import * as _ from 'lodash';

import {
    EnterpriseSearchDataToElasticModelDto,
    EnterpriseSearchItemsInputDto,
    EnterpriseSearchMetadataDto,
    EnterpriseSearchServiceProxy,
    IEnterpriseSearchDataToElasticModelDto,
    IEnterpriseSearchItemsInputDto,
    PreviewItemOutputDto,
    SearchResultDto,
    TimelineDto
} from '@shared/service-proxies/service-proxies';

@Injectable({
    providedIn: 'root'
})
export class EsDataViewService {

    private _layoutMode$: BehaviorSubject<'list' | 'grid'>;

    private _searchResult$: BehaviorSubject<SearchResultDto>;

    // private _searchData$: BehaviorSubject<EnterpriseSearchDataToElasticModelDto[]>;
    // private _selectedDataItem$: BehaviorSubject<EnterpriseSearchDataToElasticModelDto>;

    protected enterpriseSearchServiceProxy: EnterpriseSearchServiceProxy;

    constructor(injector: Injector) {
        this.enterpriseSearchServiceProxy = injector.get(EnterpriseSearchServiceProxy);

        this._layoutMode$ = new BehaviorSubject<'list' | 'grid'>('list');

        this._searchResult$ = new BehaviorSubject<SearchResultDto>(undefined);

        // this._searchData$ = new BehaviorSubject<EnterpriseSearchDataToElasticModelDto[]>(undefined);
        // this._selectedDataItem$ = new BehaviorSubject<EnterpriseSearchDataToElasticModelDto>(undefined);
    }

    //#region LayoutMode
    get layoutMode$(): Observable<'list' | 'grid'> {
        return this._layoutMode$.asObservable();
    }
    get layoutMode(): 'list' | 'grid' {
        return this._layoutMode$.getValue();
    }
    private setLayoutMode(mode: 'list' | 'grid') {
        this._layoutMode$.next(mode);
    }
    setGridMode() {
        this.setLayoutMode('grid');
    }
    setListMode() {
        this.setLayoutMode('list');
    }
    //#endregion

    //
    // //#region Search Result
    // private setSearchResult(result: SearchResultDto) {
    //     this._searchResult$.next(result);
    //
    //     if (!this.isHistoryModeSearch) {
    //         //update metadata
    //         this.setMetadata(result.metadata);
    //     }
    //
    //     //update searchData
    //     this.setSearchData(result.data);
    //     //update totalFound
    //     this.setTotalRecordsCount(result.totalFound);
    //     //update timeLine
    //     this.setTimeLine(result.timeLine);
    // }
    //
    // //#region SearchData
    // private setSearchData(result: EnterpriseSearchDataToElasticModelDto[]) {
    //     if (this.imagePreview) {
    //         this.initDummyPictures(result);
    //     }
    //     this._searchData$.next(result);
    // }
    //
    // get searchData$(): Observable<EnterpriseSearchDataToElasticModelDto[]> {
    //     return this._searchData$.asObservable();
    // }
    // get searchData(): EnterpriseSearchDataToElasticModelDto[] {
    //     return this._searchData$.getValue();
    // }
    // //#endregion SearchData
    //
    // //#region SelectedDataItem
    // setSelectedDataItem(result: EnterpriseSearchDataToElasticModelDto) {
    //     this._selectedDataItem$.next(result);
    //     this.preparePreviewItem(result);
    // }
    //
    // private preparePreviewItem(result: EnterpriseSearchDataToElasticModelDto) {
    //     if (result) {
    //         //get preview item
    //         this.getPreviewItem(result);
    //         this.showPreviewLoader();
    //         this._isShowPreviewItem$.next(true);
    //     } else {
    //         this._isShowPreviewItem$.next(false);
    //     }
    // }
    //
    // get selectedDataItem$(): Observable<EnterpriseSearchDataToElasticModelDto> {
    //     return this._selectedDataItem$.asObservable();
    // }
    // get selectedDataItem(): EnterpriseSearchDataToElasticModelDto {
    //     return this._selectedDataItem$.getValue();
    // }
    // resetSelectedDataItem() {
    //     this._selectedDataItem$.next(undefined);
    // }
    // //#endregion SelectedDataItem
    //
    // //#region TotalRecordsCount
    // private setTotalRecordsCount(result: number) {
    //     this._totalRecordsCount$.next(result);
    // }
    //
    // get totalRecordsCount$(): Observable<number> {
    //     return this._totalRecordsCount$.asObservable();
    // }
    // get totalRecordsCount(): number {
    //     return this._totalRecordsCount$.getValue();
    // }
    // //#endregion TotalRecordsCount
    //
    // onSearchData$(input: IEnterpriseSearchItemsInputDto): Observable<SearchResultDto>  {
    //     if (this.isHistoryModeSearch && this.selectedMetadata.searchTerm !== input.content) {
    //         this.resetCurrentMetadata();
    //     }
    //
    //     return this.enterpriseSearchServiceProxy
    //         .searchData(new EnterpriseSearchItemsInputDto(input))
    //         .pipe(
    //             tap((result: SearchResultDto) => {
    //                 this.setSearchResult(result);
    //             })
    //         );
    // }
    // //#endregion Search

}


