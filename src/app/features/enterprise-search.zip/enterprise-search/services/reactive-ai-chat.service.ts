import {Injectable} from '@angular/core';
import {
    BehaviorSubject,
    combineLatest,
    distinctUntilChanged, forkJoin,
    from,
    merge,
    mergeMap,
    Observable,
    of,
    scan,
    share,
    Subject,
    withLatestFrom,
    startWith, concat
} from 'rxjs';

import * as _ from 'lodash';

import {
    AIChatMessageDto, AIChatMessageReadyDto,
    AIChatMessageType, AIChatMetricDto,
    AIChatServiceProxy,
    AIPersonDescriptionDto,
    ChatMessageReadState,
    ChatSide,
    FileToAiDto,
    UploadFilesToChatInputDto
} from '@shared/service-proxies/service-proxies';
import {
    AIChatEvents,
    AIChatMessage,
    AIChatPendingEvents,
    AIChatSession,
    AllAIChatEvents,
    ExtendedAIChatMessageDto,
    TypingIndicator
} from '@app/enterprise-search/shared/models';
import dayjs from 'dayjs';
import {InstructionInterceptor} from '@app/enterprise-search/shared/helpers/instruction-interceptor';
import {catchError, debounceTime, filter, ignoreElements, map, shareReplay, switchMap, take, tap} from 'rxjs/operators';
import {EsHistoryService} from '@app/enterprise-search/services/es-history.service';
import {MessageId, SessionId} from '@app/enterprise-search/shared/types';
import {CurrentMessageManager} from '@app/enterprise-search/services/messages/current-message.manager';
import {filterByType} from '@app/enterprise-search/shared/rxjs/filter/filterByType';
import {filterByCurrentMessageId} from '@app/enterprise-search/shared/rxjs/filter/filterByCurrentMessageId';
import {filterOutByType} from '@app/enterprise-search/shared/rxjs/filter/filterOutByType';
import {filterByChatEvent} from '@app/enterprise-search/shared/rxjs/filter/filterByChatEvent';
import {handleStartedEventSilently} from '@app/enterprise-search/shared/rxjs/events/handleStartedEventSilently';
import {filterByAgentPresence} from '@app/enterprise-search/shared/rxjs/filter/filterByAgentPresence';
import {
    filterWhenCurrentMessageIdNotSet
} from '@app/enterprise-search/shared/rxjs/filter/filterWhenCurrentMessageIdNotSet';
import {filterOutByChatEvent} from '@app/enterprise-search/shared/rxjs/filter/filterOutByChatEvent';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';
import {convertMessage, extractName} from '@app/enterprise-search/shared/helpers/helpers';
import {AiSessionsService} from '@app/enterprise-search/services/ai-sessions.service';
import {ChatMessagesStore} from '@app/enterprise-search/shared/store/ai-message.store';

@Injectable({
    providedIn: 'root'
})
export class ReactiveAIChatService {

    private readonly _reset$ = new Subject<void>();

    private readonly _aiAssistant$: BehaviorSubject<AIPersonDescriptionDto[]> = new BehaviorSubject<AIPersonDescriptionDto[]>([]);

    private readonly _aiIsPendingSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    private readonly _aiIsPending$ = this._aiIsPendingSubject.asObservable();

    private readonly _aiIsTyping$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    private readonly _connectedAIName$: BehaviorSubject<string | undefined> = new BehaviorSubject<string | undefined>(undefined);

    private readonly lastMessageId$!: Observable<MessageId | undefined>;
    private readonly currentMessageId$!: Observable<MessageId | undefined>;
    private readonly currentSharedMessageId$!: Observable<MessageId | undefined>;
    currentAIAssistant$!: Observable<AIPersonDescriptionDto | undefined>;

    //#region Agents
    private readonly _currentAgentSubject   = new BehaviorSubject<AIPersonDescriptionDto | undefined>(undefined);
    private readonly _lastAgentSubject      = new BehaviorSubject<AIPersonDescriptionDto | undefined>(undefined);

    // keep an ID for routing (/app/ai/:agentId)
    private readonly _currentAgentIdSubject = new BehaviorSubject<string | undefined>(undefined);
    readonly _currentAgentId$ = this._currentAgentIdSubject.asObservable();

    private readonly _lastAgentIdSubject    = new BehaviorSubject<string | undefined>(undefined);
    readonly _lastAgentId$ = this._lastAgentIdSubject.asObservable();

    get currentAgent(): AIPersonDescriptionDto | undefined { return this._currentAgentSubject.getValue(); }
    get lastAgent(): AIPersonDescriptionDto | undefined    { return this._lastAgentSubject.getValue(); }
    get currentAgentId(): string | undefined               { return this._currentAgentIdSubject.getValue(); }
    get lastAgentId(): string | undefined                  { return this._lastAgentIdSubject.getValue(); }
    //#endregion Agents

    //#region QUEUED messages
    private readonly _queuedMessagesArraySubject = new BehaviorSubject<ExtendedAIChatMessageDto[]>([]);
    private readonly _queuedMessages$ = this._queuedMessagesArraySubject.asObservable();

    constructor(
        private aiChatServiceProxy: AIChatServiceProxy
        , private currentMessageManager: CurrentMessageManager
        , private aiSessionsService: AiSessionsService
        , private aiAgentsService: AiAgentsService
        , private esHistoryService: EsHistoryService
        , public messageStore: ChatMessagesStore) {

        this.currentMessageId$ = this.currentMessageManager?.currentMessageId$ ?? of(undefined);
        this.lastMessageId$ = this.currentMessageManager?.lastMessageId$ ?? of(undefined);
        this.currentSharedMessageId$ = this.currentMessageManager?.currentSharedMessageId$ ?? of(undefined);
        this.currentAIAssistant$ = this.currentMessageManager?.currentAIAssistant$ ?? of(undefined);

        //#region Helpers
        const pendingCheckerSilenced$ = this._incomingMessages$.pipe(
            filterOutByType(AIChatMessageType.User)
            , withLatestFrom(this.currentMessageId$, this._aiIsPending$)
            , filter(([m, currentId, aiIsPending]) => m.id === currentId && aiIsPending)
            , tap(([m, currentId, aiIsPending]) => {
                this._aiIsPendingSubject.next(false);
                this.hideIndicatorByName(m);
            }),
            ignoreElements()
        );

        const currentMessageIdCheckerSilenced$ = this._incomingMessages$.pipe(
            filterByType(AIChatMessageType.AI)
            , withLatestFrom(this.currentMessageId$)
            , filter(([m, currentId]) => !currentId)
            , tap(([m, currentId]) => {
                this.currentMessageManager.setCurrentMessageIdIfNotSet(m.id);
                this.currentMessageManager.setCurrentSharedMessageIdIfNotSet(m.sharedMessageId);

                this.setCurrentAIAssistant(m.sender);
            }),
            ignoreElements()
        );

        const loaderCheckerSilenced$ = this._incomingMessages$.pipe(
            filterOutByType(AIChatMessageType.User)
            , withLatestFrom(this.loading$)
            , filter(([_, isLoading]) => isLoading)
            , tap(([_, isLoading]) => {
                this.hideLoader();
            }),
            ignoreElements()
        );

        const helpers$ = merge(
            pendingCheckerSilenced$
            , currentMessageIdCheckerSilenced$
            , loaderCheckerSilenced$
        );

        //#endregion Helpers

        //#region Immediate

        const immediateMessageUser$ = this._incomingMessages$.pipe(
            filterByType(AIChatMessageType.User),
            tap(msg => {
                this.showLoader();
                this.currentMessageManager.setCurrentSharedMessageIdIfNotSet(msg.sharedMessageId);
            })
        );

        const immediateIncomingMessages$ = this._incomingMessages$.pipe(
            filterOutByType(AIChatMessageType.Events)
            , withLatestFrom(this.currentMessageId$, this._queuedMessages$)
            , filter(([m, currentId, queued]) => m.id === currentId && !queued.some(item => item.id === m.id && item.id === currentId)) // not the current thread
            //
            // , tap(([m, _]) => this._showMessageLogsSubject.next(m))
            , map(([m, _]) => m)
        );

        //#region Immediate System messages
        const immediateIncomingSystemMessages$ = this._incomingMessages$.pipe(
            filterByType(AIChatMessageType.System)
            , filterWhenCurrentMessageIdNotSet(() => this.currentMessageId)
            , tap(_ => {
                this.hideLoader();
            })
            //, tap(messageDto => this._showMessageLogsSubject.next(messageDto))
        );

        const immediateAIOfflineMessages$ = immediateIncomingSystemMessages$.pipe(
            filter(msg => msg.message.includes(' offline'))
            , tap(msg => {
                this.hideLoader();
                this.hideIndicatorByMessage(msg);
            })
            , map(msg => this.showOffline(msg))
            //, tap(messageDto => this._showMessageLogsSubject.next(messageDto))
        );
        //#endregion Immediate System messages

        //#region Immediate Events
        const SILENCED_EVENTS: AllAIChatEvents[] = [
            AIChatEvents.Pending,
            AIChatPendingEvents.SearchingIntent,
            AIChatPendingEvents.PreparingResult,
            AIChatPendingEvents.SearchingFunction,
            AIChatEvents.JoinedAI,
            AIChatEvents.AddAI,
        ];

        const immediateSystemJoinedAIMessage$ = this._messageEventJoinedAI$.pipe(
            tap(msg => {
                this.currentMessageManager.setCurrentSharedMessageIdIfNotSet(msg.sharedMessageId);

                // //reordering list of ai agents in chat
                // const aiName = this._getAgentNameFromEvent(msg.message);
                // this.aiAgentsService.reorderByName(aiName);
            })
            , filterByAgentPresence(this.aiAgentsService, m => this._getAgentNameFromEvent(m.message), false)
            , map(msg =>  {
                msg.displayMessage = InstructionInterceptor.transformMessageText(msg.displayMessage);
                return msg;
            })
        );

        const immediateStartEvent$ = this._messageEventStarted$.pipe(
            //, filterOutByCurrentMessageId(() => this.currentMessageId)
            // tap(m => {
            //     console.log(
            //         '%c\'THIS IS SILENT START EVENT %c' + m.message + ' %c' + m.sender.name  + ' %c' + m.id + ' ' + m.sharedMessageId,
            //         'color: aqua;',      // System Input
            //         'color: aqua;',     // Sender name
            //         'color: aqua;',       // Rest of the message
            //         'color: aqua;'       // Rest of the message
            //     );
            // }),
            handleStartedEventSilently(
                () => this.hideLoader(),
                () => this.currentMessageManager.isCurrentMessageIdNotSet(),
                m => this._changeCurrentAIAssistant(m)
            )
        );

        // Live “not required” events (don’t show; do effects)
        const allLiveSilentEvents$ = this._incomingMessages$.pipe(
            filterByType(AIChatMessageType.Events),
            filterByChatEvent(...SILENCED_EVENTS),
            //tap(m => this._showMessageLogsSubject.next(m)),
        );

        const searchResultSilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatEvents.SearchResult),
            tap((m: ExtendedAIChatMessageDto) => {
                this.hideIndicatorByName(m);
            }),
            ignoreElements()
        );
        const addAISilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatEvents.AddAI),
            tap((m: ExtendedAIChatMessageDto) => {
                //TODO: do smth
            }),
            ignoreElements()
        );
        const joinedAISilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatEvents.JoinedAI),
            tap((m: ExtendedAIChatMessageDto) => {
                this.showIndicator(m, AIChatEvents.JoinedAI);

                const agentName = this._getAgentNameFromEvent(m.message);
                this.aiAgentsService.addAIAgentByName(agentName);
            }),
            ignoreElements()
        );
        const pendingSilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatEvents.Pending),
            tap((m: ExtendedAIChatMessageDto) => {
                this.showIndicator(m, AIChatEvents.Pending);
                this._aiIsPendingSubject.next(true);
            }),
            ignoreElements()
        );
        const pendingSearchingIntentSilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatPendingEvents.SearchingIntent),
            tap((m: ExtendedAIChatMessageDto) => {
                this.showIndicator(m, AIChatPendingEvents.SearchingIntent);
                this._aiIsPendingSubject.next(true);
            }),
            ignoreElements()
        );
        const pendingSearchingFunctionSilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatPendingEvents.SearchingFunction),
            tap((m: ExtendedAIChatMessageDto) => {
                this.showIndicator(m, AIChatPendingEvents.SearchingFunction);
                this._aiIsPendingSubject.next(true);
            }),
            ignoreElements()
        );
        const pendingPreparingResultSilentEvents$ = allLiveSilentEvents$.pipe(
            filterByChatEvent(AIChatPendingEvents.PreparingResult),
            tap((m: ExtendedAIChatMessageDto) => {
                this.showIndicator(m, AIChatPendingEvents.PreparingResult);
                this._aiIsPendingSubject.next(true);
            }),
            ignoreElements()
        );

        const immediateSearchEvent$ = this._incomingMessages$.pipe(
            filterByType(AIChatMessageType.Events)
            , filterByCurrentMessageId(() => this.currentMessageId)
            , filterByChatEvent(AIChatEvents.SearchResult)
            , map(msg => this.showResult(msg))
            //, tap(msg => this._showMessageLogsSubject.next(msg))
        );

        const liveSilentFinishEvent$ = this._messageEventFinished$.pipe(
            withLatestFrom(this.currentMessageId$)
            , filter(([msg, currentId]) => msg.id === currentId)
            , map(([msg, _]) => msg),
            //tap(m => this._showMessageLogsSubject.next(m)),
            tap((m: ExtendedAIChatMessageDto) => {
                this.currentMessageManager.resetCurrentMessageIdIfSet();
                this.currentMessageManager.resetCurrentSharedMessageId();
                this.hideIndicatorByName(m);
            }),
            share()
        );

        const liveSilentEvents$ = merge(
            immediateStartEvent$
            , immediateSystemJoinedAIMessage$
            , joinedAISilentEvents$
            , addAISilentEvents$
            , searchResultSilentEvents$
            , pendingSilentEvents$
            , pendingSearchingIntentSilentEvents$
            , pendingPreparingResultSilentEvents$
            , pendingSearchingFunctionSilentEvents$
            , immediateSearchEvent$
            , liveSilentFinishEvent$            // side-effects only
        );
        //#endregion Immediate Events

        const immediate$ = merge(
            //this._initialMessages$
            immediateMessageUser$
            , immediateIncomingMessages$
            , immediateIncomingSystemMessages$
            , immediateAIOfflineMessages$
            , liveSilentEvents$
        ).pipe(
            filterOutByChatEvent(AIChatEvents.Finished)
        );

        //#endregion immediate

        //#region Queued
        // 1) Enqueue non-current messages (side-effect only)
        const enqueueToQueue$ = this._incomingMessages$.pipe(
            filterOutByType(AIChatMessageType.User)
            , filterOutByChatEvent(AIChatEvents.JoinedAI)
            , withLatestFrom(this.currentMessageId$, this.lastMessageId$)
            , filter(([msg, currentId, _]) => msg.id !== currentId)
            , filter(([m, currentId, lastId]) => {
                const id = m.id;
                const isFinished = (m.message ?? '').includes(AIChatEvents.Finished);
                return !(id !== currentId && id === lastId && isFinished);
            })
            , map(([msg, _]) => ({ ...msg, fromQueue: true } as ExtendedAIChatMessageDto)),
            distinctUntilChanged((a, b) =>
                a.id === b.id && a.type === b.type && a.displayMessage === b.displayMessage && a.creationTime === b.creationTime
            ),
            tap((m: ExtendedAIChatMessageDto) => {
                // console.log(
                //     '%c\'QUEUED MESSAGE %c' + m.message + ' %c' + m.sender.name  + ' %c' + m.id + ' ' + m.sharedMessageId,
                //     'color: red;',      // System Input
                //     'color: red;',     // Sender name
                //     'color: red;',       // Rest of the message
                //     'color: red;'       // Rest of the message
                // );

                if (m.type === AIChatMessageType.Events && this.isSearchResultEvent(m)) {
                    m = this.convertShowResult(m);
                    this._queuedMessagesArraySubject.next([...this._queuedMessagesArraySubject.value, m]);
                } else {
                    this._queuedMessagesArraySubject.next([...this._queuedMessagesArraySubject.value, m]);
                }
            }),
            ignoreElements() // <- side-effects only
        );

        const REQUIRED_EVENTS: AllAIChatEvents[] = [
            AIChatEvents.Started,
            AIChatEvents.Finished,
            AIChatEvents.SearchResult
        ];

        const includesAny = (msg: string | undefined, events: AllAIChatEvents[]) =>
            !!msg && events.some(ev => msg.includes(ev));

        const queuedProjection$ = this._queuedMessages$.pipe(
            map(list => {
                const visibleById = new Map<MessageId, ExtendedAIChatMessageDto[]>();
                const silentEvents: ExtendedAIChatMessageDto[] = [];

                for (const m of list) {
                    const isEvent = m.type === AIChatMessageType.Events;
                    const isNotRequired = isEvent && includesAny(m.message, SILENCED_EVENTS);
                    const isRequired = isEvent && includesAny(m.message, REQUIRED_EVENTS);
                    if (isNotRequired) { silentEvents.push(m); continue; }

                    const arr = visibleById.get(m.id) ?? [];
                    arr.push(m);
                    visibleById.set(m.id, arr);
                }
                return { visibleById, silentEvents };
            }),
            shareReplay({ bufferSize: 1, refCount: true })
        );

        const queuedById$: Observable<Map<MessageId, ExtendedAIChatMessageDto[]>> =
            queuedProjection$.pipe(map(x => x.visibleById));

        const queuedSilentEvents$: Observable<ExtendedAIChatMessageDto[]> =
            queuedProjection$.pipe(map(x => x.silentEvents));

        // Queued “not required” events (don’t show; do effects)
        const queuedSilentEventsSideEffects$ = queuedSilentEvents$.pipe(
            mergeMap(list => from(list))
            , withLatestFrom(this.currentMessageId$)
            , filter(([msg, currentId]) => msg.id === currentId)
            , map(([msg, _]) => msg),
            tap((m: ExtendedAIChatMessageDto) => {
                if ((m.message ?? '').includes(AIChatEvents.Pending)) {
                    this.showIndicator(m, AIChatEvents.Pending);
                }
                if ((m.message ?? '').includes(AIChatEvents.JoinedAI)) {
                    this.showIndicator(m, AIChatEvents.JoinedAI);
                }
                if ((m.message ?? '').includes(AIChatEvents.AddAI)) {
                    //this.onAddAI?.(m);
                }
                if ((m.message ?? '').includes(AIChatEvents.Started)) {
                    this.currentMessageManager.setCurrentSharedMessageIdIfNotSet(m.id);
                }
                if ((m.message ?? '').includes(AIChatEvents.Finished)) {
                    this.currentMessageManager.resetCurrentMessageIdIfSet();
                    this.currentMessageManager.resetCurrentSharedMessageId();
                    this.hideIndicatorByName(m);
                }
                if ((m.message ?? '').includes(AIChatEvents.SearchResult)) {
                    this.hideIndicatorByName(m);
                }
            }),
            ignoreElements()
        );

        // Finished for the current thread → drain that id
        const finishedIds$ = liveSilentFinishEvent$.pipe(
            map(m => m.id),
            share()
        );

        // Queued “not required” events (don’t show; do effects)

        const promoteNextQueuedOnFinished$ = finishedIds$.pipe(
            withLatestFrom(queuedById$, this._queuedMessages$),
            map(([_, byId, all]) => {
                const iter = byId.keys();
                const nextId: MessageId | undefined = iter.next().value;
                const toFlush = nextId ? (byId.get(nextId) ?? []) : [];
                return { nextId, toFlush, all };
            }),
            tap(({ nextId, toFlush, all }) => {
                if (nextId && toFlush.length > 0) {
                    // remove promoted id from queue
                    this._queuedMessagesArraySubject.next(all.filter(m => m.id !== nextId));
                    // promote to current so future chunks show immediately
                    this.currentMessageManager.initCurrentMessageId(nextId);
                }
            }),
            mergeMap(({ toFlush }) => from(toFlush))
            // , tap((m) => console.log('From Queue', m.id, m.sender?.name ?? 'system', m.message))
            , share()
        );
        const fromQueueSilentEventsSideEffects$ = promoteNextQueuedOnFinished$.pipe(
            filterByType(AIChatMessageType.Events)
            , tap((m: ExtendedAIChatMessageDto) => {
                if ((m.message ?? '').includes(AIChatEvents.Started)) {
                    this.currentMessageManager.setCurrentSharedMessageIdIfNotSet(m.id);
                }
                if ((m.message ?? '').includes(AIChatEvents.Finished)) {
                    this.currentMessageManager.resetCurrentMessageIdIfSet();
                    this.currentMessageManager.resetCurrentSharedMessageId();
                    this.hideIndicatorByName(m);
                }
                if ((m.message ?? '').includes(AIChatEvents.SearchResult)) {
                    this.hideIndicatorByName(m);
                }
            }),
            ignoreElements()
        );

        const fromQueueSearchEvent$ = promoteNextQueuedOnFinished$.pipe(
            filterByType(AIChatMessageType.Events)
            , filterByChatEvent(AIChatEvents.SearchResult)
            , withLatestFrom(this.currentMessageId$)
            , filter(([m, currentId]) => !!currentId)
            , map(([msg, currentId]) => this.showResult(msg))
            //, tap(msg => this._showMessageLogsSubject.next(msg))
        );

        const fromQueueInitializationSideEffects$ = promoteNextQueuedOnFinished$.pipe(
            filterByType(AIChatMessageType.AI)
            , tap((m: ExtendedAIChatMessageDto) => {
                this.currentMessageManager.setCurrentMessageIdIfNotSet(m.id);
                this.currentMessageManager.setCurrentSharedMessageIdIfNotSet(m.sharedMessageId);

                this.setCurrentAIAssistant(m.sender);
            }),
            ignoreElements()
        );

        const queued$ = merge(
            promoteNextQueuedOnFinished$          // visible: queued thread + SearchResult
            , fromQueueSearchEvent$               // side-effects only
            , enqueueToQueue$                     // side-effects only
            , queuedSilentEventsSideEffects$      // side-effects only
            , fromQueueSilentEventsSideEffects$   // side-effects only
            , fromQueueInitializationSideEffects$ // side-effects only
        );
        //#endregion Queued

        //#region Ui messages

        const messages$ = merge(
            helpers$
            , immediate$
            , queued$
        ).pipe(
            share()
        );

        // this.groupedMessages$ = messages$
        //     .pipe(
        //         filterOutByChatEvent(AIChatEvents.Started, AIChatEvents.Finished),
        //         distinctUntilChanged((a, b) => a.id === b.id && a.displayMessage === b.displayMessage),
        //         map(dto => this._convertMessage(dto)),
        //         //withLatestFrom(this.aiSessionsService.messagesFromSession$),
        //         //delay(1500),
        //         scan((mapAcc, msg) => {
        //             const next = new Map(mapAcc);
        //
        //             if (msg.owner === 'system') {
        //                 // Always insert as a new entry, key = id + timestamp
        //                 const sysKey = `${msg.id}-${msg.timestamp}`;
        //                 next.set(sysKey, msg);
        //                 return next;
        //             }
        //
        //             const existing = next.get(msg.id);
        //             if (existing) {
        //                 next.set(msg.id, {
        //                     ...existing,
        //                     //content: existing.content + ' ' + msg.content.trim(),
        //                     content: existing.content + msg.content,
        //                     timestamp: msg.timestamp
        //                 });
        //             } else {
        //                 next.set(msg.id, msg);
        //             }
        //             return next;
        //         }, new Map<MessageId, AIChatMessage>()),
        //         map((messageMap) => {
        //             return Array.from(messageMap.values()).sort((a, b) => {
        //                 const firstA = a[0];
        //                 const firstB = b[0];
        //
        //                 if (!firstA || !firstB) {
        //                     return 0;
        //                 }
        //
        //                 return dayjs(firstA.timestamp).unix() - dayjs(firstB.timestamp).unix();
        //             });
        //
        //         }),
        //         shareReplay(1)
        //     );
        //#endregion Ui messages

        //#region STORE
        const liveDto$ = messages$.pipe(
            tap(msg => this._showMessageLogsSubject.next(msg)),
            shareReplay({ bufferSize: 1, refCount: true })
        );

        const finished$ = this._incomingMessageEvents$.pipe(
            filter(m => (m.message ?? '').includes('*|Finished|*')),
            map(m => ({ id: String(m.id), sessionId: (m as any).sessionId, chatId: (m as any).chatId })),
            shareReplay({ bufferSize: 1, refCount: true })
        );

        const userInput$ = this._incomingMessages$.pipe(
            filterByType(AIChatMessageType.User)
        );

        messageStore.ingestLiveDto(liveDto$);
        messageStore.ingestFinished(finished$);
        messageStore.ingestUserMessage(userInput$);

        //#endregion STORE

        //#region Agents
        // AI messages
        const aiAgents$ = messages$.pipe(
            filterByType(AIChatMessageType.AI)
            , tap(m => {
                if (!this.currentAgentId) {
                    this._currentAgentSubject.next(m.sender);
                    this._currentAgentIdSubject.next(m.sender.id);
                }
                if (this.currentAgentId !== m.sender?.id) {
                    this._lastAgentSubject.next(this.currentAgent);
                    this._lastAgentIdSubject.next(this.currentAgent.id);
                    this._currentAgentSubject.next(m.sender);
                    this._currentAgentIdSubject.next(m.sender.id);
                }
            })
            , share()
        );
        //#endregion Agents

        aiAgents$
            .subscribe();

        this._stream$
            .pipe(
                debounceTime(2000) // 5s since the last emission from _stream$
                , withLatestFrom(this._aiIsPending$)
                , filter(([_, isPending]) => {
                    return !!this.currentMessageManager.currentMessageId && !isPending;
                })  // has current
                , tap(() => {
                    // console.log('Reset timer');
                    this.createFakeFinish();
                }),
            )
            .subscribe();
    }

    //#endregion QUEUED messages

    readonly groupedMessages$: Observable<AIChatMessage[]>;

    private isTyping = false;

    //#region Loading
    private readonly _loadingSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    readonly loading$ = this._loadingSubject.asObservable();
    //#endregion Loading

    //#region Message Logs
    private readonly _showMessageLogsSubject = new Subject<ExtendedAIChatMessageDto>();
    private readonly _showMessageLogs$ = this._showMessageLogsSubject.asObservable();

    private readonly _showAIMessageLogs$ = this._showMessageLogs$.pipe(
        distinctUntilChanged(),
        filter(messageDto => messageDto.type === AIChatMessageType.AI),
        tap(messageDto => {
            console.log(
                '%cAI Input %c' + messageDto.message + ' %c' + messageDto.sender.name  + ' %c' + messageDto.id,
                'color: pink;',      // System Input
                'color: black;',     // Sender name
                'color: red;',       // Rest of the message
                'color: black;'       // Rest of the message
            );
        })
    );
    private readonly _showSystemMessageLogs$ = this._showMessageLogs$.pipe(
        distinctUntilChanged(),
        filter(messageDto => messageDto.type === AIChatMessageType.System),
        tap(messageDto => {
            console.log('%cSystem Input', 'color: blue;'
                , messageDto.message
                , messageDto.sender.name
                , messageDto.id);
        })
    );
    private readonly _showUserMessageLogs$ = this._showMessageLogs$.pipe(
        distinctUntilChanged(),
        filter(messageDto => messageDto.type === AIChatMessageType.User),
        tap(messageDto => {
            console.log('%cUser Input', 'color: green;'
                , messageDto.message
                , messageDto.sender.name
                , messageDto.id);
        })
    );
    private readonly _showEventMessageLogs$ = this._showMessageLogs$.pipe(
        distinctUntilChanged(),
        filter(messageDto => messageDto.type === AIChatMessageType.Events),
        tap(messageDto => {
            console.log(`%cEvent Input: ${messageDto.message}`, 'color: orange;'
                , messageDto.sender.name
                , messageDto.id);
        })
    );
    private readonly _messageLogs$ = merge(
        this._showAIMessageLogs$,
        this._showSystemMessageLogs$,
        this._showUserMessageLogs$,
        this._showEventMessageLogs$,
    );
    //#endregion Message Logs

    //#region Initial Message
    private readonly initialMessageDto = {
        id: 'system-greeting',
        userId: 0,
        tenantId: undefined,
        targetUserId: 0,
        targetTenantId: undefined,
        side: ChatSide.Receiver,
        type: AIChatMessageType.System,
        readState: ChatMessageReadState.Unread,
        receiverReadState: ChatMessageReadState.Unread,
        sender: {
            name: 'system'
        },
        message:
            'Hello! I’d like to start a conversation with you. Please help me with [your topic here].\n(To send this message, press Ctrl + Enter.)',
        displayMessage:
            'Hello! I’d like to start a conversation with you. Please help me with [your topic here].\n(To send this message, press Ctrl + Enter.)',
        creationTime: dayjs(),
        sharedMessageId: undefined,
        fromQueue: false
    } as ExtendedAIChatMessageDto;
    private readonly _initialMessages$ = of(this.initialMessageDto);
    //#endregion Initial Message

    //#region Incoming Message
    private readonly _incomingMessagesSubject = new Subject<AIChatMessageDto>();
    readonly _incomingMessages$ = this._incomingMessagesSubject.asObservable()
        .pipe(
            map(m => ({ ...(m as any), fromQueue: false } as ExtendedAIChatMessageDto))
            , distinctUntilChanged((a: ExtendedAIChatMessageDto, b: ExtendedAIChatMessageDto) =>
                a.id === b.id
                && a.type === b.type
                && a.displayMessage === b.displayMessage
                && a.creationTime === b.creationTime
            )
            //, tap(messageDto => this._showMessageLogsSubject.next(messageDto))
            // share if multiple downstream consumers
            , share()
        );

    //#region Events
    private readonly _incomingMessageEvents$ = this._incomingMessages$.pipe(
        distinctUntilChanged()
        , filterByType(AIChatMessageType.Events)
        , share()
    );
    private readonly _messageEventStarted$ = this._incomingMessageEvents$.pipe(
        filterByChatEvent(AIChatEvents.Started)
    );
    private readonly _messageEventFinished$ = this._incomingMessageEvents$.pipe(
        filter(messageDto => messageDto.message.includes(AIChatEvents.Finished))
    );
    private readonly _messageEventPending$ = this._incomingMessageEvents$.pipe(
        filter(messageDto => messageDto.message.includes(AIChatEvents.Pending))
        , tap(messageDto => {
            this.showIndicator(messageDto, AIChatEvents.Pending);
        })
    );
    private readonly _messageEventJoinedAI$ = this._incomingMessageEvents$.pipe(
        filter(messageDto => messageDto.message.includes(AIChatEvents.JoinedAI))
        , tap(messageDto => {
            this.showIndicator(messageDto, AIChatEvents.JoinedAI);
        })
    );

    readonly _events$ = merge(
        // this._messageEventStarted$
        // , this._messageEventFinished$
        // , this._messageEventPending$
        // , this._messageEventJoinedAI$
    );
    //#endregion Events

    //#region QUEUED messages
    get queuedMessages(): ExtendedAIChatMessageDto[] {
        return this._queuedMessagesArraySubject.getValue();
    }
    get hasQueuedMessages(): boolean {
        return this.queuedMessages.length > 0;
    }
    //#endregion QUEUED messages

    //#endregion Incoming Message

    //#region Typing Indicator
    private typingMap = new Map<string, TypingIndicator>();
    private readonly typingSubject = new BehaviorSubject<TypingIndicator[]>([
        // { id: '1', name: 'Oleg', message: 'Oleg is pending'},
        // { id: '2', name: 'Dima', message: 'Dima is typing'}
    ]);
    readonly typingIndicators$ = this.typingSubject.asObservable();
    //#endregion Typing Indicator

    private readonly _stream$ = merge(
        this.typingIndicators$

        , this._events$
        , this._messageLogs$
    );

    //#region AI Assistants
    get aiAssistant$(): Observable<AIPersonDescriptionDto[]> {
        return this._aiAssistant$.asObservable();
    }
    get aiAssistant(): AIPersonDescriptionDto[] {
        return this._aiAssistant$.getValue();
    }

    //#region AI is typing
    get connectedAIName$(): Observable<string | undefined> {
        return this._connectedAIName$.asObservable();
    }
    get connectedAIName(): string | undefined {
        return this._connectedAIName$.getValue();
    }
    get aiIsTyping$(): Observable<boolean> {
        return this._aiIsTyping$.asObservable();
    }
    get aiIsTyping(): boolean {
        return this._aiIsTyping$.getValue();
    }
    //#endregion AI is typing

    //#region Current AI Assistant
    get currentAIAssistant(): AIPersonDescriptionDto {
        return this.currentMessageManager.currentAIAssistant;
    }
    //#endregion Current AI Assistant

    //#endregion AI Assistants

    //#region Message

    //#region Current message
    get currentMessageId(): MessageId | undefined {
        return this.currentMessageManager.currentMessageId;
    }
    get currentSharedMessageId(): MessageId | undefined {
        return this.currentMessageManager.currentSharedMessageId;
    }
    //#endregion Current message

    //#region Actions

    protected setAIAssistant(data: AIPersonDescriptionDto[]) {
        this._aiAssistant$.next(data);

        const active = data.find(a => a.isActive);
        if (active) {
            this.aiAgentsService.addAIAgent(active);
        }
    }

    //#region AI Assistants


    //#region AI is typing
    protected setConnectedAIName(name: string | undefined) {
        this._connectedAIName$.next(name);
    }
    protected setAIIsTyping(data: boolean) {
        this._aiIsTyping$.next(data);
    }
    startTyping(input: AIChatMessageDto): void {
        this.setAIIsTyping(true);
        this._getAITypingName(input);
    }
    stopTyping(): void {
        this.setAIIsTyping(false);
    }

    private _getAITypingName(input: AIChatMessageDto) {
        const name = extractJoinedAIName(input.message);
        this.setConnectedAIName(name);

        function extractJoinedAIName(input: string): string | null {
            const match = input.match(/\*\|JoinedAI:(.*?)\|\*/);
            return match ? match[1] : null;
        }
    }
    //#endregion AI is typing

    //#region Current AI Assistant
    protected setCurrentAIAssistant(person: AIPersonDescriptionDto) {
        this.currentMessageManager.setCurrentAIAssistant(person);
    }
    //#endregion Current AI Assistant

    //#endregion AI Assistants

    setReactiveMessages(input: AIChatMessageDto) {
        this._incomingMessagesSubject.next(input);
    }

    private _getLastMessage(messages: AIChatMessage[]): AIChatMessage {
        return _.last(messages);
    }

    private _changeCurrentAIAssistant(input: AIChatMessageDto) {
        this.currentMessageManager.initCurrentMessageId(input.id);
        this.setCurrentAIAssistant(input.sender);
        // console.log(`Current message id -------------- ${this.currentMessageId}`);
        if (this.connectedAIName === this.currentAIAssistant.name) {
            this.hideIndicator(input.id);
        }
    }

    //#region Loading
    protected setLoading(value: boolean) {
        this._loadingSubject.next(value);
    }
    showLoader() {
        this.setLoading(true);
    }
    hideLoader() {
        this.setLoading(false);
    }
    //#endregion Loading

    protected showResult(input: ExtendedAIChatMessageDto): ExtendedAIChatMessageDto {
        const id = this._getSearchId(input.message ?? '');
        if (id) {
            this.esHistoryService.setSearchId(id, true);
            input.displayMessage = InstructionInterceptor.convertMarkdownToLink(id);
        }
        return input; // always pass a message through
    }
    protected convertShowResult(input: ExtendedAIChatMessageDto): ExtendedAIChatMessageDto {
        const id = this._getSearchId(input.message ?? '');
        if (id) {
            input.displayMessage = InstructionInterceptor.convertMarkdownToLink(id);
        }
        return input; // always pass a message through
    }

    protected showOffline(input: ExtendedAIChatMessageDto): ExtendedAIChatMessageDto {
        input.displayMessage = InstructionInterceptor.transformMessageText(input.displayMessage);
        return input; // always pass a message through
    }

    private _getSearchId(message: string): string | null {
        const match = message.match(/\*\|SearchResult:(.*?)\|\*/);
        return match ? match[1] : null;
    }

    private _extractAgentName(m: ExtendedAIChatMessageDto): string | undefined {
        return m.sender?.name ?? (m as any).assistantName ?? this.currentAIAssistant?.name;
    }
    //#endregion Actions

    //#endregion Message

    //#region Sessions
    // Public method to switch session
    switchToSession(sessionId: string): void {
        this.aiSessionsService.selectSession(sessionId);
    }

    get sessionId(): SessionId {
        return this.aiSessionsService.currentSessionId;
    }
    //#endregion Sessions

    //#region Typing Indicators
    showIndicator(input: ExtendedAIChatMessageDto, event: AIChatEvents | AIChatPendingEvents): void {
        //const name = input.sender.name;
        const name = this._getAgentNameFromEvent(input.message) ?? input?.sender?.name ?? '';

        let message = `${name} is typing`;
        if (event === AIChatEvents.Pending || this.isPendingEvent(input)) {
            switch (event) {
                case AIChatPendingEvents.SearchingIntent: message = 'Understanding your request'; break;
                case AIChatPendingEvents.SearchingFunction: message = 'Figuring out the best way to help'; break;
                case AIChatPendingEvents.PreparingResult: message = 'Preparing your answer'; break;
                default: message = `${name} is working`; break;
            }
        } else if (event === AIChatEvents.JoinedAI) {
            message = `${name} is typing`;
        }

        const key = `${input.sharedMessageId}-${name}`;
        this.typingMap.set(key, { id: input.id, name: name, message: message });

        this._emitIndicators();
    }

    private isPendingEvent(input: ExtendedAIChatMessageDto): boolean {
        const events = [
            AIChatEvents.Pending,
            AIChatPendingEvents._,
            AIChatPendingEvents.PreparingResult,
            AIChatPendingEvents.SearchingIntent,
            AIChatPendingEvents.SearchingFunction
        ];
        return events.some(item => item === input.message || input.message.includes(item));
    }

    private isSearchResultEvent(input: ExtendedAIChatMessageDto): boolean {
        const events = [
            AIChatEvents.SearchResult,
        ];
        return events.some(item => item === input.message || input.message.includes(item));
    }

    private _getAgentNameFromEvent(message: string): string | null {
        const match = message.match(/\*\|JoinedAI:(.*?)\|\*/);
        return match ? match[1] : null;
    }

    hideIndicator(id: string): void {
        this.typingMap.delete(id);
        this._emitIndicators();
    }

    hideIndicatorByAgentId(agentId: string): void {
        //this.typingMap.delete(id);
        this._emitIndicators();
    }

    hideIndicatorByName(input: ExtendedAIChatMessageDto): void {
        const key = `${input.sharedMessageId}-${input.sender.name}`;
        this.typingMap.delete(key);
        this._emitIndicators();
    }

    private _removeIndicator(key: string): void {
        this.typingMap.delete(key);
        this._emitIndicators();
    }

    hideIndicatorByMessage(input: ExtendedAIChatMessageDto): void {
        const name = extractName(input.message);

        const key = `${input.sharedMessageId}-${name}`;
        this._removeIndicator(key);
    }

    clearAllIndicators(): void {
        this.typingMap.clear();
        this._emitIndicators();
    }

    private _emitIndicators(): void {
        this.typingSubject.next(Array.from(this.typingMap.values()));
    }

    hideIndicatorByDto(input: AIChatMessageReadyDto) {
        if (!input) {
            return;
        }
        const key = `${input.sharedMessageId}-${input.agentName}`;
        this._removeIndicator(key);
    }

    //#endregion Typing Indicators

    //#region File Upload
    uploadFiles$(files: FileToAiDto[]) {
        const input = {
            sessionId: this.sessionId,
            files: files
        } as UploadFilesToChatInputDto;

        return this.aiChatServiceProxy.uploadFiles(input);
    }

    private generateGuid(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            // tslint:disable-next-line:no-bitwise
            const r = Math.random() * 16 | 0;
            // tslint:disable-next-line:no-bitwise
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
    //#endregion File Upload

    //#region Fake Messages
    createFakeFinish() {
        const id = this.currentMessageId ?? 'fake-finish';
        const sharedMessageId = this.currentSharedMessageId ?? undefined;
        const ai = this.currentMessageManager.currentAIAssistant ?? {
            name: 'AI'
        };

        let fake = {
            id: id,
            userId: 0,
            tenantId: undefined,
            targetUserId: 0,
            targetTenantId: undefined,
            side: ChatSide.Receiver,
            type: AIChatMessageType.Events,
            readState: ChatMessageReadState.Unread,
            receiverReadState: ChatMessageReadState.Unread,
            sender: ai,
            message: '*|Finished|*',
            displayMessage: '*|Finished|*',
            creationTime: dayjs(),
            sharedMessageId: sharedMessageId,
            fromQueue: false
        } as ExtendedAIChatMessageDto;

        this.setReactiveMessages(fake);
    }

    //#endregion Fake Messages

    initialize(): Observable<any> {
        return forkJoin({
            sessions: this.aiSessionsService.initialize()
            , aiAgents: this.aiAgentsService.initialize()
        });
    }

    loadMessages(metric: AIChatMetricDto) {
        const sid = (metric.sessionId || this.aiSessionsService.currentSessionId) as string;
        const agent = metric.aiAssistantName;

        this.aiChatServiceProxy.getQueueMessages(sid, agent)
            .pipe(
                take(1)
            )
            .subscribe();
    }
}


