
import { Injector } from '@angular/core';
import { AppConsts } from '@shared/AppConsts';

import { AppComponentBase as BaseAppComponentBase } from '@axilla/axilla-shared';

import {PermissionCheckerService} from '@node_modules/abp-ng2-module';
import {EnterpriseSearchService} from '@app/enterprise-search/services/enterprise-search.service';
import {Subject} from '@node_modules/rxjs';
import {EsDataViewService} from '@app/enterprise-search/services/es-data-view.service';
import {EnterpriseSearchServiceProxy} from '@shared/service-proxies/service-proxies';

export abstract class EsBaseService  {

    protected enterpriseSearchServiceProxy: EnterpriseSearchServiceProxy;
    protected esDataViewService: EsDataViewService;

    protected readonly destroy$ = new Subject<void>();

    protected constructor(injector: Injector) {
        this.esDataViewService = injector.get(EsDataViewService);
        this.enterpriseSearchServiceProxy = injector.get(EnterpriseSearchServiceProxy);
    }

    //#region DataView
    get layoutMode(): 'list' | 'grid' {
        return this.esDataViewService.layoutMode;
    }
    setGridMode() {
        this.esDataViewService.setGridMode();
    }
    setListMode() {
        this.esDataViewService.setListMode();
    }
    //#endregion DataView

}

