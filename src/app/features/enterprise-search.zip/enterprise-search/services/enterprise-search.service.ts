import {Injectable, Injector} from '@angular/core';

import {take, tap, takeUntil, catchError} from 'rxjs/operators';
import {BehaviorSubject, Observable, of, Subject, throwError} from 'rxjs';

import {AIChatMessage, ESResult, ESSorting} from '../shared/models';
import {
    EnterpriseSearchDataToElasticModelDto,
    EnterpriseSearchItemsInputDto,
    EnterpriseSearchServiceProxy, FilterOptionDto, FilterOptionValueDto,
    IEnterpriseSearchDataToElasticModelDto,
    IEnterpriseSearchItemsInputDto,
    SearchResultDto,
    TimelineDto
} from '@shared/service-proxies/service-proxies';
import {EsDataViewService} from '@app/enterprise-search/services/es-data-view.service';
import {EsHistoryService} from '@app/enterprise-search/services/es-history.service';
import {EsPreviewService} from '@app/enterprise-search/services/es-preview.service';
import {ESStore} from '@app/enterprise-search/shared/store/es.store';

import * as _ from 'lodash';
import dayjs from 'dayjs';

@Injectable({
    providedIn: 'root'
})
export class EnterpriseSearchService {

    basicSearchTrigger$ = new Subject<void>();
    advancedSearchTrigger$ = new Subject<void>();

    private _searchMode$: BehaviorSubject<'image' | 'text' | 'combined'>;

    private _sorting$: BehaviorSubject<ESSorting[]>;
    private _selectedSorting$: BehaviorSubject<ESSorting>;
    private _exactSearch$: BehaviorSubject<boolean>;
    private _dateRangefilter$: BehaviorSubject<Date[]>;
    private _filters$: BehaviorSubject<FilterOptionDto[]>;
    private _selectedFilters$: BehaviorSubject<FilterOptionValueDto[]>;

    private _searchResult$: BehaviorSubject<SearchResultDto>;
    private _isFiltersExpanded$: BehaviorSubject<boolean>;
    private _isLoading$: BehaviorSubject<boolean>;
    private _isShowSearchResult$: BehaviorSubject<boolean>;
    private _base64Search$: BehaviorSubject<string>;
    private _search$: BehaviorSubject<string>;
    private _totalRecordsCount$: BehaviorSubject<number>;
    private _searchData$: BehaviorSubject<EnterpriseSearchDataToElasticModelDto[]>;

    private _timeLine$: BehaviorSubject<TimelineDto[]>;
    private _showTimeLine$: BehaviorSubject<boolean>;

    private _aiChat$: BehaviorSubject<boolean>;

    private _isFileUploadOpened$: BehaviorSubject<boolean>;
    private _imagePreview$: BehaviorSubject<string>;

    protected enterpriseSearchServiceProxy: EnterpriseSearchServiceProxy;
    protected esDataViewService: EsDataViewService;
    protected esHistoryService: EsHistoryService;
    protected esPreviewService: EsPreviewService;

    protected eSStore: ESStore;

    constructor(injector: Injector) {
        this.enterpriseSearchServiceProxy = injector.get(EnterpriseSearchServiceProxy);
        this.esDataViewService = injector.get(EsDataViewService);
        this.esHistoryService = injector.get(EsHistoryService);
        this.esPreviewService = injector.get(EsPreviewService);

        this.eSStore = injector.get(ESStore);

        this.initialization();
    }

    private initialization() {
        this._searchMode$ = new BehaviorSubject<'image' | 'text' | 'combined'>('text');

        this._selectedSorting$ = new BehaviorSubject<ESSorting>({ name: 'Relevant desc', value: false, order: 'DESC' });
        this._sorting$ = new BehaviorSubject<ESSorting[]>([
            { name: 'Date desc', value: true, order: 'DESC' },
            { name: 'Date asc', value: true, order: 'ASC' },
            { name: 'Relevant desc', value: false, order: 'DESC' },
            { name: 'Relevant asc', value: false, order: 'ASC' }
        ]);

        this._exactSearch$ = new BehaviorSubject<boolean>(false);
        this._dateRangefilter$ = new BehaviorSubject<Date[]>([]);
        this._filters$ = new BehaviorSubject<FilterOptionDto[]>([]);
        this._selectedFilters$ = new BehaviorSubject<FilterOptionValueDto[]>([]);

        this._isShowSearchResult$ = new BehaviorSubject<boolean>(false);
        this._search$ = new BehaviorSubject<string>('');
        this._base64Search$ = new BehaviorSubject<string>('');

        this._searchData$ = new BehaviorSubject<EnterpriseSearchDataToElasticModelDto[]>([]);
        this._searchResult$ = new BehaviorSubject<SearchResultDto>(undefined);
        this._isFiltersExpanded$ = new BehaviorSubject<boolean>(false);
        this._isLoading$ = new BehaviorSubject<boolean>(false);
        this._totalRecordsCount$ = new BehaviorSubject<number>(0);

        this._timeLine$ = new BehaviorSubject<TimelineDto[]>(undefined);
        this._showTimeLine$ = new BehaviorSubject<boolean>(false);
        this._isFileUploadOpened$ = new BehaviorSubject<boolean>(false);
        this._imagePreview$ = new BehaviorSubject<string>(undefined);

        this._aiChat$ = new BehaviorSubject<boolean>(true);
    }

    flush() {
        this.resetAllFilters();
        this._resetSearchResult();
        this._resetSearchQuery();
        this._resetSearchData();
        this._resetTotalRecordsCount();
        this.clearImageForPreview();

        this.esHistoryService.flush();
        this.esPreviewService.flush();
        this.resetStore();
    }

    runModeCheck() {
        if (this.searchMode === 'image' && this.layoutMode === 'list') {
            this.setGridMode();
        } else if (this.searchMode === 'text' && this.layoutMode === 'grid') {
            this.setListMode();
        }
    }

    //#region searchTrigger

    generateLoremIpsum(sentencesCount: number = 1): string {
        const loremSentences = [
            'The item you\'re looking for can be found using the search panel.'
        ];

        let result = '';
        for (let i = 0; i < sentencesCount; i++) {
            // Pick random sentence from array
            const randomIndex = Math.floor(Math.random() * loremSentences.length);
            result += loremSentences[randomIndex] + ' ';
        }

        return result.trim();
    }

    triggerBasicSearch(): void {
        this.basicSearchTrigger$.next();
    }

    triggerAdvancedSearch(): void {
        this.advancedSearchTrigger$.next();
    }
    //#endregion searchTrigger

    //#region History Mode
    enableHistorySearchMode() {
        this.esHistoryService.enableHistorySearchMode();
        this._resetSearchQuery();
        this.clearImageForPreview();
    }
    //#endregion History Mode

    //#region Store
    resetStore() {
        this.eSStore.reset();
    }

    checkIfItemAvailableInStore(): boolean {
        const id = this.esHistoryService.selectedMetadata.searchId;
        return this.eSStore.checkIfItemAvailableInStore(id);
    }
    addToStore(result: SearchResultDto) {
        this.eSStore.addSearchResult({
            data: result, // Your data here
            query: {
                date: new Date(),
                query: this.search,
                base64query: result.metadata.searchTermBase64 ?? undefined
            },
        });
    }
    getFromStore$(): Observable<ESResult> {
        this.showLoadingIndicator();

        const id = this.esHistoryService.selectedMetadata.searchId;
        return this.eSStore.getItemById(id)
            .pipe(
                tap((result: ESResult) => {
                    //check if picture search
                    if (result.data.metadata.visualSearch) {
                        this.setImageForPreview(result.data.metadata.searchTermBase64 as string);
                    } else {
                        this.clearImageForPreview();
                    }
                    this.setSearchResult(result.data);
                    this.hideLoadingIndicator();
                })
            );
    }

    getLastEntry$(): Observable<ESResult> {
        this.showLoadingIndicator();
        return this.eSStore.getLastEntry()
            .pipe(
                tap((result: ESResult | null) => {
                    if (result != null) {
                        //check if picture search
                        if (result.data.metadata.visualSearch) {
                            if (this.imagePreview !== result.data.metadata.searchTermBase64) {
                                this.setImageForPreview(result.data.metadata.searchTermBase64 as string);
                            }
                            if (result.data.metadata.searchTerm) {
                                this.setSearch(result.data.metadata.searchTerm);
                            }
                        } else {
                            this.clearImageForPreview();
                            this.setSearch(result.data.metadata.searchTerm);
                        }
                    }
                    this.setSearchResult(result.data, false);

                    this.hideLoadingIndicator();
                })
            );
    }

    getPaginatedResults$(filter: string, skip: number, take: number)
        : Observable<{items: ESResult[], total: number}> {
        return this.eSStore.getPaginatedResults(skip, take
            , !filter
                ? () => true
                : (item: ESResult) => item.data.metadata.searchTerm.includes(filter));
    }

    //#endregion Store

    //#region SearchMode
    get searchMode(): 'image' | 'text' | 'combined' {
        return this._searchMode$.getValue();
    }
    get searchMode$(): Observable<'image' | 'text' | 'combined'> {
        return this._searchMode$.asObservable();
    }
    setSearchMode(mode: 'image' | 'text' | 'combined') {
        this._searchMode$.next(mode);
    }
    setImageSearchMode() {
        this.setSearchMode('image');
    }
    setTextMode() {
        this.setSearchMode('text');
    }
    setCombinedMode() {
        this.setSearchMode('combined');
    }
    isTextSearchMode(): boolean {
        return this._searchMode$.getValue() === 'text';
    }
    isImageSearchMode(): boolean {
        return this._searchMode$.getValue() === 'image';
    }
    isCombinedSearchMode(): boolean {
        return this._searchMode$.getValue() === 'combined';
    }
    //#endregion

    //#region DataView
    get layoutMode(): 'list' | 'grid' {
        return this.esDataViewService.layoutMode;
    }
    setGridMode() {
        this.esDataViewService.setGridMode();
    }
    setListMode() {
        this.esDataViewService.setListMode();
    }
    //#endregion DataView


    //#region Search

    //#region isShowSearchResult
    startAIChat() {
        if (!this.isShowSearchResult) {
            this.showSearchResult();
        }
    }

    private showSearchResult() {
        this._isShowSearchResult$.next(true);
    }
    private hideSearchResult() {
        this._isShowSearchResult$.next(false);
    }
    get isShowSearchResult$(): Observable<boolean> {
        return this._isShowSearchResult$.asObservable();
    }
    get isShowSearchResult(): boolean {
        return this._isShowSearchResult$.getValue();
    }
    private _resetSearchResult() {
        this.hideSearchResult();
    }
    //#endregion isShowSearchResult

    //#region Search String
    setSearch(filterValue: string)  {
        this._search$.next(filterValue);

        if (!this.isShowSearchResult) {
            this.showSearchResult();
        }
    }
    get search$(): Observable<string> {
        return this._search$.asObservable();
    }
    get search(): string {
        return this._search$.getValue();
    }
    private _resetSearchQuery() {
        this._search$.next('');
    }
    //#endregion Search String

    //#region base64 Search
    setBase64Search(filterValue: string)  {
        this._base64Search$.next(filterValue);

        if (!this.isShowSearchResult) {
            this.showSearchResult();
        }
    }
    get base64Search$(): Observable<string> {
        return this._base64Search$.asObservable();
    }
    get base64Search(): string {
        return this._base64Search$.getValue();
    }
    private _resetBase64SearchQuery() {
        this._base64Search$.next(undefined);
    }
    //#endregion base64 Search

    setDemoResult(result: SearchResultDto) {
        this.setSearchResult(result, true);
    }

    private setSearchResult(result: SearchResultDto, saveToStore: boolean = true) {
        this._searchResult$.next(result);

        if (!this.esHistoryService.isHistoryModeSearch && saveToStore ) {
            this.addToStore(result);

            if (result?.metadata) {
                //update metadata
                this.esHistoryService.setMetadata(result.metadata);
            }
        }

        //update searchData
        this.setSearchData(result.data);
        //update totalFound
        this.setTotalRecordsCount(result.totalFound);
        //update timeLine
        this.setTimeLine(result.timeLine);

        this.esHistoryService.setRequiredToCheckLastEntry(false);
    }

    //#region SearchData
    private setSearchData(result: EnterpriseSearchDataToElasticModelDto[]) {
        if (this.imagePreview) {
            this.initDummyPictures(result);
        }
        this._searchData$.next([...result]);
    }
    get searchData$(): Observable<EnterpriseSearchDataToElasticModelDto[]> {
        return this._searchData$.asObservable();
    }
    get searchData(): EnterpriseSearchDataToElasticModelDto[] {
        return this._searchData$.getValue();
    }
    private _resetSearchData() {
        this._searchData$.next(undefined);
    }
    //#endregion SearchData

    //#region TotalRecordsCount
    private setTotalRecordsCount(result: number) {
        this._totalRecordsCount$.next(result);
    }
    get totalRecordsCount$(): Observable<number> {
        return this._totalRecordsCount$.asObservable();
    }
    get totalRecordsCount(): number {
        return this._totalRecordsCount$.getValue();
    }
    private _resetTotalRecordsCount() {
        this._totalRecordsCount$.next(0);
    }
    //#endregion TotalRecordsCount

    //#region IsLoading
    get isLoading$(): Observable<boolean> {
        return this._isLoading$.asObservable();
    }
    showLoadingIndicator() {
        this._isLoading$.next(true);
    }
    hideLoadingIndicator() {
        this._isLoading$.next(false);
    }
    get isLoading(): boolean {
        return this._isLoading$.getValue();
    }
    //#endregion

    onSearchData$(input: IEnterpriseSearchItemsInputDto): Observable<SearchResultDto>  {
        this.showLoadingIndicator();

        if (this.esHistoryService.isHistoryModeSearch && this.esHistoryService.selectedMetadata.searchTerm !== input.content) {
            this.esHistoryService.resetCurrentMetadata();
        }

        return this.enterpriseSearchServiceProxy
            .searchData(new EnterpriseSearchItemsInputDto(input))
            .pipe(
                tap((result: SearchResultDto) => {
                    this.setSearchResult(result);
                    this.hideLoadingIndicator();
                }),
                catchError((error) => {
                    this.hideLoadingIndicator();
                    return throwError(() => error); // if you want to propagate the error
                })
            );
    }
    //#endregion Search

    //#region File Upload

    get isFileUploadOpened(): boolean {
        return this._isFileUploadOpened$.getValue();
    }

    private openFileUploadModal() {
        this._isFileUploadOpened$.next(true);
    }
    private closeFileUploadModal() {
        this._isFileUploadOpened$.next(false);
    }

    forceCloseFileUploadModal() {
        this.closeFileUploadModal();
    }

    toggleFileUpload() {
        if (this.isFileUploadOpened) {
            this.closeFileUploadModal();
        } else {
            this.openFileUploadModal();
        }
    }

    get imagePreview$(): Observable<string> {
        return this._imagePreview$.asObservable();
    }
    get imagePreview(): string {
        return this._imagePreview$.getValue();
    }
    setImageForPreview(value: string) {
        this._imagePreview$.next(value);

        //check if layout mode not grid than change it
        if (this.layoutMode !== 'grid') {
            this.setGridMode();
        }
        //check if search mode not image than change it
        if (this.searchMode !== 'image') {
            this.setImageSearchMode();
        }
    }
    setImageForPreviewAndRunSearch(value: string) {
        this.setImageForPreview(value);

        this.beginImageSearch();
    }

    clearImageForPreview(changeViewMode: boolean = true) {
        this._imagePreview$.next(undefined);

        if (changeViewMode) {
            if (this.layoutMode !== 'list') {
                this.setListMode();
            }
        }
        if (this.searchMode !== 'text') {
            this.setTextMode();
        }
    }

    beginImageSearch() {
        if (this.searchMode !== 'image') {
            this.setImageSearchMode();
        }
        this.setBase64Search(this.imagePreview);
    }

    // Generate a random size (200-400, step 50)
    private getRandomSize(min: number, max: number, step: number): number {
        const steps = (max - min) / step;
        return min + Math.floor(Math.random() * (steps + 1)) * step;
    }
    // Generate a random number between min and max
    private getRandomInt(min: number, max: number): number {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    async initDummyPictures(result: EnterpriseSearchDataToElasticModelDto[]) {
        for (const item of result) {
            if (!item.thumbnail) {
                const width = this.getRandomSize(200, 400, 50);
                const height = this.getRandomSize(200, 400, 50);
                const randomNum = this.getRandomInt(1, 10);

                const imageUrl = `https://picsum.photos/${width}/${height}?random=${randomNum}`;
                item.thumbnail = await this.convertImageToBase64(imageUrl);
            }
        }
    }

    async convertImageToBase64(imageUrl: string): Promise<string> {
        const response = await fetch(imageUrl);
        const blob = await response.blob();

        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = () => resolve(reader.result as string);
        });
    }

    // Generate 10 objects dynamically

    generateData() {
        const generatedData = Array.from({ length: 10 }, (_, i) => (new EnterpriseSearchDataToElasticModelDto({
            sourceKey: `source-${i + 1}`,
            recipientKey: `recipient-${i + 1}`,
            receiverKey: `receiver-${i + 1}`,
            mainContextKey: `context-${i + 1}`,
            id: `${i + 1}`,
            parentId: `parent-${i + 1}`,
            date: dayjs(),
            userContext: [`user${i + 1}`],
            source: `System ${String.fromCharCode(65 + i)}`,
            title: `Example Document ${i + 1}`,
            type: ['PDF', 'DOCX', 'TXT', 'XLSX'][i % 4],
            content: `Sample content for document ${i + 1}...`,
            contentHash: `hash${i + 1}`,
            hash: [`hash${i + 1}`],
            path: [],
            contextActions: [],
            thumbnail: `https://source.unsplash.com/random/200x200?sig=${i + 1}`
        } as IEnterpriseSearchDataToElasticModelDto)));
    }
    //#endregion  File Upload

    //#region Filters

    //#region Filter bar
    get filterState(): boolean {
        return this._isFiltersExpanded$.getValue();
    }
    toggleFilters() {
        if (this.filterState) {
            this.foldFilters();
        } else {
            this.expandFilters();
        }
    }
    private expandFilters() {
        this._isFiltersExpanded$.next(true);
    }
    private foldFilters() {
        this._isFiltersExpanded$.next(false);
    }
    private _resetFilterBar() {
        this.foldFilters();
    }
    //#endregion Filter bar

    //#region TimeLine
    private setTimeLine(result: TimelineDto[] | undefined) {
        this._timeLine$.next(result);
    }
    get timeLine$(): Observable<TimelineDto[]> {
        return this._timeLine$.asObservable();
    }
    get timeLine(): TimelineDto[] {
        return this._timeLine$.getValue();
    }

    setTimeLineVisibility(result: boolean) {
        this._showTimeLine$.next(result);
    }
    get showTimeLine$(): Observable<boolean> {
        return this._showTimeLine$.asObservable();
    }
    get isTimeLineVisible(): boolean {
        return this._showTimeLine$.getValue();
    }
    //#endregion TimeLine

    //#region AI Chat
    setAIChatVisibility(result: boolean) {
        this._aiChat$.next(result);
    }
    get aiChat$(): Observable<boolean> {
        return this._aiChat$.asObservable();
    }
    get isAIChatVisible(): boolean {
        return this._aiChat$.getValue();
    }
    //#endregion AI Chat

    //#region filters
    get filters$(): Observable<FilterOptionDto[]> {
        return this._filters$.asObservable();
    }
    set filters(value: FilterOptionDto[]) {
        this._filters$.next(value);
    }
    get filters(): FilterOptionDto[] {
        return this._filters$.getValue();
    }
    //#endregion filters

    //#region exact search
    get exactSearch$(): Observable<boolean> {
        return this._exactSearch$.asObservable();
    }
    setExactSearch(value: boolean) {
        this._exactSearch$.next(value);
    }
    get exactSearch(): boolean {
        return this._exactSearch$.getValue();
    }
    isExactSearchEnabled(): boolean {
        return this._exactSearch$.getValue();
    }
    resetExactSearch() {
        this.setExactSearch(false);
    }
    //#endregion exact search

    //#region selected filters
    get selectedFilters$(): Observable<FilterOptionValueDto[]> {
        return this._selectedFilters$.asObservable();
    }
    setSelectedFilters(value: FilterOptionValueDto[]) {
        this._selectedFilters$.next(value);
    }
    get selectedFilters(): FilterOptionValueDto[] {
        return this._selectedFilters$.getValue();
    }
    //#endregion selected filters

    //#region calls
    onGetAvailableFilters$(): Observable<FilterOptionDto[]>  {
        return this.enterpriseSearchServiceProxy
            .getAvailableFilters()
            .pipe(
                tap((result: FilterOptionDto[]) => {
                    //set filters
                    this.filters = this._extendFilters(result);
                })
            );
    }

    private _extendFilters(result: FilterOptionDto[]): FilterOptionDto[] {

        const exact = {
            label: 'Other'
            , filterName: 'Path.Other'
            , options: [
                { value: 'Exact search', displayName: 'Exact' }
            ] as FilterOptionValueDto[]
        } as FilterOptionDto;

        let newResult = _.cloneDeep(result);
        //newResult.push(exact);

        return newResult;
    }
    //#endregion calls

    //#region Actions and Helpers
    resetAllFilters(): void {
        if (this.isResetDisabled()) {
            return;
        }

        this.setTimeLineVisibility(false);
        this.setSelectedFilters([]);
        this._resetFilterBar();
        this.resetDateFilter();
        this.resetExactSearch();
    }

    isResetDisabled(): boolean {
        return this.selectedFilters?.length === 0
            && !this.isExactSearchEnabled()
            && !this.isDateFilterAreSet();
    }

    isClearDisabled(filter: string): boolean {
        const filterData = this.filters.find(f => f.label === filter);
        if (!filterData) { return true; }

        return !filterData.options.some(option =>
            this.selectedFilters?.some(selected =>
                selected.value === option.value &&
                selected.displayName === option.displayName
            )
        );
    }

    clearFilterByType(type: string): void {
        if (this.isClearDisabled(type)) {
            return;
        }

        const filterData = this.filters.find(f => f.label === type);
        if (!filterData) { return; }

        const filters = this.selectedFilters?.filter(selected =>
            !filterData.options.some(option =>
                selected.value === option.value &&
                selected.displayName === option.displayName
            )
        );

        this.setSelectedFilters(filters);
    }

    getSelectedFilters(): { [key: string]: string[]; } | undefined {
        if (!this.selectedFilters.length) { return undefined; }

        return this.filters.reduce((result, filter) => {
            const selectedValues = filter.options
                .filter(option => this.selectedFilters.some(selected => selected.value === option.value))
                .map(option => option.value);

            if (selectedValues.length) {
                result[filter.filterName] = selectedValues;
            }

            return result;
        }, {} as { [key: string]: string[] });
    }
    //#endregion Actions and Helpers

    //#region Sorting
    get sorting$(): Observable<ESSorting[]> {
        return this._sorting$.asObservable();
    }
    get sorting(): ESSorting[] {
        return this._sorting$.getValue();
    }
    get selectedSorting$(): Observable<ESSorting | undefined> {
        return this._selectedSorting$.asObservable();
    }
    setSelectedSorting(value: ESSorting | undefined) {
        this._selectedSorting$.next(value);
    }
    get selectedSorting(): ESSorting | undefined {
        return this._selectedSorting$.getValue();
    }
    resetSorting(): void {
        this.setSelectedSorting({ name: 'Relevant desc', value: false, order: 'DESC' });
    }
    isSortingAreSet(): boolean {
        return this.selectedSorting !== undefined && this.selectedSorting.name !== 'Relevant desc';
    }
    //#endregion Sorting

    //#region Date range filter
    get dateRangefilter$(): Observable<Date[]> {
        return this._dateRangefilter$.asObservable();
    }
    get dateRangefilter(): Date[] {
        return this._dateRangefilter$.getValue();
    }
    setDateRangeFilter(value: Date[]) {
        this._dateRangefilter$.next(value);
    }
    isDateFilterAreSet(): boolean {
        return this.dateRangefilter.length > 0
            && this.dateRangefilter.every(date => date !== null);
    }
    resetDateFilter(): void {
        this._dateRangefilter$.next([]);
    }
    //#endregion Date range filter

    isFilterChanged(): boolean {
        const prevFilter = this.esHistoryService.metadata.find(item => !item.isPointer);

        if (!prevFilter) { return false; }

        // Compare simple fields
        const isBasicChanged =
            prevFilter.exactSearch !== this.exactSearch ||
            prevFilter.sort !== this.selectedSorting?.order ||
            prevFilter.sortByDate !== this.selectedSorting?.value;

        // Compare filters object
        const isFilterObjectChanged = !this.areFiltersEqual(
            prevFilter.filters,
            this.selectedFilters
        );

        // Compare date range
        const prevStart = prevFilter?.startDate ? prevFilter?.startDate : undefined;
        const prevEnd = prevFilter?.endDate ? prevFilter?.endDate.endOf('day') : undefined;

        const currentStart = this.dateRangefilter?.[0] ? dayjs(this.dateRangefilter[0]) : undefined;
        const currentEnd = this.dateRangefilter?.[1]
            ? dayjs(this.dateRangefilter[1]).endOf('day')
            : undefined;

        const isDateChanged =
            !this.areDatesEqual(prevStart, currentStart) || !this.areDatesEqual(prevEnd, currentEnd);

        return isBasicChanged || isFilterObjectChanged || isDateChanged;
    }

    private areDatesEqual(d1?: dayjs.Dayjs, d2?: dayjs.Dayjs): boolean {
        if (!d1 && !d2) { return true; }
        if (!d1 || !d2) { return false; }
        return d1.isSame(d2);
    }

    private areFiltersEqual(
        f1: { [key: string]: string[] },
        f2: FilterOptionValueDto[] | undefined
    ): boolean {
        if (!f2) { return false; }

        // Flatten all values from f1
        const f1Values = Object.values(f1)
            .reduce((acc, val) => acc.concat(val), [])
            .filter(Boolean)
            .sort();

        // Get values from f2
        const f2Values = f2
            .map(opt => opt.value || '')
            .filter(Boolean)
            .sort();

        if (f1Values.length !== f2Values.length) { return false; }

        for (let i = 0; i < f1Values.length; i++) {
            if (f1Values[i] !== f2Values[i]) {
                return false;
            }
        }

        return true;
    }

    //#endregion filters
}

