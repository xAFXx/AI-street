import {inject, Injectable, Injector} from '@angular/core';
import {BehaviorSubject, distinctUntilChanged, merge} from 'rxjs';

import {AgentId, MessageId} from '@app/enterprise-search/shared/types';
import {AIChatMetricDto, AIChatServiceProxy, AIPersonDescriptionDto} from '@shared/service-proxies/service-proxies';
import {map, tap} from 'rxjs/operators';
import {Observable} from '@node_modules/rxjs';

@Injectable({
    providedIn: 'root'
})
export class AiAgentsService {

    private readonly _currentAIAssistantSubject: BehaviorSubject<AIPersonDescriptionDto> = new BehaviorSubject<AIPersonDescriptionDto | undefined>(undefined);
    readonly currentAIAssistant$ = this._currentAIAssistantSubject.asObservable();

    private readonly _availableAIAssistantSubject: BehaviorSubject<AIPersonDescriptionDto[]> = new BehaviorSubject<AIPersonDescriptionDto[]>([]);
    readonly availableAIAgents$ = this._availableAIAssistantSubject.asObservable();

    get availableAIAgents(): AIPersonDescriptionDto[] | undefined {
        return this._availableAIAssistantSubject.getValue();
    }

    private readonly _aiAgentsSubject: BehaviorSubject<AIPersonDescriptionDto[]> = new BehaviorSubject<AIPersonDescriptionDto[] | undefined>([]);
    readonly aiAgents$ = this._aiAgentsSubject.asObservable();

    get aiAgents(): AIPersonDescriptionDto[] | undefined {
        return this._aiAgentsSubject.getValue();
    }

    private readonly _stream$ = merge(
        this.aiAgents$
    );

    constructor(
        private aiChatServiceProxy: AIChatServiceProxy) {

        this._stream$.subscribe();
    }

    initialize() {
        return this.getAvailableAssistant$()
            .pipe(
                tap((result: AIPersonDescriptionDto[]) => {
                    this.setAvailableAIAssistant(result);
                })
            );
    }

    getAvailableAssistant$(sessionId: string | undefined = undefined): Observable<AIPersonDescriptionDto[]> {
        return this.aiChatServiceProxy.getAvailableAssistant(sessionId);
    }

    //#region Actions

    setCurrentAIAssistant(agent: AIPersonDescriptionDto) {
        this._currentAIAssistantSubject.next(agent);
    }

    protected setAvailableAIAssistant(data: AIPersonDescriptionDto[]) {
        this._availableAIAssistantSubject.next(data);

        const active = data.find(a => a.isActive);
        if (active) {
            this.addAIAgent(active);
        }
    }

    // reorderByName(agentName: string) {
    //     const list = this.aiAgents; // current array
    //     const agent = list.find(a => a.name === agentName);
    //     const newOrder = this.reorderCurrentFirst(list, agent);
    //     this._aiAgentsSubject.next(newOrder);
    // }

    // private reorderCurrentFirst(
    //     list: AIPersonDescriptionDto[],
    //     current?: AIPersonDescriptionDto
    // ): AIPersonDescriptionDto[] {
    //     if (!current || list.length === 0) {
    //         return list;
    //     }
    //
    //     const currentId = current.id as any; // adjust key if needed
    //     const idx = list.findIndex(a => a.id === currentId);
    //     if (idx <= 0) {
    //         return list;
    //     } // already first or not found
    //
    //     // move the existing item to the front, keep others' order
    //     const currentItem = list[idx];
    //     return [currentItem, ...list.slice(0, idx), ...list.slice(idx + 1)];
    // }

    addAIAgent(agent: AIPersonDescriptionDto) {
        if (!agent) {
            return;  // do nothing if no agent
        }

        const list = this.aiAgents; // current array
        const exists = list.some(a => a.id === agent.id); // adjust key if needed

        if (exists) {
            return;  // do nothing if already present
        }

        this._aiAgentsSubject.next([agent, ...list]); // append immutably
    }

    addAIAgentByName(agentName: string) {
        if (!agentName) {
            return;  // do nothing if no agent
        }

        const list = this.availableAIAgents; // current array
        const exists = list.find(a => a.name === agentName); // adjust key if needed

        if (!exists) {
            return;  // do nothing if already present
        }

        this.addAIAgent(exists); // append immutably
    }

    // Helper to extract a stable unique key per agent
    private keyOf(a: AIPersonDescriptionDto): AgentId {
        // If your DTO uses another key, change here (e.g., a.guid, a.name, etc.)
        // @ts-ignore – assume 'id' exists on your DTO; adjust as needed
        return a.id as AgentId;
    }

    //#endregion Actions


}


