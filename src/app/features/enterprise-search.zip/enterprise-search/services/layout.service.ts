import {inject, Injectable, Injector} from '@angular/core';
import {BehaviorSubject, distinctUntilChanged, merge} from 'rxjs';

import {AgentId, MessageId, EsPanelId, EsPanelMode} from '@app/enterprise-search/shared/types';
import {AIChatMetricDto, AIChatServiceProxy, AIPersonDescriptionDto} from '@shared/service-proxies/service-proxies';
import {map, tap} from 'rxjs/operators';
import {Observable} from '@node_modules/rxjs';
import {EsPanel} from '@app/enterprise-search/shared/models';



@Injectable({
    providedIn: 'root'
})
export class AiLayoutService {

    panelMode: EsPanelMode = 'one';

    esPanels: EsPanel[] = [
        { id: 'ai',     visible: true },   // default main AI column
        { id: 'search-result', visible: false },
        { id: 'preview', visible: false }
    ];

    get visiblePanels(): EsPanel[] {
        return this.esPanels.filter(c => c.visible);
    }

    private readonly _stream$ = merge(

    );

    constructor(
        ) {

        this._stream$.subscribe();
    }

    showPanel(id: EsPanelId): void {
        this.setPanelVisibility(id, true);
    }

    hidePanel(id: EsPanelId): void {
        if (this.visiblePanels.length === 1 &&
            this.visiblePanels[0].id === id) {
            return;
        }

        this.setPanelVisibility(id, false);
    }

    toggleColumn(id: EsPanelId): void {
        const col = this.getPanel(id);
        if (!col) {
            return;
        }

        col.visible ? this.hidePanel(id) : this.showPanel(id);
    }

    showOnly(ids: EsPanelId[]): void {
        this.esPanels.forEach(c => {
            c.visible = ids.includes(c.id);
        });

        this.syncModeFromVisibility();
    }

    private setPanelVisibility(id: EsPanelId, visible: boolean): void {
        const col = this.getPanel(id);
        if (!col || col.visible === visible) {
            return;
        }

        col.visible = visible;
        this.syncModeFromVisibility();
    }

    private getPanel(id: EsPanelId): EsPanel | undefined {
        return this.esPanels.find(c => c.id === id);
    }

    setLayoutMode(mode: EsPanelMode) {
        this.panelMode = mode;

        switch (mode) {
            case 'one':
                // only AI column
                this.esPanels.forEach(c => c.visible = c.id === 'ai');
                break;

            case 'two':
                // AI + Search (for example)
                this.esPanels.forEach(c =>
                    c.visible = (c.id === 'ai' || c.id === 'search-result')
                );
                break;

            case 'three':
                // AI + Search + Preview
                this.esPanels.forEach(c => c.visible = true);
                break;
        }
    }

    /**
    * Close a panel by id, but ensure we close by its *visible index* so
    * the UI (which often renders visibleMidColumns with *ngFor index) stays aligned.
    */
    closePanel(id: EsPanelId): void {
        const visible = this.visiblePanels;

        // Find panel by id in the visible list (this yields the "tab index" currently shown in UI)
        const visibleIndex = visible.findIndex(c => c.id === id);
        if (visibleIndex === -1) {
            // already hidden or unknown
            return;
        }

        // Do not allow closing the last visible column
        if (visible.length === 1) {
            return;
        }

        const toCloseId = visible[visibleIndex].id;

        // Hide it in the source array
        const col = this.esPanels.find(c => c.id === toCloseId);
        if (col) {
            col.visible = false;
        }

        // Recompute layout mode based on remaining visible columns
        this.syncModeFromVisibility();
    }

    private syncModeFromVisibility(): void {
        const count = this.visiblePanels.length;

        if (count <= 1) {
            this.panelMode = 'one';
        } else if (count === 2) {
            this.panelMode = 'two';
        } else {
            this.panelMode = 'three';
        }
    }
}


