import {inject, Injectable} from '@angular/core';
import {BehaviorSubject, distinctUntilChanged, merge} from 'rxjs';
import {map, shareReplay, tap} from 'rxjs/operators';
import { AgentId } from '@app/enterprise-search/shared/types';
import {AIChatMetricDto, AIPersonDescriptionDto} from '@shared/service-proxies/service-proxies';
import {AIAgentMetric, AIAgentMetricSummary} from '@app/enterprise-search/shared/models';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';
import _, {cloneDeep} from 'lodash';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';

@Injectable({ providedIn: 'root' })
export class AIChatMetricsService {

    private readonly _metricSummarySubject: BehaviorSubject<AIAgentMetricSummary> = new BehaviorSubject<AIAgentMetricSummary | undefined>(undefined);
    readonly metricSummary$ = this._metricSummarySubject.asObservable()
        .pipe(
            distinctUntilChanged(),
            shareReplay(1)
        );

    get metricSummary(): AIAgentMetricSummary | undefined {
        return this._metricSummarySubject.getValue();
    }

    private readonly _metricsSubject = new BehaviorSubject<AIChatMetricDto[]>([]);
    readonly _metrics$ = this._metricsSubject.asObservable()
        .pipe(
            distinctUntilChanged(),
            shareReplay(1)
        );

    private _defaultMetricSummary: AIAgentMetricSummary;

    // inject metrics service
    private readonly aiAgentsService = inject(AiAgentsService);
    private readonly aiChatService = inject(ReactiveAIChatService);

    readonly current$ = this.aiAgentsService.aiAgents$
        .pipe(
            tap((agents: AIPersonDescriptionDto[]) => {
                this.init(agents);
            })
        );

    constructor() {

        const _stream$ = merge(
            this._metrics$,
            this.current$
        ).subscribe();
    }

    updateMetrics(metrics: AIChatMetricDto[]) {
        this._metricsSubject.next(metrics);
        console.log('updateMetrics', metrics);
        this._updateMetricByAgent(metrics);
    }

    private _updateMetricByAgent(metrics: AIChatMetricDto[]) {
        let summary = cloneDeep(this.metricSummary);

        _.each(metrics, (metric) => {
            const agentMetric = summary.agentMetrics.find(item => item.agent.id === metric.aiAgentId);
            agentMetric.metric = metric;
        });

        this._metricSummarySubject.next(summary);
    }

    private resetIndicator(metric: AIChatMetricDto) {
        //this.aiChatService.hideIndicator()
    }

    resetMetrics() {
        this._metricSummarySubject.next(undefined);
    }

    init(agents: AIPersonDescriptionDto[]) {
        let summary = cloneDeep(this.metricSummary);

        if (!summary) {
            summary = {
                sessionId: undefined,
                agentMetrics: _.map(agents, (agent) => {
                    return {
                            agent: agent,
                            metric: undefined
                    } as AIAgentMetric;
                })
            };

            this._metricSummarySubject.next(summary);
            return;
        }

        const agentIds = this.getAgentsIds();
        const notExisting = _.filter(agents, (agent) => !agentIds.includes(agent.id));

        _.each(notExisting, (agent) => {
            summary.agentMetrics.push(
                {
                    agent: agent,
                    metric: undefined
                } as AIAgentMetric
            );
        });

        this._metricSummarySubject.next(summary);
    }

    private getAgentsIds(): string[] {
        return _.map(this.metricSummary.agentMetrics, items => items.agent.id);
    }

}
