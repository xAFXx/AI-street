import {Injectable, Injector} from '@angular/core';

import {take, tap, takeUntil} from 'rxjs/operators';
import {BehaviorSubject, Observable} from 'rxjs';

import * as _ from 'lodash';
import {SearchResultType, SearchResult, CustomHistoryItem} from '../shared/models';
import {
    EnterpriseSearchDataToElasticModelDto,
    EnterpriseSearchItemsInputDto,
    EnterpriseSearchMetadataDto,
    EnterpriseSearchServiceProxy,
    IEnterpriseSearchDataToElasticModelDto,
    IEnterpriseSearchItemsInputDto,
    PreviewItemOutputDto,
    SearchResultDto,
    TimelineDto
} from '@shared/service-proxies/service-proxies';
import {PermissionCheckerService} from 'abp-ng2-module';
import {EsDataViewService} from '@app/enterprise-search/services/es-data-view.service';
import moment from 'moment';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Injectable({
    providedIn: 'root'
})
export class EsHistoryService {
    private _historyMode$: BehaviorSubject<'life' | 'historySearch' | 'history' | undefined>;

    private _imageDescription$: BehaviorSubject<string | undefined>;

    private _isHistoryModeSearch$: BehaviorSubject<boolean>;
    private _selectedMetadata$: BehaviorSubject<CustomHistoryItem>;
    private _metadata$: BehaviorSubject<CustomHistoryItem[]>;

    private _searchId$: BehaviorSubject<string | undefined>;

    private _isRequiredToCheckLastEntry$: BehaviorSubject<boolean>;

    protected enterpriseSearchServiceProxy: EnterpriseSearchServiceProxy;
    protected esDataViewService: EsDataViewService;


    private _showPreviewSubject = new BehaviorSubject<boolean>(false);
    showPreview$ = this._showPreviewSubject.asObservable();

    constructor(injector: Injector) {
        this.enterpriseSearchServiceProxy = injector.get(EnterpriseSearchServiceProxy);
        this.esDataViewService = injector.get(EsDataViewService);

        this.initialization();
    }

    private initialization() {
        this._historyMode$ = new BehaviorSubject<'life' | 'historySearch' | 'history'>('life');

        this._imageDescription$ = new BehaviorSubject<string | undefined>(undefined);
        this._searchId$ = new BehaviorSubject<string | undefined>(undefined);

        this._metadata$ = new BehaviorSubject<CustomHistoryItem[]>([]);
        this._selectedMetadata$ = new BehaviorSubject<CustomHistoryItem>(undefined);
        this._isHistoryModeSearch$ = new BehaviorSubject<boolean>(false);

        this._isRequiredToCheckLastEntry$ = new BehaviorSubject<boolean>(false);
    }

    flush() {
        this.resetMetadata();
        this._resetHistoryModeSearch();
        this.resetHistoryMode();
        this._resetRequiredToCheckLastEntry();
        this.resetImageDescription();
    }

    //#region imageDescription
    get imageDescription$(): Observable<string | undefined> {
        return this._imageDescription$.asObservable();
    }
    get imageDescription(): string | undefined {
        return this._imageDescription$.getValue();
    }
    protected setImageDescription(value: string | undefined) {
        this._imageDescription$.next(value);
    }
    resetImageDescription() {
        this.setImageDescription(undefined);
    }

    private _initializeImageDescription(result: EnterpriseSearchMetadataDto) {
        this.setImageDescription(result.searchDescription);
    }
    //#endregion

    //#region Search ID
    get searchId$(): Observable<string | undefined> {
        return this._searchId$.asObservable();
    }
    get searchId(): string | undefined {
        return this._searchId$.getValue();
    }
    setSearchId(id: string | undefined, withPreview: boolean = false) {
        this._searchId$.next(id);
        this.setShowPreview(withPreview);
    }

    setShowPreview(withPreview: boolean) {
        if (withPreview) {
            this._showPreviewSubject.next(withPreview);
        }
    }
    //#endregion Search ID

    //#region isRequiredToCheckLastEntry
    get isRequiredToCheckLastEntry$(): Observable<boolean> {
        return this._isRequiredToCheckLastEntry$.asObservable();
    }
    get isRequiredToCheckLastEntry(): boolean {
        return this._isRequiredToCheckLastEntry$.getValue();
    }
    setRequiredToCheckLastEntry(value: boolean) {
        this._isRequiredToCheckLastEntry$.next(value);
    }
    private _resetRequiredToCheckLastEntry() {
        this._isRequiredToCheckLastEntry$.next(false);
    }
    //#endregion

    //#region HistoryMode
    get historyMode$(): Observable<'life' | 'historySearch' | 'history'> {
        return this._historyMode$.asObservable();
    }
    get historyMode(): 'life' | 'historySearch' | 'history' {
        return this._historyMode$.getValue();
    }
    private _setHistoryMode(mode: 'life' | 'historySearch' | 'history') {
        this._historyMode$.next(mode);
    }
    enableHistoryMode() {
        this._setHistoryMode('history');
        // reset required to check last entry
        //this.setRequiredToCheckLastEntry(true);
    }
    enableHistorySearchMode() {
        this._setHistoryMode('historySearch');
    }
    enableLifeMode(checkLastEntry: boolean = false) {
        this._setHistoryMode('life');
        this.disableHistoryModeSearch();
        if (checkLastEntry) {
            // reset required to check last entry
            this.setRequiredToCheckLastEntry(true);
        }
    }
    resetHistoryMode() {
        this.enableLifeMode(false);
    }
    //#endregion HistoryMode

    //#region Metadata
    resetPointerPosition() {
        let newMetadata = _.cloneDeep(this.metadata) as CustomHistoryItem[];
        newMetadata = this._shuffle(newMetadata);
        this._metadata$.next(newMetadata);
    }

    setMetadata(result: EnterpriseSearchMetadataDto) {
        let metadata = this.metadata;

        if (result && metadata.length === 0) {
            this._addPointerAtCorrectPosition(undefined);
        }

        if (result.visualSearch) {
            this._initializeImageDescription(result);
        }

        let newMetadata = _.cloneDeep(metadata) as CustomHistoryItem[];
        newMetadata.unshift(result as CustomHistoryItem);
        if (!this.isHistoryModeSearch) {
            newMetadata = this._shuffle(newMetadata);
        }

        this._metadata$.next(newMetadata);
    }

    private _shuffle(metaData: CustomHistoryItem[]): CustomHistoryItem[] {
        const pointerItems = metaData.filter(item => item?.isPointer);
        const otherItems = metaData.filter(item => !item?.isPointer);
        otherItems.unshift(pointerItems[0]);
        return otherItems;
    }

    get metadata$(): Observable<CustomHistoryItem[]> {
        return this._metadata$.asObservable();
    }
    get metadata(): CustomHistoryItem[] {
        return this._metadata$.getValue();
    }

    resetAllMetadata() {
        this._metadata$.next([]);
    }

    get isHistoryModeSearch$(): Observable<boolean> {
        return this._isHistoryModeSearch$.asObservable();
    }
    get isHistoryModeSearch(): boolean {
        return this._isHistoryModeSearch$.getValue();
    }
    private _resetHistoryModeSearch() {
        this._isHistoryModeSearch$.next(false);
    }
    enableHistoryModeSearch() {
        this._isHistoryModeSearch$.next(true);
    }
    disableHistoryModeSearch() {
        this._isHistoryModeSearch$.next(false);
    }

    // Method to simulate selecting an item and adding the pointer
    setCurrentMetadata(data: CustomHistoryItem | undefined, fixPointer: boolean = false) {
        this._selectedMetadata$.next(data);

        if (fixPointer) {
            this._addPointerAtCorrectPosition(data);
        }

        if (data) {
            this.enableHistoryModeSearch();
            this.enableHistoryMode();
        } else {
            this.disableHistoryModeSearch();
            this.resetHistoryMode();
        }
    }

    get selectedMetadata$(): Observable<CustomHistoryItem> {
        return this._selectedMetadata$.asObservable();
    }
    get selectedMetadata(): CustomHistoryItem {
        return this._selectedMetadata$.getValue();
    }

    resetCurrentMetadata() {
        this.setCurrentMetadata(undefined);
    }

    resetMetadata() {
        this.resetCurrentMetadata();
        this.resetAllMetadata();
    }

    // Method to add pointer at the correct position
    private _addPointerAtCorrectPosition(selectedItem: CustomHistoryItem | undefined) {
        if (selectedItem === undefined) {
            this.metadata.splice(0, 0, { isPointer: true } as CustomHistoryItem);
        }

        // Remove the pointer from the array if it exists
        const pointerIndex = this.metadata.findIndex(item => item.isPointer);
        if (pointerIndex !== -1) {
            this.metadata.splice(pointerIndex, 1);
        }

        // Find the index of the selected item
        const selectedIndex = this.metadata.findIndex(item => item.searchId === selectedItem.searchId);

        // Add pointer after the selected item if it's not at the last position
        if (selectedIndex !== -1 && selectedIndex < this.metadata.length - 1) {
            // Insert the pointer after the selected item
            this.metadata.splice(selectedIndex, 0, { isPointer: true } as CustomHistoryItem);
        // If selected item is at the last position, move pointer before it
        } else if (selectedIndex === this.metadata.length - 1) {
            this.metadata.splice(this.metadata.length - 1, 0, { isPointer: true } as CustomHistoryItem);
        }
    }

    drop(event: CdkDragDrop<CustomHistoryItem[]>) {
        // Check if the pointer is being moved to the last position
        const pointerIndex = this.metadata.findIndex(item => item.isPointer);
        const lastIndex = this.metadata.length - 1;

        // If the pointer is being dropped at the last position, move it to the previous position
        if (event.currentIndex === lastIndex && pointerIndex !== lastIndex) {
            moveItemInArray(this.metadata, pointerIndex, lastIndex - 1);
        } else {
            moveItemInArray(this.metadata, event.previousIndex, event.currentIndex);
        }

        // Select the next item after the pointer
        //TODO: check if next not selected than select
        //this._selectNextItem();
    }

    // Move the pointer to the next position
    movePointerNext() {
        const pointerIndex = this.metadata.findIndex(item => item.isPointer);
        const lastIndex = this.metadata.length - 1;

        // Only move pointer if it's not already at the second-to-last position
        if (pointerIndex < lastIndex - 1) {
            moveItemInArray(this.metadata, pointerIndex, pointerIndex + 1);
        }
        // Select the next item after the pointer
        this._selectNextItem();
    }

    // Move the pointer to the previous position
    movePointerPrevious() {
        const pointerIndex = this.metadata.findIndex(item => item.isPointer);

        // Only move pointer if it's not already at the first position
        if (pointerIndex > 0) {
            moveItemInArray(this.metadata, pointerIndex, pointerIndex - 1);
        }
        // Select the next item after the pointer
        this._selectNextItem();
    }

    // Select the next item after the pointer
    private _selectNextItem() {
        const pointerIndex = this.metadata.findIndex(item => item.isPointer);

        // Make sure the pointer is not at the last position
        if (pointerIndex < this.metadata.length - 1) {
            this.setCurrentMetadata(this.metadata[pointerIndex + 1]);
        }
    }



    //#endregion Metadata

}

