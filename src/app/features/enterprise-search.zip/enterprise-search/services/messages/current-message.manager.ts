import {Injectable, Injector} from '@angular/core';
import {BehaviorSubject, merge } from 'rxjs';

import {MessageId} from '@app/enterprise-search/shared/types';
import {AIPersonDescriptionDto} from '@shared/service-proxies/service-proxies';

@Injectable({
    providedIn: 'root'
})
export class CurrentMessageManager {

    private readonly _currentAIAssistantSubject: BehaviorSubject<AIPersonDescriptionDto> = new BehaviorSubject<AIPersonDescriptionDto | undefined>(undefined);
    readonly currentAIAssistant$ = this._currentAIAssistantSubject.asObservable();

    get currentAIAssistant(): AIPersonDescriptionDto | undefined {
        return this._currentAIAssistantSubject.getValue();
    }

    private readonly _lastMessageIdSubject = new BehaviorSubject<MessageId | undefined>(undefined);
    readonly lastMessageId$ = this._lastMessageIdSubject.asObservable();

    get lastMessageId(): MessageId | undefined {
        return this._lastMessageIdSubject.getValue();
    }
    private readonly _currentMessageIdSubject = new BehaviorSubject<MessageId | undefined>(undefined);
    readonly currentMessageId$ = this._currentMessageIdSubject.asObservable();

    get currentMessageId(): MessageId | undefined {
        return this._currentMessageIdSubject.getValue();
    }

    private readonly _currentSharedMessageIdSubject = new BehaviorSubject<MessageId | undefined>(undefined);
    readonly currentSharedMessageId$ = this._currentSharedMessageIdSubject.asObservable();

    get currentSharedMessageId(): MessageId | undefined {
        return this._currentSharedMessageIdSubject.getValue();
    }

    private readonly _stream$ = merge(
        this.currentMessageId$
        , this.currentAIAssistant$
    );

    constructor() {
        this._stream$.subscribe();
    }

    //#region Actions
    /** Reset currentMessageId if it's already set */
    resetCurrentMessageIdIfSet(): void {
        if (!this.isCurrentMessageIdNotSet()) {
            this.resetCurrentMessageId();
        }
    }

    setCurrentMessageIdIfNotSet(value: string): void {
        if (this.isCurrentMessageIdNotSet()) {
            this.setCurrentMessageId(value);
        }
    }
    setCurrentSharedMessageIdIfNotSet(value: string): void {
        if (this.isCurrentSharedMessageIdNotSet()) {
            this.setCurrentSharedMessageId(value);
        }
    }

    //#region Current AI Assistant
    setCurrentAIAssistant(person: AIPersonDescriptionDto) {
        this._currentAIAssistantSubject.next(person);
    }
    //#endregion Current AI Assistant

    //#region Current Message ID
    initCurrentMessageId(value: string | MessageId): void {
        this.setCurrentMessageId(value);
    }
    resetCurrentMessageId(): void {
        this.setLastMessageId(this.currentMessageId);
        this.setCurrentMessageId(undefined);
    }
    isCurrentMessageIdNotSet(): boolean {
        return this.currentMessageId === null || this.currentMessageId === undefined;
    }
    protected setCurrentMessageId(value: MessageId | string | undefined): void {
        this._currentMessageIdSubject.next(value);
        console.log(`%cCURRENT MESSAGE ID - ${value}`, 'color: orange;');
    }
    //#endregion Current Message ID

    //#region Last Message ID
    resetLastMessageId(): void {
        this.setLastMessageId(undefined);
    }
    isLastMessageIdNotSet(): boolean {
        return this.lastMessageId === null || this.lastMessageId === undefined;
    }
    protected setLastMessageId(value: MessageId | string | undefined): void {
        this._lastMessageIdSubject.next(value);
        console.log(`%cLAST MESSAGE ID - ${value}`, 'color: pink;');
    }
    //#endregion Last Message ID

    //#region Current Shared Message ID
    initCurrentSharedMessageId(value: string): void {
        this.setCurrentSharedMessageId(value);
    }
    resetCurrentSharedMessageId(): void {
        this.setCurrentSharedMessageId(undefined);
    }
    isCurrentSharedMessageIdNotSet(): boolean {
        return this.currentSharedMessageId === null || this.currentSharedMessageId === undefined;
    }
    protected setCurrentSharedMessageId(value: string | undefined): void {
        this._currentSharedMessageIdSubject.next(value);
    }
    //#endregion Current Shared Message ID

    //#endregion Actions

}


