import { Injectable, Injector, NgZone } from '@angular/core';
import { AppComponentBase } from '@axilla/axilla-shared';
import { HubConnection } from '@microsoft/signalr';
import {
    AIChatMessageDto, AIChatMessageReadyDto,
    AIChatMetricDto,
    AISessionDto,
    IAIChatMessageDto,
    IChatMessageDto
} from '@shared/service-proxies/service-proxies';
import {BehaviorSubject, Observable} from 'rxjs';
import { ChatConnectionState } from '../shared/models';

@Injectable({
    providedIn: 'root'
})
export class AIChatSignalrService extends AppComponentBase {

    private _connectionState$ = new BehaviorSubject<ChatConnectionState>(ChatConnectionState.Disconnected);
    public connectionState$: Observable<ChatConnectionState> = this._connectionState$.asObservable();

    constructor(
        injector: Injector,
        public _zone: NgZone
    ) {
        super(injector);
    }

    chatHub: HubConnection;
    isChatConnected = false;

    private setConnectionState(state: ChatConnectionState) {
        this._connectionState$.next(state);
    }

    configureConnection(connection): void {
        // Set the common hub
        this.chatHub = connection;

        // Reconnect loop
        let reconnectTime = 5000;
        let tries = 1;
        let maxTries = 8;

        const start = () => {
            this.setConnectionState(ChatConnectionState.Connecting);
            return new Promise<void>((resolve, reject) => {
                if (tries > maxTries) {
                    this.setConnectionState(ChatConnectionState.Disconnected);
                    reject();
                } else {
                    connection.start()
                        .then(() => {
                            this.setConnectionState(ChatConnectionState.Connected);
                            reconnectTime = 5000;
                            tries = 1;
                            resolve();
                        })
                        .catch(() => {
                            this.setConnectionState(ChatConnectionState.Reconnecting);
                            setTimeout(() => {
                                start().then(resolve);
                            }, reconnectTime);
                            reconnectTime *= 2;
                            tries += 1;
                        });
                }
            });
        };

        // Reconnect if hub disconnects
        connection.onclose(e => {
            this.isChatConnected = false;
            this.setConnectionState(ChatConnectionState.Disconnected);
            this.unregisterChatEvents(connection);

            if (e) {
                abp.log.debug('Chat connection closed with error: ' + e);
            } else {
                abp.log.debug('Chat disconnected');
            }

            start().then(() => {
                this.isChatConnected = true;
            });
        });

        // Register to get notifications
        this.registerChatEvents(connection);
    }

    registerChatEvents(connection): void {
        connection.on('getAIChatMessage', this.onMessage);
        connection.on('hideIndicator', this.onHideIndicator);
        connection.on('updateAIChatMetric', this.onMetricUpdate);
        connection.on('updateSessions', this.onUpdateSessions);
    }

    unregisterChatEvents(connection): void {
        connection.off('getAIChatMessage', this.onMessage);
        connection.off('hideIndicator', this.onHideIndicator);
        connection.off('updateAIChatMetric', this.onMetricUpdate);
        connection.off('updateSessions', this.onUpdateSessions);
    }

    private onMessage = (message: AIChatMessageDto) => {
        abp.event.trigger('app.aichat.messageReceived', message);
    };

    private onHideIndicator = (input: AIChatMessageReadyDto) => {
        abp.event.trigger('app.aichat.hideIndicator', input);
    };

    private onMetricUpdate = (metrics: AIChatMetricDto[]) => {
        abp.event.trigger('app.aichat.chatMetricUpdate', metrics);
    };

    private onUpdateSessions = (sessions: AISessionDto[]) => {
        abp.event.trigger('app.aichat.updateSessions', sessions);
    };

    sendMessage(messageData, callback): void {
        if (!this.isChatConnected) {
            if (callback) {
                callback();
            }

            abp.notify.warn(this.l('ChatIsNotConnectedWarning'));
            return;
        }

        this.chatHub.invoke('sendMessage', messageData).then(result => {
            if (result) {
                abp.notify.warn(result);
            }

            if (callback) {
                callback();
            }
        }).catch(error => {
            abp.log.error(error);

            if (callback) {
                callback();
            }
        });
    }

    init(): void {
        this._zone.runOutsideAngular(() => {
            this.setConnectionState(ChatConnectionState.Connecting);
            abp.signalr.connect();
            abp.signalr.startConnection(abp.appPath + 'signalr-aichat', connection => {
                this.configureConnection(connection);
            }).then(() => {
                abp.event.trigger('app.chat.connected');
                this.isChatConnected = true;
                this.setConnectionState(ChatConnectionState.Connected);
            }).catch(() => {
                this.isChatConnected = false;
                this.setConnectionState(ChatConnectionState.Disconnected);

                if (location.pathname === '/app/enterprise-search') {
                    let message = this.ls('Axilla', 'Axilla.Apps.AI.Chat.NotConnectedMessage');
                    let title = this.ls('Axilla', 'Axilla.Apps.AI.Chat.NotConnectedTitle');

                    abp.message.confirm(message, title
                        , (state) => {
                            if (state) {
                                location.reload();
                            }
                        });
                }
            });
        });
    }

}
