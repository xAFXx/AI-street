// ai-sessions.service.ts
import {inject, Injectable} from '@angular/core';
import { Location } from '@angular/common';
import {BehaviorSubject, Observable, combineLatest, merge, of, withLatestFrom} from 'rxjs';
import {tap, map, distinctUntilChanged, shareReplay, filter, switchMap, catchError, take} from 'rxjs/operators';
import dayjs from 'dayjs';
import { Router, ActivatedRoute } from '@angular/router';
import {
    AIChatServiceProxy,
    PagedResultDtoOfAISessionDto,
    AISessionDto, ListResultDtoOfAIChatMessageDto, AIChatMessageDto, ChatSide, AIChatMessageType
} from '@shared/service-proxies/service-proxies';
import {AIChatEvents, AIChatMessage, ExtendedAIChatMessageDto} from '@app/enterprise-search/shared/models';
import {ChatMessagesStore} from '@app/enterprise-search/shared/store/ai-message.store';
import {convertMessage} from '@app/enterprise-search/shared/helpers/helpers';
import {SessionId} from '@app/enterprise-search/shared/types';


export interface MessagesState {
    loading: boolean;
    error?: unknown;
    data: ListResultDtoOfAIChatMessageDto | null;
}

@Injectable({ providedIn: 'root' })
export class AiSessionsService {
    //#region Sessions
    private readonly _sessionsSubject = new BehaviorSubject<AISessionDto[]>([]);
    private readonly _sessions$ = this._sessionsSubject.asObservable();

    // Track currently selected session by ID
    private readonly _currentSessionIdSubject = new BehaviorSubject<SessionId | null>(null);
    readonly currentSessionId$ = this._currentSessionIdSubject.asObservable();

    // Derive the current session based on selected ID
    readonly currentSession$ = combineLatest([
        this._sessions$,
        this.currentSessionId$
    ]).pipe(
        map(([sessions, currentId]) => sessions.find(s => s.sessionId === currentId) ?? null),
        distinctUntilChanged()
    );

    /** Snapshot helpers */
    get currentSessionId(): SessionId | null { return this._currentSessionIdSubject.getValue(); }
    get sessionsSnapshot(): AISessionDto[] { return this._sessionsSubject.getValue(); }
    get currentSessionSnapshot(): AISessionDto | null {
        const id = this.currentSessionId;
        return id ? this.sessionsSnapshot.find(s => s.sessionId === id) ?? null : null;
    }
    //#endregion Sessions

    /** All sessions observable (public) */
    readonly sessions$: Observable<AISessionDto[]> = this._sessions$.pipe(shareReplay(1));

    /** Sessions with pinned first, then by updatedAt desc */
    readonly sortedSessions$ = this._sessions$.pipe(
        map(list =>
            [...list].sort((a, b) => {
                if (a.pinned !== b.pinned) {
                    return a.pinned ? -1 : 1;
                }
                return b.lastModificationTime.valueOf() - a.lastModificationTime.valueOf();
            })
        ),
        shareReplay(1)
    );

    /** Emits whenever selected session changes AND that session exists in the list */
    readonly selectedValidSessionId$ = combineLatest([
        this.currentSessionId$,
        this.sessions$
    ]).pipe(
        map(([id, list]) => {
            if (!id) {
                return null;
            }
            return list.some(s => s.sessionId === id) ? id : null;
        }),
        filter((id): id is string => !!id),
        distinctUntilChanged()
    );

    private readonly suppressNextSessionIdSubject = new BehaviorSubject<SessionId | null>(null);
    readonly suppressNextSessionId$ = this.suppressNextSessionIdSubject.asObservable();

    // Use the gated stream to connect
    private readonly reactableSessionId$ = this.currentSessionId$.pipe(
        filter((id): id is string => !!id),
        withLatestFrom(this.suppressNextSessionId$),      // get the one-shot mute
        filter(([id, muted]) => id !== muted),                   // drop the muted id
        map(([id]) => id),
        tap(() => this.suppressNextSessionIdSubject.next(null)),   // reset the mute after use
        distinctUntilChanged()
    );

    private location = inject(Location);

    constructor(
        private aiChatServiceProxy: AIChatServiceProxy,
        private router: Router,
        private route: ActivatedRoute,
        private messageStore: ChatMessagesStore
    ) {

        merge(
            this.currentSession$,
            this._sessions$,
            //this.messagesFromSession$
        )
        .subscribe();

        // Start reacting to session changes
        this.messageStore.connectToSession(this.reactableSessionId$);
    }

    initialize() {
        return this.getAllSession$();
    }

    private getAllSession$() {
        return this.aiChatServiceProxy.getAllSession(100, 0)
            .pipe(
                tap((result: PagedResultDtoOfAISessionDto) => {
                    const sessions = result?.items ?? [];

                    if (sessions.length > 0) {
                        this._sessionsSubject.next(sessions);
                    }
                })
            );
    }

    refreshSessionList() {
        this.getAllSession$()
            .pipe(
                take(1)
            )
            .subscribe();
    }

    createNewSession() {
        this.messageStore.startNewSession();
    }

    getMessages() {
        const sessionId = this.currentSessionId as string;

        return this.aiChatServiceProxy.getUserChatHistoryMessages(
            sessionId, 100, 0
        )
        .pipe(
            tap()
        );
    }

    private checkIfSessionAlreadyExist(sessionId: string) {
        return this.sessionsSnapshot.find(a => a.sessionId === sessionId);
    }

    /** Add (or upsert) an incoming session and select it */
    updateSessions(
        incoming: AISessionDto,
        opts?: { updateUrl?: boolean; replaceUrl?: boolean; silent?: boolean }
    ): void {
        const { updateUrl = true, replaceUrl = true, silent = false } = opts ?? {};

        const prev = this.sessionsSnapshot;
        if (this.checkIfSessionAlreadyExist(incoming.sessionId)) {
            return;
        }
        prev.push(incoming);

        this._commit(prev);

        this.selectSession(incoming.sessionId, silent);

        // sync URL
        if (updateUrl) {
            this.setSessionIdInUrl(incoming.sessionId, replaceUrl);
        }
    }

    /** Select a session by id (returns false if not found) */
    selectSession(id: SessionId, silent?: boolean): boolean {
        if (silent) {
            this.suppressNextSessionIdSubject.next(id);
            this.messageStore.startNewSession(id);
        }

        const exists = this._sessionsSubject.getValue().some(s => s.sessionId === id);
        if (!exists) {
            return false;
        }
        if (this.currentSessionId !== id) {
            this._currentSessionIdSubject.next(id);
        }
        return true;
    }

    /** Rename a session */
    renameSession(id: string, sessionName: string): void {
        this.updateSession(id, { sessionName, lastModificationTime: dayjs() });
    }

    /** Delete a session; if currently selected, switch to a sensible neighbor or create a new one */
    private _deleteSession(id: string): void {
        const sessions = this._sessionsSubject.getValue();
        const idx = sessions.findIndex(s => s.sessionId === id);
        if (idx < 0) {
            return;
        }

        const next = sessions.filter(s => s.sessionId !== id);
        this._commit(next);

        const currentId = this._currentSessionIdSubject.getValue();
        if (currentId === id) {
            this._currentSessionIdSubject.next(undefined);
            this.messageStore.startNewSession();
        }
    }

     deleteSession(id: string) {
        return this.aiChatServiceProxy.deleteSession(id)
            .pipe(
                take(1),
                tap(() => {
                    this._deleteSession(id);
                    this.clearSelectionAndResetUrl(true);
                })
            );
    }

    /** Pin/unpin */
    setPinned(id: string, pinned: boolean): void {
        this.updateSession(id, { pinned, lastModificationTime: dayjs() });
    }

    /** Archive/unarchive */
    setArchived(id: string, archived: boolean): void {
        this.updateSession(id, { archived, lastModificationTime: dayjs() });
    }

    /** Mark session as read (zero unread) */
    markRead(id: string): void {
        this.updateSession(id, { unreadCount: 0, lastModificationTime: dayjs() });
    }

    /** Increment unread count (use negative to decrement safely) */
    incrementUnread(id: string, by = 1): void {
        const sessions = this._sessionsSubject.getValue();
        const s = sessions.find(x => x.sessionId === id);
        if (!s) {
            return;
        }
        const unread = Math.max(0, s.unreadCount + by);
        this.updateSession(id, { unreadCount: unread });
    }

    /** Touch lastMessageAt and updatedAt */
    touchActivity(id: string, at: dayjs.Dayjs = dayjs()): void {
        this.updateSession(id, { lastMessageAt: at, lastModificationTime: at });
    }

    /** Replace all sessions (e.g., after loading from backend) */
    setSessions(sessions: AISessionDto[]): void {
        this._commit([...sessions]);
    }

    /** Upsert a batch (merge by id) */
    upsertSessions(sessions: AISessionDto[]): void {
        const map = new Map(this._sessionsSubject.getValue().map(s => [s.sessionId, s]));
        sessions.forEach(s => map.set(s.sessionId, { ...map.get(s.sessionId), ...s, lastModificationTime: s.lastModificationTime ?? dayjs() } as any));
        this._commit([...map.values()]);
    }

    setSessionIdInUrl(sessionId: string, replace = true) {
        const safeId = encodeURIComponent(sessionId);
        const url = `/app/enterprise-search/${safeId}`;

        replace ? this.location.replaceState(url) : this.location.go(url);
    }

    navigateToSession(sessionId: string) {
        const safeId = encodeURIComponent(sessionId);
        this.router.navigate(['../', safeId], {
            relativeTo: this.route,
            replaceUrl: true, // don’t clutter history
        });
    }

    /** Reset the browser URL to /app/enterprise-search (no session segment). */
    resetUrlToRoot(replace = true): void {
        const base = '/app/enterprise-search';
        replace ? this.location.replaceState(base) : this.location.go(base);
    }

    /** Optional: also clear the selected session, then reset URL. */
    clearSelectionAndResetUrl(replace = true): void {
        this._currentSessionIdSubject.next(null);
        this.resetUrlToRoot(replace);
    }

    private updateSession(id: string, patch: Partial<AISessionDto>): void {
        const next = this._sessionsSubject.getValue().map(s =>
            s.sessionId === id ? { ...s, ...patch } : s
        );
        this._commit(next as any);
    }

    clear() {
        this.clearSelectionAndResetUrl(true);
        this.messageStore.startNewSession();
    }

    private _commit(next: AISessionDto[]): void {
        this._sessionsSubject.next(next);
    }
}
