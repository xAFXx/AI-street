import {Injectable, Injector} from '@angular/core';

import {take, tap, takeUntil} from 'rxjs/operators';
import {BehaviorSubject, Observable, of} from 'rxjs';

import * as _ from 'lodash';
import {SearchResultType, SearchResult} from '../shared/models';
import {
    DocumentCountDto,
    EnterpriseSearchDataToElasticModelDto,
    EnterpriseSearchServiceProxy,
    PagedResultDtoOfPreviewDocumentOutputDto,
    PreviewDocumentOutputDto,
    PreviewItemOutputDto,
    RelatedDocumentTypes,
    SearchResultDto,
} from '@shared/service-proxies/service-proxies';
import {EsDataViewService} from '@app/enterprise-search/services/es-data-view.service';
import {EsBaseService} from '@app/enterprise-search/services/es-base-service';

@Injectable({
    providedIn: 'root'
})
export class EsPreviewService extends EsBaseService {
    private _previewDocumentsSubject = new BehaviorSubject<PreviewDocumentOutputDto[] | undefined>([]);

    private _previewMode$: BehaviorSubject<'attachment' | 'self' | undefined>;
    private _isShowPreviewLoader$: BehaviorSubject<boolean>;
    private _previewOrigin$: BehaviorSubject<EnterpriseSearchDataToElasticModelDto>;
    private _isPreviewAvailable$: BehaviorSubject<boolean>;
    private _previewItem$: BehaviorSubject<PreviewItemOutputDto>;
    private _isShowPreviewItem$: BehaviorSubject<boolean>;
    private _isPreviewItemLoading$: BehaviorSubject<boolean>;

    private _isShowPreviewAttachments$: BehaviorSubject<boolean>;
    private _isPreviewAttachmentsLoading$: BehaviorSubject<boolean>;

    private _totalAttachmentsCount$: BehaviorSubject<number>;
    private _attachments$: BehaviorSubject<EnterpriseSearchDataToElasticModelDto[]>;
    private _selectedAttachmentType$: BehaviorSubject<DocumentCountDto>;
    private _selectedAttachment$: BehaviorSubject<EnterpriseSearchDataToElasticModelDto>;

    constructor(injector: Injector) {
        super(injector);

        this.initialization();
    }

    private initialization() {
        this._previewMode$ = new BehaviorSubject<'attachment' | 'self' | undefined>(undefined);
        this._isPreviewAvailable$ = new BehaviorSubject<boolean>(false);
        this._previewOrigin$ = new BehaviorSubject<EnterpriseSearchDataToElasticModelDto>(undefined);
        this._isShowPreviewLoader$ = new BehaviorSubject<boolean>(false);
        this._previewItem$ = new BehaviorSubject<PreviewItemOutputDto>(undefined);
        this._isShowPreviewItem$ = new BehaviorSubject<boolean>(false);
        this._isPreviewItemLoading$ = new BehaviorSubject<boolean>(false);
        this._isShowPreviewAttachments$ = new BehaviorSubject<boolean>(false);
        this._isPreviewAttachmentsLoading$ = new BehaviorSubject<boolean>(false);

        this._attachments$ = new BehaviorSubject<EnterpriseSearchDataToElasticModelDto[]>(undefined);
        this._selectedAttachment$ = new BehaviorSubject<EnterpriseSearchDataToElasticModelDto>(undefined);
        this._totalAttachmentsCount$ = new BehaviorSubject<number>(0);
        this._selectedAttachmentType$ = new BehaviorSubject<DocumentCountDto>(undefined);
    }

    flush() {
        this.closePreview();
        this.hidePreviewAttachments();
        this.resetPreviewItem();
    }

    //#region Preview
    //#region PreviewOrigin
    setPreviewOrigin(result: EnterpriseSearchDataToElasticModelDto | undefined) {
        this._previewOrigin$.next(result);
    }
    get previewOrigin$(): Observable<EnterpriseSearchDataToElasticModelDto> {
        return this._previewOrigin$.asObservable();
    }
    get previewOrigin(): EnterpriseSearchDataToElasticModelDto {
        return this._previewOrigin$.getValue();
    }
    resetOrigin() {
        this.setPreviewOrigin(undefined);
    }
    //#endregion PreviewOrigin

    //#region Preview Mode
    get previewMode$(): Observable<'attachment' | 'self' | undefined> {
        return this._previewMode$.asObservable();
    }
    setPreviewMode(mode: 'attachment' | 'self' | undefined) {
        this._previewMode$.next(mode);
    }
    get previewMode(): 'attachment' | 'self' | undefined {
        return this._previewMode$.getValue();
    }
    closePreview() {
        this.setPreviewMode(undefined);
        this.hidePreviewAvailable();
        this.resetOrigin();
    }
    //#endregion Preview Mode

    //#region PreviewAvailable
    get isPreviewAvailable(): boolean {
        return this._isPreviewAvailable$.getValue();
    }
    get isPreviewAvailable$(): Observable<boolean> {
        return this._isPreviewAvailable$.asObservable();
    }
    showPreviewAvailable() {
        this._setPreviewAvailability(true);
    }
    hidePreviewAvailable() {
        this._setPreviewAvailability(false);
    }
    private _setPreviewAvailability(isAvailable: boolean) {
        this._isPreviewAvailable$.next(isAvailable);
    }
    //#endregion PreviewAvailable

    //#region PreviewLoader
    get isShowPreviewLoader(): boolean {
        return this._isShowPreviewLoader$.getValue();
    }
    get isShowPreviewLoader$(): Observable<boolean> {
        return this._isShowPreviewLoader$.asObservable();
    }
    showPreviewLoader() {
        this._isShowPreviewLoader$.next(true);
    }
    hidePreviewLoader() {
        this._isShowPreviewLoader$.next(false);
    }
    //#endregion PreviewLoader

    //#endregion Preview

    //#region PreviewAttachments
    get isShowPreviewAttachments(): boolean {
        return this._isShowPreviewAttachments$.getValue();
    }
    get isShowPreviewAttachments$(): Observable<boolean> {
        return this._isShowPreviewAttachments$.asObservable();
    }
    showPreviewAttachments() {
        this.showPreviewLoader();
        this._isShowPreviewAttachments$.next(true);

        setTimeout(() => {
            this.hidePreviewLoader();
        }, 2000);
    }
    hidePreviewAttachments() {
        this._isShowPreviewAttachments$.next(false);
    }

    private setPreviewAttachmentsLoading(result: boolean) {
        this._isPreviewAttachmentsLoading$.next(result);
    }
    get isPreviewAttachmentsLoading$(): Observable<boolean> {
        return this._isPreviewAttachmentsLoading$.asObservable();
    }
    get isPreviewAttachmentsLoading(): boolean {
        return this._isPreviewAttachmentsLoading$.getValue();
    }

    showPreviewAttachmentsLoader() {
        this.setPreviewAttachmentsLoading(true);
    }
    hidePreviewAttachmentsLoader() {
        this.setPreviewAttachmentsLoading(false);
    }

    private setAttachmentResult(result: SearchResultDto) {
        //update setAttachments
        this.setAttachments(result.data);
        //update totalFound
        this.setTotalAttachmentsCount(result.totalFound);
    }

    resetPreviewAttachments() {
        //reset preview mode
        this.setPreviewMode(undefined);
        //reset document type
        this.setAttachmentType(undefined);

        this.hidePreviewLoader();
        this.hidePreviewAttachments();
        this._resetAllAttachments();
    }

    //#region Attachment Type
    get selectedAttachmentType$(): Observable<DocumentCountDto> {
        return this._selectedAttachmentType$.asObservable();
    }
    get selectedAttachmentType(): DocumentCountDto {
        return this._selectedAttachmentType$.getValue();
    }
    setAttachmentType(type: DocumentCountDto) {
        this._selectedAttachmentType$.next(type);
    }
    //#endregion Attachment Type

    //#region Attachments
    private setAttachments(result: EnterpriseSearchDataToElasticModelDto[] | undefined) {
        this._attachments$.next(result);
    }
    get attachments$(): Observable<EnterpriseSearchDataToElasticModelDto[]> {
        return this._attachments$.asObservable();
    }
    get attachments(): EnterpriseSearchDataToElasticModelDto[] {
        return this._attachments$.getValue();
    }
    private _resetAttachments() {
        this.setAttachments(undefined);
    }

    private setSelectedAttachment(result: EnterpriseSearchDataToElasticModelDto | undefined) {
        this._selectedAttachment$.next(result);
    }
    get selectedAttachment$(): Observable<EnterpriseSearchDataToElasticModelDto> {
        return this._selectedAttachment$.asObservable();
    }
    get selectedAttachment(): EnterpriseSearchDataToElasticModelDto {
        return this._selectedAttachment$.getValue();
    }
    private _resetSelectedAttachment() {
        this.setSelectedAttachment(undefined);
    }

    private _resetAllAttachments() {
        this._resetAttachments();
        this._resetSelectedAttachment();
    }
    //#endregion Attachments

    //#region TotalAttachmentsCount
    private setTotalAttachmentsCount(result: number) {
        this._totalAttachmentsCount$.next(result);
    }

    get totalAttachmentsCount$(): Observable<number> {
        return this._totalAttachmentsCount$.asObservable();
    }
    get totalAttachmentsCount(): number {
        return this._totalAttachmentsCount$.getValue();
    }
    //#endregion TotalRecordsCount

    //#region Calls
    getAttachmentsData$(skipCount: number | undefined
        , maxResultCount: number | undefined): Observable<SearchResultDto>  {

        const type = this.selectedAttachmentType.type || RelatedDocumentTypes.TextDocument;

        return this.enterpriseSearchServiceProxy
            .getRelatedDocuments(
                this.previewOrigin.id
                , type
                , skipCount
                , maxResultCount)
            .pipe(
                tap((result: SearchResultDto) => {
                    this.setAttachmentResult(result);
                })
            );
    }
    //#endregion Calls

    //#endregion

    //#region Item preview
    private setPreviewItemLoading(result: boolean) {
        this._isPreviewItemLoading$.next(result);
    }
    get isPreviewItemLoading$(): Observable<boolean> {
        return this._isPreviewItemLoading$.asObservable();
    }
    get isPreviewItemLoading(): boolean {
        return this._isPreviewItemLoading$.getValue();
    }

    showPreviewItemLoader() {
        this.setPreviewItemLoading(true);
    }
    hidePreviewItemLoader() {
        this.setPreviewItemLoading(false);
    }

    private setPreviewDocumentItem(result: PreviewDocumentOutputDto[] | undefined) {
        this._previewDocumentsSubject.next(result);
    }
    get previewDocuments$(): Observable<PreviewDocumentOutputDto[]> {
        return this._previewDocumentsSubject.asObservable();
    }
    get previewDocuments(): PreviewDocumentOutputDto[] {
        return this._previewDocumentsSubject.getValue();
    }

    private setPreviewItem(result: PreviewItemOutputDto | undefined) {
        this._previewItem$.next(result);
    }
    get previewItem$(): Observable<PreviewItemOutputDto> {
        return this._previewItem$.asObservable();
    }
    get previewItem(): PreviewItemOutputDto {
        return this._previewItem$.getValue();
    }

    resetPreviewItem() {
        this.setPreviewItem(undefined);
        this.setPreviewDocumentItem(undefined);
        this.hidePreviewLoader();
        this.hidePreviewItem();
    }

    get isShowPreviewItem(): boolean {
        return this._isShowPreviewItem$.getValue();
    }
    get isShowPreviewItem$(): Observable<boolean> {
        return this._isShowPreviewItem$.asObservable();
    }
    hidePreviewItem() {
        this._isShowPreviewItem$.next(false);
    }

    getItemPreview$(id: string | undefined, parentOnly: boolean | undefined): Observable<PreviewItemOutputDto>  {
        return this.enterpriseSearchServiceProxy
            .getItemPreview(id, parentOnly)
            .pipe(
                tap((result: PreviewItemOutputDto) => {
                    this.setPreviewItem(result);
                })
            );
    }

    getJSONItemPreview$(id: string | undefined): Observable<PagedResultDtoOfPreviewDocumentOutputDto>  {
        const skip = 0;
        const take = 1000;

        return this.enterpriseSearchServiceProxy
            .getItemDocumentsPreview(id, skip, take)
            .pipe(
                tap((result: PagedResultDtoOfPreviewDocumentOutputDto) => {
                    // console.log(result.items);
                    this.setPreviewDocumentItem(result.items);
                })
            );
    }

    getPreviewItem(
        origin: EnterpriseSearchDataToElasticModelDto
        , mode: 'attachment' | 'self' | undefined) {

        if (this.isJson(origin)) {
            // console.log('origin JSON', origin);
            this.getJSONItemPreview$(origin.id)
                .pipe(
                    take(1)
                ).subscribe((result: PagedResultDtoOfPreviewDocumentOutputDto) => {
                    this.setPreviewMode(mode);
                    this.setPreviewOrigin(origin);
                    this.hidePreviewItemLoader();
                });
        } else {
            this.getItemPreview$(origin.id, false)
                .pipe(
                    take(1)
                )
                .subscribe((result: PreviewItemOutputDto) => {
                    this.setPreviewMode(mode);
                    this.setPreviewOrigin(origin);
                    this.hidePreviewItemLoader();
                });
        }
    }

    private isJson(origin: EnterpriseSearchDataToElasticModelDto) {
        return origin.type.includes('JSON');
    }

    //#endregion Item preview

    showPreview(
        origin: EnterpriseSearchDataToElasticModelDto
        , mode: 'attachment' | 'self' | undefined) {

        if (this.isPreviewItemLoading) {
            return;
        }
        this.resetPreview();
        this.showPreviewItemLoader();

        if (!this.isPreviewAvailable) {
            this.showPreviewAvailable();
        }

        this.getPreviewItem(origin, mode);
    }

    closeAndReset() {
        this.resetPreview();
        this.closePreview();
    }

    resetPreview() {
        if (this.previewMode === 'attachment') {
            this.resetPreviewAttachments();
        } else if (this.previewMode === 'self') {
            this.resetPreviewItem();
        }
    }

}
