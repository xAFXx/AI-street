import {
    Component,
    EventEmitter,
    Injector, Input,
    OnDestroy,
    OnInit,
    Output,
    ViewChild,
    ViewEncapsulation
} from '@angular/core';
import { appModuleAnimation} from '@axilla/axilla-shared';

import {concatMap, debounceTime, finalize, take} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {LazyLoadEvent, MenuItem} from 'primeng/api';
import {
    EnterpriseSearchDataToElasticModelDto, EnterpriseSearchMetadataDto,
    IEnterpriseSearchItemsInputDto, PreviewItemOutputDto
} from '@shared/service-proxies/service-proxies';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {DataViewLazyLoadEvent, DataViewPageEvent} from 'primeng/dataview';
import {takeUntil, filter} from 'rxjs/operators';
import {ContextMenu} from 'primeng/contextmenu';
import {ContextMenuData} from '@app/enterprise-search/shared/models';
import {PaginatorState} from '@node_modules/primeng/paginator';

@Component({
    selector: 'app-es-data-view',
    templateUrl: './es-data-view.component.html',
    styleUrls: ['./es-data-view.component.less'],
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class EsDataViewComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    @Output() onOpenContextMenu: EventEmitter<ContextMenuData>
        = new EventEmitter<ContextMenuData>();

    searchValue: string;
    rowsAmount = 9;
    first = 0;

    @Output() loadData: EventEmitter<any>
        = new EventEmitter<any>();
    @Output() onSelectItem: EventEmitter<EnterpriseSearchDataToElasticModelDto>
        = new EventEmitter<EnterpriseSearchDataToElasticModelDto>();
    @Output() showAttachmentsPreview: EventEmitter<any>
        = new EventEmitter<any>();

    @Input() isLoading: boolean;
    @Input() isShowTitle = true;
    @Input() showAttachments = true;
    @Input() layoutMode: 'list' | 'grid' = 'list';
    @Input() totalRecordsCount: number;
    @Input() data: EnterpriseSearchDataToElasticModelDto[] | undefined;

    get currentMetadata() {
        return this.esHistoryService.selectedMetadata;
    }
    get selectedItem(): EnterpriseSearchDataToElasticModelDto {
        return this.esPreviewService.previewOrigin;
    }
    get imagePreview(): string | undefined {
        return this.enterpriseSearchService.imagePreview;
    }

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.esHistoryService.isHistoryModeSearch$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((isHistoryMode: boolean) => {
                this.isHistoryMode = isHistoryMode;
            });
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    onItemClick(item: EnterpriseSearchDataToElasticModelDto) {
        this.onSelectItem.emit(item);
    }

    private onShowPreview(item: EnterpriseSearchDataToElasticModelDto) {
        this.esPreviewService.setPreviewOrigin(item);
    }

    onItemContextMenu(data: ContextMenuData) {
        this.onOpenContextMenu.emit(data);
    }

    onLoadData(event?: PaginatorState |DataViewPageEvent | DataViewLazyLoadEvent) {
        this.first = event?.first || 0;
        this.loadData.emit(event);
    }

    //#region preview Attachments
    onShowAttachmentsPreview(origin: EnterpriseSearchDataToElasticModelDto) {
        this.showAttachmentsPreview.emit(origin);
    }
    //#endregion preview Attachments
}
