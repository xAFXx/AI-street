import {Component, Input, OnDestroy, OnInit, inject, ViewEncapsulation, Injector, ViewChild} from '@angular/core';
import {debounceTime, finalize, map, startWith, take, takeUntil} from 'rxjs/operators';
import {combineLatest, of, Subject, timer} from 'rxjs';
import {AiSessionsService} from '@app/enterprise-search/services/ai-sessions.service';
import {AISessionDto} from '@shared/service-proxies/service-proxies';
import {AppComponentBase} from '@axilla/axilla-shared';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import {MenuItem} from 'primeng/api';
import {Menu} from 'primeng/menu';
import {SessionId, UrlUpdateMode} from '@app/enterprise-search/shared/types';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';
import {AIChatMetricsService} from '@app/enterprise-search/services/ai-chat-metrics.service';
import {FormControl} from '@angular/forms';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {GroupedSessions} from '@app/enterprise-search/shared/models';



@Component({
    selector: 'app-ai-sessions-list',
    templateUrl: './ai-sessions-list.component.html',
    styleUrls: ['./ai-sessions-list.component.less'],
    encapsulation: ViewEncapsulation.None
})
export class AiSessionsListComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    @ViewChild('menu') menu!: Menu;

    @Input()
    override set urlUpdateMode(value: UrlUpdateMode) {
        super.urlUpdateMode = value;
    }

    private readonly aiChatMetricsService = inject(AIChatMetricsService);

    protected menuItems: MenuItem[] = [];

    // Search control
    searchCtrl = new FormControl<string>('', { nonNullable: true });

    sessions$ = combineLatest([
        this.aiSessionsService.sortedSessions$ ?? of([]),
        this.searchCtrl.valueChanges.pipe(
            startWith(this.searchCtrl.value),
            debounceTime(150),
            map(q => (q ?? '').trim().toLowerCase())
        )
    ]).pipe(
        map(([sessions, query]) => {
            const list = (sessions ?? []).slice();

            const ts = (d: any): number => {
                if (!d) {
                    return 0;
                }
                if (typeof d === 'number') {
                    return d;
                }
                if (typeof d?.valueOf === 'function') {
                    return d.valueOf();
                }
                const n = Date.parse(String(d));
                return Number.isNaN(n) ? 0 : n;
            };

            // Sort: pinned first, then by lastMessageAt desc (fallback to lastModificationTime), then by sessionName
            list.sort((a, b) => {
                if (a.pinned !== b.pinned) {
                    return a.pinned ? -1 : 1;
                }
                const aTime = ts(a.lastMessageAt) || ts(a.lastModificationTime);
                const bTime = ts(b.lastMessageAt) || ts(b.lastModificationTime);
                if (aTime !== bTime) {
                    return bTime - aTime;
                }
                const aLabel = a.sessionName || a.sessionId || '';
                const bLabel = b.sessionName || b.sessionId || '';
                return aLabel.localeCompare(bLabel);
            });

            // Filter
            const filtered = query
                ? list.filter(s => {
                    const vals = [
                        s.sessionName,
                        s.sessionId
                    ]
                        .filter(Boolean)
                        .map(v => String(v).toLowerCase());
                    return vals.some(v => v.includes(query));
                })
                : list;

            // Group
            const grouped: GroupedSessions = {
                pinned: filtered.filter(s => !!s.pinned),
                others: filtered.filter(s => !s.pinned)
            };

            return grouped;
        })
    );

    //Detect selected sessions
    protected selectedId: SessionId | null = null;
    //For menu usage
    private session: AISessionDto | null = null;

    constructor(
        injector: Injector
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.init();

        // Sync initial/current selection
        this.aiSessionsService.currentSessionId$
            .pipe(takeUntil(this.destroy$))
            .subscribe(id => (this.selectedId = id));

    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    private init(): void {
        this.registerEvents();
        this._initMenu();
    }

    registerEvents(): void {
        abp.event.on('app.aichat.updateSessions', (sessions:  AISessionDto[]) => {
            this.aiSessionsService.updateSessions(sessions[0], {silent: true});
        });
    }

    private _initMenu() {
        this.menuItems = [
            // {
            //     label: 'New',
            //     icon: 'pi pi-plus',
            //     command: () => {
            //         this.clearSession();
            //     }
            // },
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                command: () => {
                    this.deleteSession();
                }
            }
        ];
    }

    deleteSession() {
        let message = this.ls('Axilla', 'Axilla.AI.Sessions.DeleteMessage', this.session.sessionName);
        let title = this.ls('Axilla', 'Axilla.AI.Sessions.DeleteTitle');

        abp.message.confirm(message,
            title,
            (result: boolean) => {
                if (result) {
                    this.aiChatMetricsService.resetMetrics();
                    this.aiService.clearAllIndicators();

                    const sessionId = this.session.sessionId;
                    this._deleteSession(sessionId);
                }
            });
    }

    private _deleteSession(sessionId: SessionId): void {
        const sid = sessionId as string;
        this.aiSessionsService.deleteSession(sid)
            .pipe(
                take(1),
                finalize(() => {
                    timer(500)
                        .pipe(take(1))
                        .subscribe(() => this.aiSessionsService.refreshSessionList());
                })
            )
            .subscribe();
    }

    // Programmatic select
    selectSession(id: string) {
        this.selectedId = id;
        this.onSelect(id);
    }

    menuActivation($event, session: AISessionDto) {
        if (!session) {
            return;
        }
        this.session = session;
        this.menu.toggle($event);
    }

    trackById = (_: number, s: AISessionDto) => s.sessionId;
}
