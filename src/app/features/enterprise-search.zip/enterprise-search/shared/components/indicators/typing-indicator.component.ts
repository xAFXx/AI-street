import {Component, Injector, NgZone} from '@angular/core';
import { BehaviorSubject, Observable, timer } from 'rxjs';
import { map } from 'rxjs/operators';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {TypingIndicator} from '@app/enterprise-search/shared/models';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';

@Component({
    selector: 'app-typing-indicator-container',
    templateUrl: './typing-indicator.component.html',
})
export class TypingIndicatorContainerComponent extends EnterpriseSearchComponentBase {
    typingIndicators$: Observable<TypingIndicator[]>;
    loading$: Observable<boolean>;

    protected reactiveAIChatService: ReactiveAIChatService;

    constructor(
        injector: Injector,
    ) {
        super(injector);

        this.reactiveAIChatService = injector.get(ReactiveAIChatService);

        this.typingIndicators$ = this.reactiveAIChatService.typingIndicators$;
        this.loading$ = this.reactiveAIChatService.loading$;
    }

}
