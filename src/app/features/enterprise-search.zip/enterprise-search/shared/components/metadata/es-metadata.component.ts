import {Component, Injector, Input, OnDestroy, OnInit} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {takeUntil, filter} from 'rxjs/operators';
import {
    EnterpriseSearchDataToElasticModelDto,
    PreviewItemOutputDto,
    TimelineDto
} from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'app-es-metadata',
    templateUrl: './es-metadata.component.html',
    styleUrls: ['./es-metadata.component.less']
})
export class ESMetadataComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    @Input() item: EnterpriseSearchDataToElasticModelDto;

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {}

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }
}
