import {Injector, OnDestroy} from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { MenuItem } from 'primeng/api';

import { AppComponentBase } from '@node_modules/@axilla/axilla-shared';
import { AiSessionsService } from '@app/enterprise-search/services/ai-sessions.service';
import { ReactiveAIChatService } from '@app/enterprise-search/services/reactive-ai-chat.service';
import { AiAgentsService } from '@app/enterprise-search/services/ai-agents.service';
import { AIChatMetricsService } from '@app/enterprise-search/services/ai-chat-metrics.service';
import { AISessionDto } from '@shared/service-proxies/service-proxies';
import { SessionId } from '@app/enterprise-search/shared/types';

type UrlUpdateMode = 'router' | 'location' | 'none';

interface SessionOption {
    label: string;
    value: string;
    data: AISessionDto;
}

export abstract class AiSessionsBaseComponent extends AppComponentBase implements OnDestroy {
    /** Services */
    protected readonly aiSessionsService: AiSessionsService = this.injector.get(AiSessionsService);
    protected readonly aiService: ReactiveAIChatService = this.injector.get(ReactiveAIChatService);
    protected readonly aiAgentsService: AiAgentsService = this.injector.get(AiAgentsService);
    protected readonly aiChatMetricsService: AIChatMetricsService = this.injector.get(AIChatMetricsService);

    /** Public API for templates */
    urlUpdateMode: UrlUpdateMode = 'router';
    selectedId: SessionId | null = null;
    menuItems: MenuItem[] = [];

    /** Expose options for dropdowns, lists, etc. */
    options$: Observable<SessionOption[]> = this.aiSessionsService.sortedSessions$.pipe(
        map(list =>
            list.map(s => ({
                label: s.sessionName || s.sessionId,
                value: s.sessionId,
                data: s
            }))
        )
    );

    /** Lifecycle helpers */
    protected readonly destroy$ = new Subject<void>();

    protected constructor(protected injector: Injector) {
        super(injector);

        this.registerEvents();
        this.menuItems = this.buildMenuItems();
        this.bindCurrentSelection();
    }

    /** Clean up */
    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    /** Hook to customize context-menu items in child components */
    protected buildMenuItems(): MenuItem[] {
        return [
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                command: () => this.deleteSession()
            }
        ];
    }

    /** Subscribe to store’s current session to keep local selectedId in sync */
    protected bindCurrentSelection(): void {
        this.aiSessionsService.currentSessionId$.subscribe(id => (this.selectedId = id));
    }

    /** abp event bus listeners shared by all session pickers */
    protected registerEvents(): void {
        abp.event.on('app.aichat.updateSessions', (sessions: AISessionDto[]) => {
            if (sessions?.length) {
                this.aiSessionsService.updateSessions(sessions[0], { silent: true });
            }
        });
    }

    /** TrackBy helper */
    trackByValue = (_: number, opt: SessionOption) => opt.value;

    /** Programmatic select (also used by UI handlers) */
    selectSession(id: string): void {
        this.selectedId = id;
        this.onSelect(id);
    }

    /** Clear current session (new/empty) */
    clearSession(): void {
        this.selectedId = null;
        this.onSelect(null);
        this.aiSessionsService.clear();
    }

    /** Main select handler (shared) */
    onSelect(id: string | null): void {
        if (!id) {
            return;
        }

        const ok = this.aiSessionsService.selectSession(id);
        if (!ok) {
            return;
        }

        this.aiService.clearAllIndicators();
        this.updateAvailableAgent(id);

        switch (this.urlUpdateMode) {
            case 'router':
                this.aiSessionsService.navigateToSession(id);
                break;
            case 'location':
                this.aiSessionsService.setSessionIdInUrl(id, true);
                break;
            case 'none':
            default:
                break;
        }
    }

    /** Helper to preload available assistant for the session */
    protected updateAvailableAgent(sid: string): void {
        if (!sid) {
            return;
        }

        this.aiAgentsService.getAvailableAssistant$(sid)
            .pipe(take(1))
            .subscribe();
    }

    /** New session flow with confirmation */
    newSession(): void {
        const message = this.ls('Axilla', 'Axilla.AI.Sessions.CreateNewMessage');
        const title = this.ls('Axilla', 'Axilla.AI.Sessions.CreateNewTitle');

        abp.message.confirm(message, title, (result: boolean) => {
            if (result) {
                this.clearSession();
                this.aiSessionsService.createNewSession();
            }
        });
    }

    /** Delete current session with confirmation */
    deleteSession(): void {
        const session = this.aiSessionsService.currentSessionSnapshot;
        const message = this.ls('Axilla', 'Axilla.AI.Sessions.DeleteMessage', session.sessionName);
        const title = this.ls('Axilla', 'Axilla.AI.Sessions.DeleteTitle');

        abp.message.confirm(message, title, (result: boolean) => {
            if (result) {
                this.aiChatMetricsService.resetMetrics();
                this.aiService.clearAllIndicators();

                const sessionId = this.aiSessionsService.currentSessionId;
                this._deleteSession(sessionId as string);
            }
        });
    }

    /** Actual delete call (kept separate for overriding if needed) */
    protected _deleteSession(sid: string): void {
        this.aiSessionsService.deleteSession(sid)
            .pipe(take(1))
            .subscribe();
    }

}
