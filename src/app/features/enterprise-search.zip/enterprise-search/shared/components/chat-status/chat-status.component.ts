import {Component, OnInit, Injector} from '@angular/core';
import { AppComponentBase } from '@axilla/axilla-shared';
import { ChatConnectionState } from '../../models';
import {AIChatSignalrService} from '@app/enterprise-search/services/ai-chat-signalr.service';

@Component({
    selector: 'app-chat-status',
    templateUrl: 'chat-status.component.html',
    styleUrls: ['./chat-status.component.less']
})
export class ChatStatusComponent extends AppComponentBase implements OnInit {
    status: ChatConnectionState;

    private aiChatSignalrService: AIChatSignalrService;

    constructor(
        injector: Injector
    ) {
        super(injector);

        this.aiChatSignalrService = injector.get(AIChatSignalrService);
    }

    ngOnInit(): void {
        this.aiChatSignalrService.connectionState$.subscribe(s => this.status = s);
    }
}
