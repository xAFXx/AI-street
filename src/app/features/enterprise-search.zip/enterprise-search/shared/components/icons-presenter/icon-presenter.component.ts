import {Component, Input, OnInit} from '@angular/core';

@Component({
    selector: 'app-icon-presenter',
    templateUrl: './icon-presenter.component.html',
    styleUrls: ['./icon-presenter.component.less']
})
export class ESIconPresenterComponent implements OnInit {
    @Input() type?: string;

    iconSupplier: string;
    iconType: string;
    base64Source: string;

    ngOnInit() {
        this._initIcon();
    }

    private _initIcon() {
        switch (this.type) {
            case 'WorkItem':
                this.iconType = 'task';
                this.iconSupplier = 'material';
                break;
            case 'Mail':
                this.iconType = 'mail';
                this.iconSupplier = 'material';
                break;
            case 'PDF':
                this.iconType = 'pi-file-pdf';
                this.iconSupplier = 'primeng';
                break;

            default:
                this.iconType =  'draft';
                this.iconSupplier = 'material';
                break;
        }
    }
}
