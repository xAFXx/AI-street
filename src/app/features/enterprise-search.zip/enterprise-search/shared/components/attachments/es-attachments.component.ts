import {Component, EventEmitter, Injector, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {
    DocumentCountDto,
    EnterpriseSearchDataToElasticModelDto, PreviewItemOutputDto,
    RelatedDocumentTypes
} from '@shared/service-proxies/service-proxies';
import {takeUntil} from 'rxjs/operators';

@Component({
    selector: 'app-es-attachments',
    templateUrl: './es-attachments.component.html',
    styleUrls: ['./es-attachments.component.less']
})
export class EsAttachmentsComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    @Input() item: EnterpriseSearchDataToElasticModelDto;

    @Output() preview = new EventEmitter<EnterpriseSearchDataToElasticModelDto>();

    protected readonly RelatedDocumentTypes = RelatedDocumentTypes;

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.esPreviewService.previewItem$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            )
            .subscribe((item: PreviewItemOutputDto) => {
            });
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    isSelectedAttachmentType(attachment: DocumentCountDto): boolean {
        if (!this.item
            || !this.esPreviewService.previewOrigin
            || !this.esPreviewService.selectedAttachmentType) {
            return false;
        }

        return this.item?.id === this.esPreviewService.previewOrigin?.id
            && attachment.type === this.esPreviewService.selectedAttachmentType.type;
    }

    previewAttachment(event: Event, attachment: DocumentCountDto) {
        event.preventDefault();
        event.stopPropagation();

        this.esPreviewService.flush();

        this.esPreviewService.setAttachmentType(attachment);
        this.preview.emit(this.item);
    }

}
