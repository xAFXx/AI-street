import {Component, Input, OnDestroy, OnInit, inject, ViewEncapsulation, Injector, ViewChild} from '@angular/core';
import {map, take, takeUntil} from 'rxjs/operators';
import { Subject } from 'rxjs';
import {AiSessionsService} from '@app/enterprise-search/services/ai-sessions.service';
import {AIChatMessageDto, AIChatMetricDto, AISessionDto} from '@shared/service-proxies/service-proxies';
import {AppComponentBase} from '@node_modules/@axilla/axilla-shared';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import {MenuItem} from '@node_modules/primeng/api';
import {ContextMenu} from '@node_modules/primeng/contextmenu';
import {ContextMenuData} from '@app/enterprise-search/shared/models';
import {SessionId} from '@app/enterprise-search/shared/types';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';
import {AIChatMetricsService} from '@app/enterprise-search/services/ai-chat-metrics.service';

type UrlUpdateMode = 'router' | 'location' | 'none';

interface SessionOption {
    label: string;
    value: string;
    data: AISessionDto;
}

@Component({
    selector: 'app-ai-sessions',
    templateUrl: './ai-sessions.component.html',
    styleUrls: ['./ai-sessions.component.less'],
    encapsulation: ViewEncapsulation.None
})
export class AiSessionsComponent extends AppComponentBase implements OnInit, OnDestroy {

    @Input() urlUpdateMode: UrlUpdateMode = 'router'; // 'location' | 'none'

    private readonly destroy$ = new Subject<void>();
    private readonly aiSessionsService = inject(AiSessionsService);
    private readonly aiService = inject(ReactiveAIChatService);
    private readonly aiAgentsService = inject(AiAgentsService);
    private readonly aiChatMetricsService = inject(AIChatMetricsService);

    protected menuItems: MenuItem[] = [];

    options$ = this.aiSessionsService.sortedSessions$.pipe(
        map(list =>
            list.map(s => ({
                label: s.sessionName || s.sessionId,
                value: s.sessionId,
                data: s
            }) as SessionOption)
        )
    );

    /** Two-way bound to the dropdown */
    selectedId: SessionId | null = null;

    constructor(
        injector: Injector
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.init();

        // Sync initial/current selection
        this.aiSessionsService.currentSessionId$
            .pipe(takeUntil(this.destroy$))
            .subscribe(id => (this.selectedId = id));

    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    private init(): void {
        this.registerEvents();
        this._initMenu();
    }

    registerEvents(): void {

        abp.event.on('app.aichat.updateSessions', (sessions:  AISessionDto[]) => {
            this.aiSessionsService.updateSessions(sessions[0], {silent: true});
        });
    }

    private _initMenu() {
        this.menuItems = [
            // {
            //     label: 'New',
            //     icon: 'pi pi-plus',
            //     command: () => {
            //         this.clearSession();
            //     }
            // },
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                command: () => {
                    this.deleteSession();
                }
            }
        ];
    }

    onSelect(id: string): void {
        if (!id) {
            return;
        }

        // Update the store selection
        const ok = this.aiSessionsService.selectSession(id);
        if (!ok) {
            return;
        }

        this.aiService.clearAllIndicators();
        this.updateAvailableAgent(id);

        // Update URL per chosen mode
        switch (this.urlUpdateMode) {
            case 'router':
                this.aiSessionsService.navigateToSession(id); // no reload; replaceUrl: true inside
                break;
            case 'location':
                this.aiSessionsService.setSessionIdInUrl(id, true); // replaceState only
                break;
            case 'none':
            default:
                // do nothing
                break;
        }
    }

    updateAvailableAgent(sid: string) {
        if (!sid) {
            return;
        }

        this.aiAgentsService.getAvailableAssistant$(sid)
            .pipe(
                take(1)
            )
            .subscribe();
    }

    newSession() {
        let message = this.ls('Axilla', 'Axilla.AI.Sessions.CreateNewMessage');
        let title = this.ls('Axilla', 'Axilla.AI.Sessions.CreateNewTitle');

        abp.message.confirm(message,
            title,
            (result: boolean) => {
                if (result) {
                    this.clearSession();
                    this.aiSessionsService.createNewSession();
                }
            });

    }

    deleteSession() {
        const session = this.aiSessionsService.currentSessionSnapshot;

        let message = this.ls('Axilla', 'Axilla.AI.Sessions.DeleteMessage', session.sessionName);
        let title = this.ls('Axilla', 'Axilla.AI.Sessions.DeleteTitle');

        abp.message.confirm(message,
            title,
            (result: boolean) => {
                if (result) {
                    this.aiChatMetricsService.resetMetrics();
                    this.aiService.clearAllIndicators();

                    const sessionId = this.aiSessionsService.currentSessionId;
                    this._deleteSession(sessionId);
                }
            });

    }

    private _deleteSession(sessionId: SessionId): void {
        const sid = sessionId as string;
        this.aiSessionsService.deleteSession(sid)
            .pipe(
                take(1)
            )
            .subscribe();
    }

    // Programmatic select
    selectSession(id: string) {
        this.selectedId = id;
        this.onSelect(id);
    }

    clearSession() {
        this.selectedId = null;
        this.onSelect(null); // optional
        this.aiSessionsService.clear();
    }

    trackByValue = (_: number, opt: SessionOption) => opt.value;

}
