import {Component, EventEmitter, Injector, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {takeUntil, filter} from 'rxjs/operators';
import {
    EnterpriseSearchDataToElasticModelDto,
    PreviewItemOutputDto,
    TimelineDto
} from '@shared/service-proxies/service-proxies';
import {ContextMenuData} from '@app/enterprise-search/shared/models';

@Component({
    selector: 'app-es-item-header',
    templateUrl: './es-item-header.component.html',
    styleUrls: ['./es-item-header.component.less']
})
export class ESItemHeaderComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    @Input() showMetadata = false;
    @Input() showClose = false;
    @Input() item: EnterpriseSearchDataToElasticModelDto;

    @Output() onOpenContextMenu: EventEmitter<ContextMenuData>
        = new EventEmitter<ContextMenuData>();

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {

    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    close() {
        this.esPreviewService.closeAndReset();
    }

    onItemContextMenu(event: MouseEvent) {
        event.preventDefault();  // prevent the default right-click menu

        const cmData: ContextMenuData = {
            event: event,
            data: this.item
        };

        this.onOpenContextMenu.emit(cmData);
    }
}
