import {
    Component,
    ViewChild,
    ElementRef,
    Injector,
    OnInit,
    OnDestroy,
    AfterViewInit,
    HostListener
} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {takeUntil, filter, take} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {
    AIChatMessageType,
    AIPersonDescriptionDto,
    EnterpriseSearchMetadataDto,
    FileToAiDto
} from '@shared/service-proxies/service-proxies';
import dayjs from 'dayjs';
import {AIChatMessage} from '@app/enterprise-search/shared/models';
import {InstructionInterceptor} from '@app/enterprise-search/shared/helpers/instruction-interceptor';
import {OverlayPanel} from 'primeng/overlaypanel';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import _ from 'lodash';
import {AIChatSignalrService} from '@app/enterprise-search/services/ai-chat-signalr.service';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';
import {countWords, createGuid, wordStats} from '@app/enterprise-search/shared/helpers/helpers';
import {AiSessionsService} from '@app/enterprise-search/services/ai-sessions.service';
import {ChatMessagesStore} from '@app/enterprise-search/shared/store/ai-message.store';
import {SessionId} from '@app/enterprise-search/shared/types';
import {AiLayoutService} from '@app/enterprise-search/services/layout.service';

@Component({
    selector: 'app-search-input',
    templateUrl: './search-input.component.html',
    styleUrls: ['./search-input.component.less'],
})
export class SearchInputComponent extends EnterpriseSearchComponentBase implements OnInit, AfterViewInit, OnDestroy {
    @ViewChild('searchInput') searchInput!: ElementRef;
    @ViewChild('mentionDropdown') mentionDropdown!: ElementRef<HTMLUListElement>;
    @ViewChild('op') op!: OverlayPanel;
    @ViewChild('filesTextInput') filesTextInput!: ElementRef<HTMLInputElement>;

    highlightedIndex = 0;
    coordinates: { left: number; top: number; height: number } = {left: 554, top: 100, height: 100};
    protected initialLeft = 0;

    protected readonly destroy$ = new Subject<void>();

    uploadMode: 'image' | 'file' = 'image';
    allowMultipleUploads = false;

    // Optional: expand as you wish
    allowedFileTypes = '.xml, .json, .pdf, .doc, .docx, .xls, .xlsx, .csv, .txt';
    allowedImagesTypes = '.jpg, .png, .tiff, .webp';

    selectedItems: FileToAiDto[] = [];

    fileUploadPrompt = '';
    searchValue = '';
    imagePreview: boolean;
    isHovering = false;
    startPictureLoading = false;
    startFilesLoading = false;

    private _modes: boolean;
    set modes(value: boolean) {
        this._modes = value;
    }
    get modes(): boolean {
        return this._modes;
    }

    searchMode: 'image' | 'text' | 'combined';

    get imagePreviewPicture(): string | undefined {
        return this.enterpriseSearchService.imagePreview;
    }
    uploadError: string | null = null;

    get isFileUploadOpened(): boolean {
        return this.enterpriseSearchService.isFileUploadOpened;
    }

    get filterPlaceholder(): string {
        if (this.enterpriseSearchService.isImageSearchMode()) {
            return 'Searching image';
        }
        return 'What are you looking for?';
    }

    get sessionId(): SessionId | undefined {
        return this.aiSessionsService?.currentSessionId ?? undefined;
    }

    get mentionSuggestions(): AIPersonDescriptionDto[]  {
        return this.aiAgentsService.availableAIAgents;
    }
    filteredSuggestions: AIPersonDescriptionDto[] = [];
    showMentionDropdown = false;
    mentionSearchTerm = '';
    caretPosition = 0;

    protected reactiveAIChatService: ReactiveAIChatService;

    constructor(
        injector: Injector,
        private messageStore: ChatMessagesStore,
    ) {
        super(injector);

        this.reactiveAIChatService = injector.get(ReactiveAIChatService);
    }

    ngOnInit() {
        this._initSubscriptions();
    }

    ngAfterViewInit(): void {
        // Focus the input after the view has been initialized.
        this.searchInput.nativeElement.focus();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    @HostListener('window:keydown.escape', ['$event'])
    handleEsc(event: KeyboardEvent) {
        if (this.enterpriseSearchService.isImageSearchMode()) {
            this.forceCloseFileUpload();
        }
    }

    private _initSubscriptions() {
        this.enterpriseSearchService.isShowSearchResult$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((isShowSearchResult: boolean) => {
                this.isShowSearchResult = isShowSearchResult;
            });

        this.enterpriseSearchService.searchMode$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((searchMode: 'image' | 'text' | 'combined') => {
                this.searchMode = searchMode;

                if (this.searchMode === 'text' || this.searchMode === 'combined') {
                    this.modes = false;
                } else {
                    this.modes = true;
                }
            });

        this.esHistoryService.historyMode$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((historyMode: 'life' | 'historySearch' | 'history') => {
                this.historyMode = historyMode;
            });

        this.enterpriseSearchService.search$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((searchValue: string) => {
            if (this.imagePreview) {
                this.searchValue = '';
                return;
            }

            if (this.historyMode === 'life') {
                if (!this.imagePreview && searchValue) {
                    this.searchValue = searchValue;
                }
            } else if (this.historyMode === 'historySearch') {
                this.searchValue = searchValue;
            }
        });

        this.esHistoryService.selectedMetadata$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
                filter((searchValue: EnterpriseSearchMetadataDto | null) => !!searchValue)
            ).subscribe((searchValue: EnterpriseSearchMetadataDto) => {
                if (!this.imagePreview) {
                    this.searchValue = searchValue.searchTerm;
                }
            });

        this.enterpriseSearchService.imagePreview$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits

            ).subscribe((image: string) => {
                if (image) {
                    this.forceCloseFileUpload();
                    this.startPictureLoading = false;
                    this.searchValue = '';
                    this.imagePreview = true;
                } else {
                    this.imagePreview = false;
                }
            });
    }

    toggleFileUpload() {
        this.enterpriseSearchService.toggleFileUpload();
    }
    forceCloseFileUpload() {
        this.enterpriseSearchService.forceCloseFileUploadModal();
    }

    //#region Image Search
    // Update your starters to enable single/multiple and mode
    protected startImageUpload($event: Event, allowMany = false): void {
        this.uploadMode = 'image';
        this.allowMultipleUploads = allowMany;
        this.op.toggle($event);
        setTimeout(() => this.toggleFileUpload(), 300);
    }

    onImageSelected(event: Event) {
        const file = (event.target as HTMLInputElement).files?.[0];
        this.handleFile(file);
    }

    onDrop(event: DragEvent) {
        event.preventDefault();
        this.isHovering = false;

        if (this.uploadMode === 'image') {
            const file = event.dataTransfer?.files[0];
            this.handleFile(file);
        } else {
            const files = Array.from(event.dataTransfer?.files ?? []);
            this.handleFiles(files);
        }
    }

    private handleFile(file?: File) {
        if (!file) {
            return;
        }
        this.startPictureLoading = true;
        if (this.esHistoryService.historyMode !== 'life') {
            this.esHistoryService.resetHistoryMode();
        }

        const allowedTypes = ['image/jpeg', 'image/png', 'image/tiff', 'image/webp'];

        if (!allowedTypes.includes(file.type)) {
            this.uploadError = 'Upload failed. Supported filetypes: .jpg, .png, .tiff, or .webp';
            this.enterpriseSearchService.clearImageForPreview();
            return;
        }

        this.uploadError = null;
        const reader = new FileReader();
        reader.onload = () => {
            this.enterpriseSearchService.setImageForPreviewAndRunSearch(reader.result as string);
        };
        reader.readAsDataURL(file);
    }
    //#endregion Image Search


    onDragOver(event: DragEvent) {
        event.preventDefault();
        this.isHovering = true;
    }

    onDragLeave() {
        this.isHovering = false;
    }

    openFileDialog() {
        const fileInput = document.querySelector<HTMLInputElement>('input[type="file"]');
        if (fileInput) {
            fileInput.click();
        }
    }

    clearSearch() {
        this.searchValue = '';
        this.enterpriseSearchService.setSearch('');
        this.enterpriseSearchService.setBase64Search(undefined);

        if (this.imagePreview) {
            this.enterpriseSearchService.clearImageForPreview(false);
        }

        this.uploadError = null;
        this.esHistoryService.resetImageDescription();
    }

    //#region keyDown
    onKeyDown(event: KeyboardEvent): void {
        // 1) Mention navigation / selection first
        if (this.handleMentionKeys(event)) {
            return;
        }

        // 2) Quick flags
        const isCtrlEnter = this.isCtrlEnter(event);
        const isEnter = this.isEnter(event);

        // 3) Validations
        if (this.shouldBlockEmptyPrompt(isCtrlEnter)) {
            abp.message.info('Please enter a prompt.');
            return;
        }

        if (this.shouldBlockMissingFiles(isCtrlEnter)) {
            abp.message.info('Please upload at least one file or close the file upload.');
            return;
        }

        // 4) Actions
        if (isCtrlEnter) {
            this.sendDependingOnUpload();
            return;
        }

        if (isEnter && !this.isFileUploadOpened) {
            this._executeSearch();
            return;
        }
    }
    onSingleKeyDown(event: KeyboardEvent): void {
        // 1) Mention navigation / selection first
        if (this.handleMentionKeys(event)) {
            return;
        }

        // 2) Quick flags
        const isEnter = this.isEnter(event);
        const searchValueLen = countWords(this.searchValue);

        // 3) Validations
        if (this.shouldBlockEmptyPrompt(isEnter)) {
            abp.message.info('Please enter a prompt.');
            return;
        }

        if (this.shouldBlockMissingFiles(isEnter)) {
            abp.message.info('Please upload at least one file or close the file upload.');
            return;
        }

        // 4) Actions
        if (isEnter && !this.isFileUploadOpened && searchValueLen >= 3) {
            this.sendDependingOnUpload();
        } else if (isEnter && !this.isFileUploadOpened && searchValueLen <= 2) {
            this._executeSearch();
        }
    }

    /* ========== Helpers ========== */

    private handleMentionKeys(event: KeyboardEvent): boolean {
        if (!this.showMentionDropdown || this.filteredSuggestions.length === 0) {
            return false;
        }

        if (event.key === 'ArrowDown') {
            this.moveHighlight(1);
            event.preventDefault();
            return true;
        }

        if (event.key === 'ArrowUp') {
            this.moveHighlight(-1);
            event.preventDefault();
            return true;
        }

        if (event.key === 'Enter') {
            this.selectCurrentMention();
            event.preventDefault();
            return true;
        }

        return false;
    }

    private moveHighlight(delta: 1 | -1): void {
        const len = this.filteredSuggestions.length;
        this.highlightedIndex = (this.highlightedIndex + delta + len) % len;
    }

    private selectCurrentMention(): void {
        const item = this.filteredSuggestions[this.highlightedIndex];
        this.selectMention(item);
    }

    private isCtrlEnter(event: KeyboardEvent): boolean {
        return event.key === 'Enter' && !!event.ctrlKey;
    }

    private isEnter(event: KeyboardEvent): boolean {
        return event.key === 'Enter';
    }

    private isPromptEmpty(): boolean {
        // Keep original logic: treat falsy `searchValue` as empty.
        return !this.searchValue;
    }

    private shouldBlockEmptyPrompt(isCtrlEnter: boolean): boolean {
        // Original code had the same condition twice; equivalently:
        return isCtrlEnter && this.isPromptEmpty();
    }

    private shouldBlockMissingFiles(isCtrlEnter: boolean): boolean {
        return isCtrlEnter && this.isFileUploadOpened && !this.selectedItems.length;
    }

    private sendDependingOnUpload(): void {
        if (!this._aiChatSignalrService.isChatConnected) {
            return;
        }

        this.aiLayoutService.showPanel('ai');

        if (this.isFileUploadOpened) {
            this.sendWithFiles();
        } else {
            this._sendMessageToAI();
        }
    }

    // onKeyDown(event: KeyboardEvent): void {
    //     if (this.showMentionDropdown && this.filteredSuggestions.length > 0) {
    //         if (event.key === 'ArrowDown') {
    //             this.highlightedIndex = (this.highlightedIndex + 1) % this.filteredSuggestions.length;
    //             event.preventDefault();
    //             return;
    //         }
    //         if (event.key === 'ArrowUp') {
    //             this.highlightedIndex =
    //                 (this.highlightedIndex - 1 + this.filteredSuggestions.length) % this.filteredSuggestions.length;
    //             event.preventDefault();
    //             return;
    //         }
    //         if (event.key === 'Enter') {
    //             this.selectMention(this.filteredSuggestions[this.highlightedIndex]);
    //             event.preventDefault();
    //             return;
    //         }
    //     }
    //
    //     const isCtrlEnter = event.key === 'Enter' && event.ctrlKey;
    //     const isCtrlSpace = event.key === ' ' && event.ctrlKey;
    //     const isEnter = event.key === 'Enter';
    //
    //     if (isCtrlEnter && !this.searchValue
    //         || isCtrlEnter && !this.searchValue) {
    //         abp.message.info('Please enter a prompt.');
    //         return;
    //     }
    //
    //     if (isCtrlEnter && this.isFileUploadOpened && !this.selectedItems.length) {
    //         abp.message.info('Please upload at least one file or close the file upload.');
    //         return;
    //     }
    //
    //     if (isCtrlEnter) {
    //         if (this.isFileUploadOpened) {
    //             this.sendWithFiles();
    //         } else {
    //             this._sendMessageToAI();
    //         }
    //         return;
    //     }
    //
    //     if (isEnter && !this.isFileUploadOpened) {
    //         this._executeSearch();
    //         return;
    //     }
    // }
    //#endregion keyDown


    onSearchValueChange(value: string): void {
        this.searchValue = value;
        const input = document.activeElement as HTMLInputElement;
        const caretIndex = input?.selectionStart ?? value.length;

        this._checkMentionTrigger(value, caretIndex);

        // Calculate caret coordinates
        if (input) {
            this.coordinates = this.getCaretCoordinates(input, caretIndex);
            if (this.initialLeft === 0) {
                this.initialLeft = this.coordinates.left;
            }
            //this.positionMentionDropdown(coords);
        }
    }

    protected focusInput() {
        this.searchInput.nativeElement.focus();
    }

    protected clearInput() {
        this.searchValue = '';
    }

    runSearch(force: boolean = false) {
        const trimmed = this.searchValue.trim();
        if (this.historyMode === 'historySearch') {
            this.enterpriseSearchService.setSearch(trimmed);
        }

        if (this.searchValue === ''
            || this.searchValue === null) {
            return;
        }

        this.aiLayoutService.showPanel('search-result');
        this.esHistoryService.resetImageDescription();
        this.enterpriseSearchService.setSearch(trimmed);

        this.enterpriseSearchService.triggerBasicSearch();
    }

    private _sendMessageToAI(): void {
        const trimmed = this.searchValue.trim();
        if (!trimmed) {
            return;
        }

        const input = {
            content: trimmed,
            owner: 'user',
            timestamp: dayjs().format('DD-MM-YYYY HH:mm:ss'),
            sessionId: this.sessionId
        } as AIChatMessage;

        this.sendToAIMessage(input);
    }

    private _executeSearch(): void {
        this.runSearch();
        this.showMentionDropdown = false;
    }

    //#region Mention
    private positionMentionDropdown(coords: { left: number; top: number; height: number }): void {
        if (this.mentionDropdown?.nativeElement) {
            const dropdown = this.mentionDropdown.nativeElement;
            dropdown.style.position = 'absolute';
            dropdown.style.left = `${coords.left}px`;
            dropdown.style.top = `${coords.top + coords.height}px`;
        }
    }

    private getCaretCoordinates(input: HTMLInputElement, caretPos: number): { left: number; top: number; height: number } {
        // Create a hidden div to replicate the input
        const div = document.createElement('div');
        const copyStyle = getComputedStyle(input);
        const stylesToCopy = [
            'font', 'fontSize', 'fontFamily', 'fontWeight', 'letterSpacing',
            'textTransform', 'wordSpacing', 'textIndent', 'whiteSpace',
            'padding', 'border', 'boxSizing'
        ];
        stylesToCopy.forEach(prop => (div.style[prop] = copyStyle[prop]));

        div.style.position = 'absolute';
        div.style.visibility = 'hidden';
        div.style.whiteSpace = 'pre-wrap';
        div.style.left = '0';
        div.style.top = '0';

        // Text up to the caret
        const value = input.value.substring(0, caretPos);
        div.textContent = value.replace(/\s/g, '\u00a0'); // replace spaces with non-breaking space

        // Create a span to mark the caret position
        const span = document.createElement('span');
        span.textContent = '|';
        div.appendChild(span);

        document.body.appendChild(div);
        const rect = span.getBoundingClientRect();
        document.body.removeChild(div);

        const inputRect = input.getBoundingClientRect();

        let left = inputRect.left + rect.left;
        if (this.initialLeft !== 0 && left > this.initialLeft + 441) {
            left = left - (left - (this.initialLeft + 441));
        }
        return {
            left: left,
            top: inputRect.top + rect.top,
            height: rect.height
        };
    }

    protected selectMention(suggestion: AIPersonDescriptionDto): void {
        const inputEl = document.querySelector<HTMLInputElement>('input[type="text"]');
        if (!inputEl) {
            return;
        }

        const caretPos = inputEl.selectionStart || 0;
        const value = inputEl.value;

        // Find the last '@' before caret
        const lastAtIndex = value.lastIndexOf('@', caretPos - 1);
        // No @ found, no replacement
        if (lastAtIndex < 0) {
            return;
        }

        const before = value.substring(0, lastAtIndex + 1); // Include '@'
        const after = value.substring(caretPos);

        // Update searchValue with inserted mention
        this.searchValue = `${before}${suggestion.name} ${after}`;
        this.showMentionDropdown = false;

        // Restore focus and place caret after inserted mention
        setTimeout(() => {
            inputEl.focus();
            const newCaretPos = before.length + suggestion.name.length + 1;
            inputEl.setSelectionRange(newCaretPos, newCaretPos);
        });
    }

    private _checkMentionTrigger(value: string, caretPosition?: number): void {
        const position = caretPosition ?? value.length;

        // Find the last '@' before the caret
        const lastAt = value.lastIndexOf('@', position - 1);

        if (lastAt >= 0) {
            const mentionFragment = value.slice(lastAt + 1, position);

            // Only allow alphanumeric + underscore
            const validMention = /^[\w\d_]*$/.test(mentionFragment);

            if (validMention) {
                this.mentionSearchTerm = mentionFragment;

                // Filter suggestions
                this.filteredSuggestions = this.mentionSuggestions.filter(person =>
                    person.name?.toLowerCase().includes(mentionFragment.toLowerCase())
                );

                this.showMentionDropdown = this.filteredSuggestions.length > 0;
                return;
            }
        }

        // If no valid mention, hide dropdown
        this.showMentionDropdown = false;
    }
    //#endregion Mention


    protected closeFileDialog() {
        this.toggleFileUpload();
    }

    //#region Files
    protected startFileUpload($event: Event, allowMany = true): void {
        this.uploadMode = 'file';
        this.allowMultipleUploads = allowMany;
        this.op.toggle($event);
        setTimeout(() => {
            this.toggleFileUpload();
        }, 300);
    }
    // Unified change handler (replace onImageSelected or call it inside)
    protected onFilesSelected(evt: Event): void {
        const input = evt.target as HTMLInputElement;
        const files = Array.from(input.files ?? []);
        if (!files.length) {
            return;
        }
        this.handleFiles(files);
    }

    onFilesDrop(event: DragEvent) {
        event.preventDefault();
        this.isHovering = false;
        const files = Array.from(event.dataTransfer?.files ?? []);
        this.handleFiles(files);
    }

    private handleFiles(files: File[]) {
        if (!files?.length) {
            return;
        }

        this.startFilesLoading = true;
        const allowedTypes = new Set([
            'application/xml',             // .xml
            'application/json',            // .json
            'application/pdf',             // .pdf
            'application/msword',          // .doc
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
            'application/vnd.ms-excel',    // .xls
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
            'text/csv',                    // .csv
            'text/plain'                   // .txt
        ]);
        const errors: string[] = [];
        const dtos: Promise<FileToAiDto>[] = [];

        files.forEach(file => {
            if (!allowedTypes.has(file.type)) {
                errors.push(
                    `${file.name}: unsupported type (${file.type || 'unknown'}). Allowed: ${Array.from(allowedTypes).join(', ')}`
                );
                return;
            }
            // Convert file → FileToAiDto (async with FileReader)
            dtos.push(this.fileToDto(file));
        });

        if (errors.length) {
            this.uploadError = `Upload failed for some files:\n• ` + errors.join('\n• ');
        } else {
            this.uploadError = null;
        }

        // Wait until all conversions complete, then upload
        Promise.all(dtos).then(converted => {
            this.reactiveAIChatService.uploadFiles$(converted)
                .pipe(
                    take(1)
                )
                .subscribe({
                    next: () => {
                        this.selectedItems = converted;
                        this.startFilesLoading = false;
                    },
                    error: err => {
                        this.startFilesLoading = false;
                    }
                });
        });
    }

    private fileToDto(file: File): Promise<FileToAiDto> {
        return new Promise<FileToAiDto>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const dto = new FileToAiDto();
                dto.fileName = `ai-file-${file.name}`;
                dto.fileContent = (reader.result as string).split(',')[1]; // strip base64 prefix
                dto.id = createGuid();
                resolve(dto);
            };
            reader.onerror = err => reject(err);
            reader.readAsDataURL(file);
        });
    }

    // Call when you remove a file
    removeItem(id: string) {
        const item = this.selectedItems.find(x => x.fileName === id);
        this.selectedItems = this.selectedItems.filter(x => x.fileName !== id);
    }

    trackByUpload = (_: number, f: FileToAiDto) => f.fileName;

    sendWithFiles() {
        const tenancyName = this.appSession.tenant ? this.appSession.tenant.tenancyName : null;

        const messageInput = `${this.searchValue}\n\n` +
            `**Files:**\n` +
            this.selectedItems
                .map(f => `- ${f.fileName}`)
                .join('\n');

        const message = {
            tenantId: abp.session.tenantId,
            userId: abp.session.userId,
            message: InstructionInterceptor.convertMentionsToEvent(this.searchValue),
            displayMessage: messageInput,
            tenancyName: tenancyName,
            userName: this.appSession.user.userName,
            sessionId: this.sessionId,
            type: AIChatMessageType.User,
            fileKeys: _.map(this.selectedItems, item => item.id)
        };

        this.enterpriseSearchService.forceCloseFileUploadModal();
        this.enterpriseSearchService.startAIChat();
        this.enterpriseSearchService.triggerAdvancedSearch();
        this.clearInput();

        this._aiChatSignalrService.sendMessage(message, () => {
            //console.log('message delivered');
        });
    }
    //#endregion Files


    simulateTyping(text: string, speed: number = 50): Promise<void> {
        return new Promise<void>((resolve) => {
            this.searchValue = '';
            let index = 0;

            const interval = setInterval(() => {
                this.searchValue += text.charAt(index);
                index++;

                if (index === text.length) {
                    clearInterval(interval);
                    this.searchInput.nativeElement.focus();
                    resolve(); // resolves when typing is done
                }
            }, speed);
        });
    }

    sendToAIMessage(input: AIChatMessage) {
        this.enterpriseSearchService.startAIChat();
        this.enterpriseSearchService.triggerAdvancedSearch();
        this.clearInput();

        this.sendMessageToAI(input);
    }

    //Sending message via signalR
    private sendMessageToAI(input: AIChatMessage): void {
        if (!input) {
            return;
        }
        const tenancyName = this.appSession.tenant ? this.appSession.tenant.tenancyName : null;
        const message = {
            tenantId: abp.session.tenantId,
            userId: abp.session.userId,
            message: InstructionInterceptor.convertMentionsToEvent(input.content),
            displayMessage: input.content,
            tenancyName: tenancyName,
            userName: this.appSession.user.userName,
            type: AIChatMessageType.User,
            sessionId: input.sessionId
        };
        this._aiChatSignalrService.sendMessage(message, () => {
            //console.log('message delivered');
        });
    }

    protected onModesChange(event: any) {
        const mode = event.checked;
        if (mode) {
            this.enterpriseSearchService.setImageSearchMode();
        } else {
            this.enterpriseSearchService.setTextMode();
        }
    }

}
