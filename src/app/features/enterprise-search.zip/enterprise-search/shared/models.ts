import {
    AIChatMessageDto, AIChatMetricDto, AIPersonDescriptionDto, AISessionDto,
    EnterpriseSearchDataToElasticModelDto,
    EnterpriseSearchMetadataDto, SearchResultDto
} from '@shared/service-proxies/service-proxies';
import {AgentId, MessageId, EsPanelId, SessionId} from '@app/enterprise-search/shared/types';

export interface ESItem {
    date: Date;
    query: string;
    base64query: string;
}

export interface ESResult {
    data: SearchResultDto;
    query: ESItem;
}

export interface ESState {
    searchResults: ESResult[];
    loading: boolean;
}

export enum SearchResultType {
  Text = 'text',
  Video = 'video',
  Audio = 'audio',
}

export interface SearchResult {
  type: SearchResultType;
  title: string;
  description: string;
  link?: string;
  thumbnail?: string;
  video_url?: string;
  audio_url?: string;
  duration?: string;
}

export class ContextMenuData {
    event: MouseEvent;
    data: EnterpriseSearchDataToElasticModelDto;
}

export class CustomHistoryItem extends EnterpriseSearchMetadataDto {
    isPointer: boolean;
}

export interface ESSorting {
    name: string;
    value: boolean;
    order: string;
}

export enum AIChatEvents {
    Finished = '*|Finished|*',
    Pending = '*|Pending|*',
    Started = '*|Started|*',
    JoinedAI = '*|JoinedAI:',
    AddAI = '*|AddAI:',
    SearchResult = '*|SearchResult:'
}

export enum AIChatPendingEvents {
    _ = '*|Pending:',
    SearchingIntent = '*|Pending:SearchingIntent|*',
    SearchingFunction = '*|Pending:SearchingFunction|*',
    PreparingResult = '*|Pending:PreparingResult|*'
}

export type AllAIChatEvents = AIChatEvents | AIChatPendingEvents;

export enum ChatConnectionState {
    Disconnected = 'Disconnected',
    Connecting = 'Connecting',
    Connected = 'Connected',
    Reconnecting = 'Reconnecting'
}

export interface AIChatSession {
    id: string;
    participant: string[];
    messages: AIChatMessageDto[];
}

export interface GroupedAIChatMessageDto {
    id: string;
    messages: AIChatMessageDto[];
}

export interface AIChatMessage {
    id: MessageId;                // Unique message ID
    sessionId: SessionId;            // ID of the chat/conversation this message belongs to
    chatId: AgentId;            // ID of the chat/conversation this message belongs to
    owner: 'system' | 'user' | 'ai';          // User ID of the sender
    author: string;
    content: string;           // The actual text message
    timestamp: string;           // When the message was sent
    status?: 'sent' | 'delivered' | 'read' | 'failed' | string; // Message status
    finished: boolean;
}

export interface TypingIndicator {
    id: string; // unique per AI/user
    agentId?: string;
    name: string;
    message: string;
}

export interface ExtendedAIChatMessageDto extends AIChatMessageDto {
    fromQueue: boolean;
}

export interface QueuedAIChatMessageDto {
    message: ExtendedAIChatMessageDto;
    creationTime: string;
}

export interface ChatMessagesState {
    sessionId: SessionId;
    buckets: Record<SessionId, Record<MessageId, AIChatMessage>>;
    loading: boolean;
    error?: unknown;
}

export interface AIAgentMetricSummary {
    sessionId: SessionId;
    agentMetrics: AIAgentMetric[];
}
export interface AIAgentMetric {
    agent: AIPersonDescriptionDto;
    metric: AIChatMetricDto;
}

export interface EsPanel {
    id: EsPanelId;
    visible: boolean;
}

export interface GroupedSessions {
    pinned: AISessionDto[];
    others: AISessionDto[];
}
