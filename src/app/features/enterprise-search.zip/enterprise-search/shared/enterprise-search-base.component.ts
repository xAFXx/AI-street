
import {inject, Injector, OnDestroy, OnInit} from '@angular/core';
import { AppConsts } from '@shared/AppConsts';

import { AppComponentBase as BaseAppComponentBase } from '@axilla/axilla-shared';

import {PermissionCheckerService} from 'abp-ng2-module';
import {EnterpriseSearchService} from '@app/enterprise-search/services/enterprise-search.service';
import {Subject} from 'rxjs';
import {EsHistoryService} from '@app/enterprise-search/services/es-history.service';
import {EsPreviewService} from '@app/enterprise-search/services/es-preview.service';
import {take, takeUntil} from 'rxjs/operators';
import {ChatSignalrService} from '@appshared/layout/chat/chat-signalr.service';
import {AIChatSignalrService} from '@app/enterprise-search/services/ai-chat-signalr.service';
import _ from 'lodash';
import {EsPanelId, SessionId, UrlUpdateMode} from '@app/enterprise-search/shared/types';
import {AiLayoutService} from '@app/enterprise-search/services/layout.service';
import {AiSessionsService} from '@app/enterprise-search/services/ai-sessions.service';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';

export abstract class EnterpriseSearchComponentBase extends BaseAppComponentBase {
    remoteServiceBaseUrl: string = AppConsts.remoteServiceBaseUrl;
    localizationSourceName = AppConsts.localization.defaultLocalizationSourceName;

    protected aiSessionsService: AiSessionsService;
    protected enterpriseSearchService: EnterpriseSearchService;
    protected esHistoryService: EsHistoryService;
    protected esPreviewService: EsPreviewService;
    protected permissionChecker: PermissionCheckerService;
    protected _aiChatSignalrService: AIChatSignalrService;
    protected aiLayoutService: AiLayoutService;
    protected aiService: ReactiveAIChatService;
    protected aiAgentsService: AiAgentsService;

    protected _urlUpdateMode: UrlUpdateMode = 'router';
    set urlUpdateMode(value: UrlUpdateMode) {
        this._urlUpdateMode = value;
    }

    protected readonly destroy$ = new Subject<void>();

    rowsAmount = 9;

    get currentMetadata() {
        return this.esHistoryService.selectedMetadata;
    }

    historyMode: 'life' | 'historySearch' | 'history';
    isShowSearchResult: boolean;
    isHistoryMode: boolean;

    //Detect selected sessions
    protected selectedId: SessionId | null = null;

    protected constructor(injector: Injector) {
        super(injector);

        this.permissionChecker = injector.get(PermissionCheckerService);
        this.enterpriseSearchService = injector.get(EnterpriseSearchService);
        this.esHistoryService = injector.get(EsHistoryService);
        this.esPreviewService = injector.get(EsPreviewService);
        this._aiChatSignalrService = injector.get(AIChatSignalrService);
        this.aiLayoutService = injector.get(AiLayoutService);
        this.aiSessionsService = injector.get(AiSessionsService);
        this.aiService = injector.get(ReactiveAIChatService);
        this.aiAgentsService = injector.get(AiAgentsService);

    }

    protected getIconType(value: string) {
        let data = value.split('.');
        if (data.length > 1) {
            return data[data.length - 1];
        }
        return data[0];
    }

    getImgUrl(itemTitle: string): string {
        return this.appRootUrl() + 'assets/common/images/no-video-available.jpg';
        //return `${this.remoteServiceBaseUrl}/Search/${this.appSession.tenant.id}/GetItemImage/${itemTitle}.jpg`;
    }

    appRootUrl(): string {
        return this.appUrlService.appRootUrl;
    }

    protected translate(key: string, source: string) {
        let localizationSources = [];
        _.each(abp.localization.sources, (source) => {
            localizationSources.unshift(source.name);
        });

        let text = abp.localization.localize(key, source);

        for (let source of localizationSources) {
            text = abp.localization.localize(key, source);
            if (text !== key) {
                break;
            }
        }

        return text;
    }

    closePanel(panelId: EsPanelId): void {
        this.aiLayoutService.closePanel(panelId);
    }

    //#region Sessions
    newSession() {
        let message = this.ls('Axilla', 'Axilla.AI.Sessions.CreateNewMessage');
        let title = this.ls('Axilla', 'Axilla.AI.Sessions.CreateNewTitle');

        abp.message.confirm(message,
            title,
            (result: boolean) => {
                if (result) {
                    this.clearSession();
                    this.aiSessionsService.createNewSession();
                }
            });

    }

    protected clearSession() {
        this.selectedId = null;
        this.onSelect(null); // optional
        this.aiSessionsService.clear();
    }

    protected onSelect(id: string): void {
        if (!id) {
            return;
        }

        // Update the store selection
        const ok = this.aiSessionsService.selectSession(id);
        if (!ok) {
            return;
        }

        this.aiService.clearAllIndicators();
        this.updateAvailableAgent(id);

        // Update URL per chosen mode
        switch (this.urlUpdateMode) {
            case 'router':
                this.aiSessionsService.navigateToSession(id); // no reload; replaceUrl: true inside
                break;
            case 'location':
                this.aiSessionsService.setSessionIdInUrl(id, true); // replaceState only
                break;
            case 'none':
            default:
                // do nothing
                break;
        }
    }

    updateAvailableAgent(sid: string) {
        if (!sid) {
            return;
        }

        this.aiAgentsService.getAvailableAssistant$(sid)
            .pipe(
                take(1)
            )
            .subscribe();
    }

    //#endregion Sessions
}

