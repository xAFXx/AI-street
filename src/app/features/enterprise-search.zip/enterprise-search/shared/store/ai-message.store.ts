import {inject, Injectable} from '@angular/core';
import {ComponentStore} from '@ngrx/component-store';
import {from, Observable, of} from 'rxjs';
import {catchError, filter, map, shareReplay, switchMap, tap, withLatestFrom} from 'rxjs/operators';
import dayjs from 'dayjs';

import {
    AIChatMessageDto,
    AIChatMessageType,
    AIChatServiceProxy,
    ChatMessageReadState,
    ChatSide,
    ListResultDtoOfAIChatMessageDto,
} from '@shared/service-proxies/service-proxies';

import {
    AIChatEvents,
    AIChatMessage,
    ChatMessagesState,
    ExtendedAIChatMessageDto,
} from '@app/enterprise-search/shared/models';
import {MessageId, SessionId} from '@app/enterprise-search/shared/types';
import {convertMessage, sanitizeAIChatMessage, subtract} from '@app/enterprise-search/shared/helpers/helpers';
import {filterByChatEvent} from '@app/enterprise-search/shared/rxjs/filter/filterByChatEvent';
import {filterOutByChatEvent} from '@app/enterprise-search/shared/rxjs/filter/filterOutByChatEvent';

@Injectable({ providedIn: 'root' })
export class ChatMessagesStore extends ComponentStore<ChatMessagesState> {
    private static readonly GREETING_ID = 'system-greeting';

    private readonly api = inject(AIChatServiceProxy);

    private readonly brandNewSessions = new Set<SessionId>();

    constructor() {
        super({ sessionId: null, buckets: {}, loading: false });

        const sid = ChatMessagesStore.GREETING_ID;
        const greeting = this.makeGreetingMessage(sid);
        const key = this.messageKey(greeting); // system → id-timestamp

        this.patchState(state => ({
            ...state,
            buckets: {
                ...state.buckets,
                [sid]: { [key]: greeting }
            }
        }));
    }

    // ============= SELECTORS =============
    readonly sessionId$ = this.select(s => s.sessionId);
    private readonly bucketForCurrent$ = this.select(s => s.buckets[s.sessionId ?? ChatMessagesStore.GREETING_ID] ?? {});

    /** Sorted messages for current session */
    readonly messagesForCurrent$: Observable<AIChatMessage[]> = this.bucketForCurrent$.pipe(
        map(bucket => Object.values(bucket)),
        map((list) => {
            return Array.from(list.values()).sort((a, b) => {
                const firstA = a[0];
                const firstB = b[0];

                if (!firstA || !firstB) {
                    return 0;
                }

                return dayjs(firstA.timestamp).unix() - dayjs(firstB.timestamp).unix();
            });
        }),
        shareReplay(1)
    );

    readonly loading$ = this.select(s => s.loading);
    readonly error$ = this.select(s => s.error);

    // ============= UPDATERS =============
    // private readonly setSession = this.updater((state, sessionId: SessionId): ChatMessagesState => ({
    //     ...state,
    //     sessionId,
    //     buckets: state.buckets[sessionId]
    //         ? state.buckets
    //         : { ...state.buckets, [sessionId]: {} }
    // }));

    private readonly ensureGreetingFor = this.updater(
        (s, p: { sessionId: SessionId; beforeTimestamp?: string }) => {
            const { sessionId, beforeTimestamp } = p;
            if (!sessionId) {
                return s;
            }

            const bucket = { ...(s.buckets[sessionId] ?? {}) };
            const hasGreeting = Object.keys(bucket).some(
                k => k === 'system-greeting' || k.startsWith('system-greeting-')
            );
            if (hasGreeting) {
                return s;
            }

            const greeting = this.makeGreetingMessage(sessionId);
            if (beforeTimestamp) {
                greeting.timestamp = subtract(beforeTimestamp);
            }
            const key = this.messageKey(greeting); // system => id-timestamp
            return {
                ...s,
                buckets: {
                    ...s.buckets,
                    [sessionId]: { ...bucket, [key]: greeting }
                }
            };
        }
    );

    private readonly removeGreeting = this.updater((s, sessionId: SessionId) => {
        if (!sessionId) {
            return s;
        }
        const bucket = { ...(s.buckets[sessionId] ?? {}) };
        const gid = ChatMessagesStore.GREETING_ID;
        for (const k of Object.keys(bucket)) {
            if (k === gid || k.startsWith(`${gid}-`)) {
                delete bucket[k];
            }
        }
        return { ...s, buckets: { ...s.buckets, [sessionId]: bucket } };
    });

    private readonly setSession = this.updater((state, sessionId: SessionId) => {
        if (!sessionId) {
            return { ...state, sessionId: null };
        }

        const bucket = state.buckets[sessionId] ?? {};

        // If bucket already has content, just switch
        if (Object.keys(bucket).length > 0) {
            return { ...state, sessionId };
        }

        // Create empty bucket by default
        let nextBucket: Record<string, AIChatMessage> = {};

        // Seed greeting ONLY if this session was flagged as brand-new
        if (this.brandNewSessions.has(sessionId)) {
            const greeting = this.makeGreetingMessage(sessionId);
            const key = this.messageKey(greeting); // system => id-timestamp
            nextBucket = { [key]: greeting };
            this.brandNewSessions.delete(sessionId); // one-time use
        }

        return {
            ...state,
            sessionId,
            buckets: { ...state.buckets, [sessionId]: nextBucket }
        };
    });

    private readonly clearBucket = this.updater((state): ChatMessagesState => {
        const id = state.sessionId;
        if (!id) {
            return state;
        }
        return { ...state, buckets: { ...state.buckets, [id]: {} } };
    });

    private readonly setLoading = this.updater((state, loading: boolean) => ({ ...state, loading }));
    private readonly setError = this.updater((state, error: unknown) => ({ ...state, error }));

    /** ONE-BY-ONE upsert with simple append/replace rules */
    readonly upsertOne = this.updater((s, payload: { sessionId: SessionId; m: AIChatMessage }) => {
        console.log(payload);
        const { sessionId, m } = payload;
        if (!sessionId) {
            return s;
        }

        const bucket = { ...(s.buckets[sessionId] ?? {}) };
        const merged = this._mergeOne(bucket, m);
        return { ...s, buckets: { ...s.buckets, [sessionId]: merged } };
    });

    private readonly clearCurrent = this.updater((s) => {
        const id = s.sessionId;
        if (!id) { return s; }
        return { ...s, buckets: { ...s.buckets, [id]: {} } };
    });

    /** Batch upsert that reuses the exact same merge logic as upsertOne */
    private readonly upsertMany = this.updater(
        (state, payload: { sessionId: SessionId; items: AIChatMessage[] }): ChatMessagesState => {
            const { sessionId, items } = payload;
            if (!sessionId || !items?.length) {
                return state;
            }

            let bucket = { ...(state.buckets[sessionId] ?? {}) };
            for (const m of items) {
                bucket = this._mergeOne(bucket, m);
            }
            return { ...state, buckets: { ...state.buckets, [sessionId]: bucket } };
        }
    );

    private readonly markFinished = this.updater((s, p: { sessionId: SessionId; messageId: MessageId }) => {
        const { sessionId, messageId } = p;
        const bucket = { ...(s.buckets[sessionId] ?? {}) };
        const ex = bucket[messageId];
        if (ex) {
            bucket[messageId] = { ...ex, finished: true, status: 'delivered' };
            return { ...s, buckets: { ...s.buckets, [sessionId]: bucket } };
        }
        return s;
    });


    // ============= EFFECTS =============

    /** Live per-dto ingestion (call once with your SignalR per-message stream) */
    readonly ingestUserMessage = this.effect(
        (userInput$: Observable<ExtendedAIChatMessageDto & { sessionId?: string; chatId?: string }>) =>
            userInput$.pipe(
                map(dto => this.convertDto(dto)),
                // accept sessionId OR chatId
                filter(m => !!(m.sessionId || m.chatId)),
                withLatestFrom(this.sessionId$),
                tap(([m, activeSid]) => {
                    const sid = (m.sessionId as string) || (m.chatId as string) || activeSid;

                    console.groupCollapsed('[ChatMessagesStore] ingestUserMessage');
                    console.log('incoming:', m);
                    console.log('active sessionId:', activeSid);
                    console.log('resolved sid:', sid);

                    // BEFORE
                    this._debugPrintBucket(sid, 'before upsert');

                    // Optional: for brand-new session make sure greeting comes first
                    if (!activeSid) {
                        this.ensureGreetingFor({ sessionId: sid, beforeTimestamp: m.timestamp });
                    }

                    // UPSERT the user message
                    this.upsertOne({ sessionId: sid, m });

                    // AFTER
                    this._debugPrintBucket(sid, 'after upsert');
                    this._debugPrintAllBuckets('snapshot');

                    console.groupEnd();
                })
            )
    );

    /** Live per-dto ingestion (call once with your SignalR per-message stream) */
    readonly ingestLiveDto = this.effect(
        (live$: Observable<AIChatMessageDto & { sessionId?: string; chatId?: string }>) =>
            live$.pipe(
                filterOutByChatEvent(AIChatEvents.Started, AIChatEvents.Finished),
                map(dto => sanitizeAIChatMessage(dto)),
                map(dto => this.convertDto(dto)),
                withLatestFrom(this.sessionId$),
                filter(([, sid]) => !!sid),
                map(([m, sid]) => this.ensureSessionAndChat(sid as string, m)),
                withLatestFrom(this.sessionId$),
                filter(([m, active]) => (m.sessionId ?? m.chatId) === active),
                tap(([m]) => {
                    const sid = (m.sessionId as string) || (m.chatId as string);

                    // If this is a brand-new session: ensure greeting comes first, then append the message
                    if (this.brandNewSessions.has(sid)) {
                        this.ensureGreetingFor({ sessionId: sid, beforeTimestamp: m.timestamp });
                        this.brandNewSessions.delete(sid); // one-shot
                    }

                    this.upsertOne({ sessionId: sid, m });
                })
            )
    );

    /** Finished event ingestion (per-event) */
    readonly ingestFinished = this.effect(
        (finished$: Observable<{ id: MessageId; sessionId?: SessionId; chatId?: SessionId }>) =>
            finished$.pipe(
                withLatestFrom(this.sessionId$),
                tap(([evt, active]) => {
                    const sid = evt.sessionId ?? evt.chatId ?? active;
                    if (sid) {
                        this.markFinished({ sessionId: sid, messageId: evt.id });
                    }
                })
            )
    );

    /** Session change: reset + load history one-by-one */
    readonly connectToSession = this.effect((sessionId$: Observable<string>) =>
        sessionId$.pipe(
            // Start loading state
            tap(() => { this.setLoading(true); this.setError(undefined); }),

            // IMPORTANT: clear the old bucket BEFORE seeding the new one
            tap(() => this.clearCurrent()),

            // Set the new session → seeds greeting if bucket is new/empty
            tap((id) => this.setSession(id)),

            switchMap((sessionId) => {
                    return this.api.getUserChatHistoryMessages(sessionId, 100, 0).pipe(
                        map(res => res?.items ?? []),

                        // If server returned any messages → drop greeting
                        tap(items => {
                            if (items.length > 0) {
                                this.removeGreeting(sessionId);
                            }
                        }),

                        // Upsert history one-by-one
                        switchMap(items => from(items)),
                        map(dto => sanitizeAIChatMessage(dto)),
                        map(dto => this.convertDto(dto)),
                        map(m => this.ensureSessionAndChat(sessionId, m)),
                        tap(m => this.upsertOne({ sessionId, m })),

                        catchError(err => { this.setError(err); return of(null); }),
                        tap(() => this.setLoading(false))
                    );
                }
            )
        )
    );

    /** Optional: insert optimistic message immediately when user sends */
    upsertOptimistic(partial: Omit<AIChatMessage, 'timestamp' | 'status'> & { timestamp?: string; status?: AIChatMessage['status'] }) {
        const sid = this.get(state => state.sessionId);
        if (!sid) {
            return;
        }

        const msg: AIChatMessage = {
            ...partial,
            sessionId: partial.sessionId ?? sid,
            timestamp: partial.timestamp ?? dayjs().format('DD-MM-YYYY HH:mm:ss'),
            status: partial.status ?? 'sent',
        };
        this.upsertMany({ sessionId: sid, items: [msg] });
    }

    // ============= HELPERS (mapping + merge) =============

    /** Map DTO → your AIChatMessage shape */
    private convertDto(input: AIChatMessageDto | ExtendedAIChatMessageDto): AIChatMessage {
        const sessionId = (input as any).sessionId as string | undefined;
        const chatId =
            ((input as any).chatId as string | undefined) ||
            sessionId ||
            String(input.id);

        const base = {
            ...convertMessage(input),
            sessionId,
            chatId,
            finished: true,
            status: 'delivered'
        };

        if (input.side === ChatSide.Sender) {
            return { ...base, owner: 'user', finished: true };
        }

        if (base.owner === 'system') {
            return { ...base };
        }

        // AI (Receiver): default unfinished until Finished event arrives
        return {
            ...base,
            owner: 'ai',
            author: (input as any).sender?.name ?? '',
            finished: input.type !== AIChatMessageType.AI
        };
    }

    /** Ensure session/chat ids are present */
    private ensureSessionAndChat(activeSessionId: SessionId, m: AIChatMessage): AIChatMessage {
        return {
            ...m,
            sessionId: m.sessionId ?? activeSessionId,
            chatId: m.chatId || m.sessionId || activeSessionId
        };
    }

    private messageKey(m: AIChatMessage): MessageId {
        return m.owner === 'system' ? `${m.id}-${m.timestamp}` : m.id;
    }

    /** Single, tiny merge rule used everywhere (append tail for AI snapshots; else replace if newer) */
    private _mergeOne(bucket: Record<string, AIChatMessage>, msg: AIChatMessage): Record<string, AIChatMessage> {
        // Use id-timestamp for system; plain id for others
        const key = (msg.owner === 'system') ? `${msg.id}-${msg.timestamp}` : msg.id;

        // If it's system — always a new entry under unique key
        if (msg.owner === 'system') {
            return { ...bucket, [key]: msg };
        }

        const existing = bucket[key];
        if (!existing || existing.content === msg.content) {
            // first time we see this id
            return { ...bucket, [key]: msg };
        }

        // append chunk + update timestamp (no other conditions)
        return {
            ...bucket,
            [key]: {
                ...existing,
                content: (existing.content ?? '') + (msg.content ?? ''),
                timestamp: msg.timestamp
            }
        };
    }

    /** Call this right before selecting a newly created sessionId */
    markBrandNewSession(sessionId: SessionId): void {
        if (sessionId) {
            this.brandNewSessions.add(sessionId);
        }
    }

    /** Mark a session as brand-new and log its bucket (and all buckets). */
    startNewSession(sessionId: SessionId = ChatMessagesStore.GREETING_ID): void {
        // pick provided id or fall back to current selection
        const sid = sessionId ?? this.get(s => s.sessionId);

        if (!sid) {
            // No session -> just print everything we have
            const snapshot = this.get(s => s);
            console.warn('[ChatMessagesStore] startNewSession: no sessionId. Printing all buckets.');
            console.dir(snapshot.buckets);
            return;
        }

        // 1) mark this session as brand-new (so setSession will seed greeting)
        this.brandNewSessions.add(sid);

        // 2) ensure bucket exists & seed greeting if empty
        this.setSession(sid);

        // 3) print the bucket contents for this session
        const state = this.get(s => s);
        const bucket = state.buckets[sid] ?? {};

        console.group(`[ChatMessagesStore] Bucket for session ${sid}`);
        console.log('count:', Object.keys(bucket).length, 'keys:', Object.keys(bucket));
        console.table(Object.values(bucket));
        console.groupEnd();

        // 4) (optional) also show all buckets
        console.groupCollapsed('[ChatMessagesStore] All buckets');
        console.dir(state.buckets);
        console.groupEnd();
    }

    /** Create the initial greeting message in the correct DTO type */
    private makeGreetingMessage(sessionId: SessionId): AIChatMessage {
        const dto = {
            id: ChatMessagesStore.GREETING_ID,
            userId: 0,
            tenantId: undefined,
            targetUserId: 0,
            targetTenantId: undefined,
            side: ChatSide.Receiver,
            type: AIChatMessageType.System,
            readState: ChatMessageReadState.Unread,
            receiverReadState: ChatMessageReadState.Unread,
            sender: { name: 'system' } as any,
            message:
                'Hello! I’d like to start a conversation with you. Please help me with [your topic here].\n(To send this message, press Ctrl + Enter.)',
            displayMessage:
                'Hello! I’d like to start a conversation with you. Please help me with [your topic here].\n(To send this message, press Ctrl + Enter.)',
            creationTime: dayjs(),
            sharedMessageId: undefined
        } as AIChatMessageDto;
        return convertMessage(dto);
    }

    /** Convert an array of messages to the API list shape */
    private toListResult(items: AIChatMessageDto[]) {
        return { items: items } as ListResultDtoOfAIChatMessageDto;
    }

    /** Debug: print a specific session bucket */
    private _debugPrintBucket(sessionId: SessionId, tag = 'bucket'): void {
        const bucket = this.get(s => s.buckets[sessionId ?? ''] ?? {});
        console.groupCollapsed(`[ChatMessagesStore] ${tag} (sessionId=${sessionId})`);
        console.log('keys:', Object.keys(bucket));
        console.table(Object.values(bucket));
        console.groupEnd();
    }

    /** Debug: print all buckets + message counts per session */
    private _debugPrintAllBuckets(tag = 'all buckets'): void {
        const buckets = this.get(s => s.buckets);
        console.groupCollapsed(`[ChatMessagesStore] ${tag}`);
        console.log('sessionIds:', Object.keys(buckets));
        console.dir(buckets);
        console.groupEnd();
    }
}
