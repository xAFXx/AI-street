import { Injectable } from '@angular/core';
import { ComponentStore } from '@ngrx/component-store';
import { ESResult, ESState} from '../models';

@Injectable({
    providedIn: 'root',
})
export class ESStore extends ComponentStore<ESState> {
    constructor() {
        super({
            searchResults: [],
            loading: false,
        });
    }

    // Selectors to get specific data from the state
    readonly searchResults$ = this.select(state => state.searchResults);
    readonly loading$ = this.select(state => state.loading);

    readonly addSearchResult = this.updater((state, newResult: ESResult) => ({
        ...state,
        searchResults: [newResult, ...state.searchResults],
    }));

    // Updaters
    readonly setSearchResults = this.updater((state, searchResults: ESResult[]) => ({
        ...state,
        searchResults,
    }));

    readonly setLoading = this.updater((state, loading: boolean) => ({
        ...state,
        loading,
    }));

    // Method to reset the store state
    readonly reset = this.updater(() => ({
        searchResults: [],
        loading: false,
    }));

    // Method to get an item by its id
    readonly getItemById = (id: string) =>
        this.select(state =>
            state.searchResults.find(result => result.data.metadata.searchId === id) ?? null
        )

    // Method to check if an item is available in the store
    readonly checkIfItemAvailableInStore = (id: string): boolean => {
        const state = this.get();
        return state.searchResults.some(result => result.data.metadata.searchId === id);
    }

    //Method to get paginated results
    readonly getPaginatedResults = (skip: number, take: number, filterFn?: (item: ESResult) => boolean) => {
        return this.select(state => {
            let filteredResults = state.searchResults;

            // Apply filtering if a filter function is provided
            if (filterFn) {
                filteredResults = filteredResults.filter(filterFn);
            }

            // Get total count after filtering
            const total = filteredResults.length;

            // Apply pagination
            const paginatedResults = filteredResults.slice(skip, skip + take);

            return {
                items: paginatedResults,
                total
            };
        });
    }

    // Method to get the last entry
    readonly getLastEntry = () => this.select(state => {
        const lastIndex = state.searchResults.length - 1;
        return lastIndex >= 0 ? state.searchResults[0] : null;
    })

}
