import { Observable, PartialObserver, Subscription } from 'rxjs';
import { take, shareReplay } from 'rxjs/operators';

export function run<T>(input: Observable<T>, observer?: PartialObserver<T>, count?: number): Subscription;
// tslint:disable-next-line:unified-signatures
export function run<T>(input: Observable<T>, next?: (value: T) => void, count?: number): Subscription;
export function run<T>(input: Observable<T>, observer?: any, count?: number): Subscription {
    count = count || 1;
    const run$ = input.pipe(
        take(count),
    );
    return run$.subscribe(observer);
}

export function run$<T>(input: Observable<T>, observer?: PartialObserver<T>, count?: number): Observable<T>;
// tslint:disable-next-line:unified-signatures
export function run$<T>(input: Observable<T>, next?: (value: T) => void, count?: number): Observable<T>;
export function run$<T>(input: Observable<T>, observer?: any, count?: number): Observable<T> {
    count = count || 1;
    const run$ = input.pipe(
        take(count),
        shareReplay(1)
    );
    run$.subscribe(observer);
    return run$;
}
