import { Observable, PartialObserver } from 'rxjs';
import { shareReplay, take } from 'rxjs/operators';

export function shareRun<T>(input: Observable<T>, observer?: PartialObserver<T>, count?: number): Observable<T>;
// tslint:disable-next-line:unified-signatures
export function shareRun<T>(input: Observable<T>, next?: (value: T) => void, count?: number): Observable<T>;
export function shareRun<T>(input: Observable<T>, observer?: any, count?: number): Observable<T> {
    count = count || 1;
    const run$ = input.pipe(
        take(count),
        shareReplay(count)
    );
    run$.subscribe(observer);
    return run$;
}
