import { MonoTypeOperatorFunction } from 'rxjs';
import { filter } from 'rxjs/operators';
import {MessageId} from '@app/enterprise-search/shared/types';

/**
 * Filters values when currentMessageId is NOT set (null or undefined).
 */
export function filterWhenCurrentMessageIdNotSet<T>(
    getCurrentMessageId: () => MessageId | undefined | null
): MonoTypeOperatorFunction<T> {
    return filter(() => getCurrentMessageId() == null);
}
