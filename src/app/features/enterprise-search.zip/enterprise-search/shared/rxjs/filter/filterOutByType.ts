import { MonoTypeOperatorFunction } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AIChatMessageType } from '@shared/service-proxies/service-proxies';
import { ExtendedAIChatMessageDto } from '@app/enterprise-search/shared/models';

export function filterOutByType<T extends ExtendedAIChatMessageDto>(
    type: AIChatMessageType
): MonoTypeOperatorFunction<T> {
    return filter((m): m is T => m.type !== type);
}

export function filterOutByTypes<T extends ExtendedAIChatMessageDto>(
    ...types: AIChatMessageType[]
): MonoTypeOperatorFunction<T> {
    const deny = new Set(types);
    return filter((m): m is T => !deny.has(m.type));
}
