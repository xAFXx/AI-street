import { MonoTypeOperatorFunction, Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import {
    AllAIChatEvents,
} from '@app/enterprise-search/shared/models';

// Keep only items whose `message` contains ANY of the specified events
export function filterByChatEvent<T extends { message?: string }>(
    ...events: AllAIChatEvents[]
): MonoTypeOperatorFunction<T> {
    return filter((m): m is T => {
        const msg = m.message ?? '';
        return events.some(ev => msg.includes(ev));
    });
}
