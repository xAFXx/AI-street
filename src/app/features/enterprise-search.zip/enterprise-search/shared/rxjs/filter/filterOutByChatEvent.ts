import { MonoTypeOperatorFunction, Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import {AIChatEvents, ExtendedAIChatMessageDto} from '@app/enterprise-search/shared/models';

// Exclude items whose `message` contains ANY of the specified events
export function filterOutByChatEvent<T extends { message?: string }>(
    ...events: AIChatEvents[]
): MonoTypeOperatorFunction<T> {
    return filter((m): m is T => {
        const msg = m.message ?? '';
        return !events.some(ev => msg.includes(ev));
    });
}
