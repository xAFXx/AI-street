import {MonoTypeOperatorFunction, Observable, OperatorFunction, withLatestFrom} from 'rxjs';
import {filter, map} from 'rxjs/operators';
import { MessageId } from '@app/enterprise-search/shared/types';

export function filterOutByCurrentMessageId<T extends { id: MessageId }>(
    getCurrentId: () => MessageId | undefined
): MonoTypeOperatorFunction<T> {
    return filter((m): m is T => {
        const cur = getCurrentId();
        return cur == null || m.id !== cur; // pass all if unset
    });
}

export function filterOutByCurrentMessageId$<T extends { id: MessageId }>(
    currentId$: Observable<MessageId | undefined>
): OperatorFunction<T, T> {
    return source => source.pipe(
        withLatestFrom(currentId$),
        filter(([m, id]) => id == null || m.id !== id),
        map(([m]) => m)
    );
}
