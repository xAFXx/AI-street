import { MonoTypeOperatorFunction } from 'rxjs';
import { filter } from 'rxjs/operators';
import {AIChatMessageType} from '@shared/service-proxies/service-proxies';
import {ExtendedAIChatMessageDto} from '@app/enterprise-search/shared/models';

export function filterByType<T extends ExtendedAIChatMessageDto>(
    type: AIChatMessageType
): MonoTypeOperatorFunction<T> {
    return filter((m): m is T & { type: typeof type } => m.type === type);
}
