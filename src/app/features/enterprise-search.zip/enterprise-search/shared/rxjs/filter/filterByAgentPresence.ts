import { MonoTypeOperatorFunction, filter } from 'rxjs';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';

export function filterByAgentPresence<T>(
    svc: AiAgentsService,
    getName: (item: T) => string,
    shouldExist: boolean // true => pass if exists, false => pass if not exists
): MonoTypeOperatorFunction<T> {
    return source$ =>
        source$.pipe(
            filter(item => {
                const name = (getName(item) ?? '').trim().toLocaleLowerCase();
                const exists = (svc.aiAgents ?? []).some(a =>
                    (a?.name ?? '').trim().toLocaleLowerCase() === name
                );
                return shouldExist ? exists : !exists;
            })
        );
}
