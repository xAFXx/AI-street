import { MonoTypeOperatorFunction } from 'rxjs';
import { filter } from 'rxjs/operators';
import { MessageId } from '@app/enterprise-search/shared/types';

export function filterByCurrentMessageId<T extends { id: MessageId }>(
    getCurrentId: () => MessageId | undefined
): MonoTypeOperatorFunction<T> {
    return filter((m): m is T => m.id === getCurrentId());
}
