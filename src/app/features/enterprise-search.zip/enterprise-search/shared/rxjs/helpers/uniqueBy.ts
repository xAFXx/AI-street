import { OperatorFunction } from 'rxjs';
import { filter, scan, map } from 'rxjs/operators';

export function uniqueBy<T>(keyFn: (x: T) => string): OperatorFunction<T, T> {
    return source => source.pipe(
        scan((acc, x) => {
            const k = keyFn(x);
            if (acc.seen.has(k))  {
                return acc;
            } // drop
            acc.seen.add(k);
            acc.last = x;
            return acc;
        }, { seen: new Set<string>(), last: undefined as T | undefined }),
        filter(acc => !!acc.last),
        map(acc => acc.last as T)
    );
}
