import { MonoTypeOperatorFunction } from 'rxjs';
import { tap, ignoreElements } from 'rxjs/operators';
import {ExtendedAIChatMessageDto} from '@app/enterprise-search/shared/models';

export function handleStartedEventSilently(
    hideLoader: () => void,
    isCurrentIdNotSet: () => boolean,
    changeAssistant: (m: ExtendedAIChatMessageDto) => void
): MonoTypeOperatorFunction<ExtendedAIChatMessageDto> {
    return source => source.pipe(
        tap((m: ExtendedAIChatMessageDto) => {
            // same logic as your _messageEventStarted$
            hideLoader();
            if (isCurrentIdNotSet()) {
                changeAssistant(m);
            }
        }),
        ignoreElements() // <- side-effects only; emit nothing to UI
    );
}
