import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import {TokenService} from 'abp-ng2-module';

@Injectable({
    providedIn: 'root'
})
export class ESDataResolver  {
    constructor(
        private tokenService: TokenService,
        private reactiveAIChatService: ReactiveAIChatService,
    ) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
        const token = this.tokenService.getToken();

        // Not authenticated => do nothing, allow navigation to login
        if (!token) {
            return of(null);
        }

        return this.reactiveAIChatService.initialize()
            .pipe(
                catchError((error) => {
                    console.error('Error in resolver:', error);
                    return of(null);  // or handle error as needed
                })
            );
    }
}
