import {AIChatMessageDto, AIChatMessageType, ChatSide} from '@shared/service-proxies/service-proxies';
import {AIChatEvents, AIChatMessage, ExtendedAIChatMessageDto} from '@app/enterprise-search/shared/models';
import dayjs from '@node_modules/dayjs';
import {InstructionInterceptor} from '@app/enterprise-search/shared/helpers/instruction-interceptor';

/**
 * Count words in a string.
 * - Uses Intl.Segmenter when available (locale-aware).
 * - Fallback regex handles Unicode letters/numbers and inner apostrophes/hyphens.
 */
export function countWords(
    text: string,
    locales: string | string[] = ['uk', 'ru', 'en']
): number {
    if (!text) {
        return 0;
    }

    // Prefer locale-aware segmentation
    const AnyIntl: any = typeof Intl !== 'undefined' ? Intl : undefined;
    if (AnyIntl?.Segmenter) {
        const seg = new AnyIntl.Segmenter(locales, { granularity: 'word' });
        let count = 0;
        for (const s of seg.segment(text)) {
            if (s.isWordLike) {
                count++;
            }
        }
        return count;
    }

    // Fallback: Unicode-aware regex (letters/numbers, allow inner ' ’ -)
    const tokens = text.match(/[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*/gu);
    return tokens ? tokens.length : 0;
}


export function wordStats(
    text: string,
    locales: string | string[] = ['uk', 'ru', 'en']
) {
    const normalize = (w: string) => w.toLocaleLowerCase(
        Array.isArray(locales) ? locales[0] : locales
    );

    const AnyIntl: any = typeof Intl !== 'undefined' ? Intl : undefined;
    let words: string[] = [];

    if (AnyIntl?.Segmenter) {
        const seg = new AnyIntl.Segmenter(locales, { granularity: 'word' });
        for (const s of seg.segment(text || '')) {
            if (s.isWordLike) {
                words.push(normalize(s.segment));
            }
        }
    } else {
        const tokens = (text || '').match(/[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*/gu) || [];
        words = tokens.map(normalize);
    }

    const freq = new Map<string, number>();
    for (const w of words) {
        freq.set(w, (freq.get(w) ?? 0) + 1);
    }

    return {
        count: words.length,
        uniqueCount: freq.size,
        frequencies: freq,                            // Map<word, count>
        top: [...freq.entries()].sort((a, b) => b[1] - a[1]) // sorted array
    };
}

export function extractName(input: string): string {
    const trimmed = (input ?? '').trim();
    if (!trimmed) {
        return '';
    }

    // Remove a trailing status word (case-insensitive)
    const match = trimmed.match(/^(.+?)\s+(offline|online|away|busy|idle|dnd|typing|connected|disconnected|inactive|active)$/i);
    return match ? match[1] : trimmed;
}

export function convertMessage(input: AIChatMessageDto | ExtendedAIChatMessageDto): AIChatMessage {
    const message = {
        id: input.id,
        content: input.displayMessage,
        timestamp: dayjs(input.creationTime).format('DD-MM-YYYY HH:mm:ss'),
        author: '',
        owner: 'system',
        finished: true
    } as AIChatMessage;

    if (input.side === ChatSide.Sender) {
        message.owner = 'user';
    } else if (input.side === ChatSide.Receiver) {
        if (input.type === AIChatMessageType.System) {
            message.owner = 'system';
        } else if (input.type === AIChatMessageType.AI || input.message.includes(AIChatEvents.SearchResult)) {
            message.author = input.sender.name;
            message.owner = 'ai';
            message.finished = false;
        }
    }

    return message;
}

export function subtract(beforeTimestamp: string) {
    const fmt = 'DD-MM-YYYY HH:mm:ss';
    return dayjs(beforeTimestamp, fmt).subtract(1, 'second').format(fmt);
}

export function sanitizeAIChatMessage(input: AIChatMessageDto | ExtendedAIChatMessageDto)
    : AIChatMessageDto | ExtendedAIChatMessageDto {
    const id = getSearchId(input.message ?? '');
    if (id) {
        input.displayMessage = InstructionInterceptor.replaceSearchResultTokens(id, input.displayMessage);
    }
    return input; // always pass a message through
}

export function getSearchId(message: string): string | null {
    const match = message.match(/\*\|SearchResult:(.*?)\|\*/);
    return match ? match[1] : null;
}

export function createGuid(): string {
    // xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}
