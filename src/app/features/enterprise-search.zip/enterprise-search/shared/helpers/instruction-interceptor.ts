import {AIChatMessageDto, AIChatMessageType, IAIChatMessageDto} from '@shared/service-proxies/service-proxies';
import {ExtendedAIChatMessageDto} from '@app/enterprise-search/shared/models';

export class InstructionInterceptor {
    static intercept(message: IAIChatMessageDto, handler: (message: IAIChatMessageDto) => boolean): boolean {
        if (message.type === AIChatMessageType.Events) {
            return handler(message);
        }
        return false;
    }

    static transformMessageText(message: string): string {
        return InstructionInterceptor.pipe(
            message
            , InstructionInterceptor.replaceJoinedAI
        );
    }

    static transformMessageEvents(message: string): string {
        return InstructionInterceptor.pipe(
            message
            , InstructionInterceptor.convertMentionsToEvent
        );
    }

    static convertMarkdownToLink(id: string): string {
        return `<a href="trigger://${id}">
                    <span class="material-symbols-outlined es-history-icon">plagiarism</span>
                </a>`;
        //return `[Trigger Action](trigger://${id})`;
        // return `<span lass="material-symbols-outlined es-history-icon">plagiarism</span>`;
    }

    static replaceSearchResultTokens(id: string, displayMessage: string): string {
        if (!id) {
            return id;
        }
        const re = /\*\|SearchResult:\s*([^|*]+?)\s*\|\*/g;
        return displayMessage.replace(re, (_m, id) => this.convertMarkdownToLink(encodeURIComponent(String(id).trim())));
    }

    static convertMentionsToEvent(message: string): string {
        return message.replace(/@(\w+)/g, '*|AddAI:$1|*');
    }

    static replaceJoinedAI(message: string): string {
        return message.replace(/\*\|JoinedAI:([^|]+)\|\*/g, (_, name) => {
            return `${name.trim()} joined the chat`;
        });
    }

    private static extractAgentName(input: string): string | null {
        const match = /\*\|JoinedAI:([^|]+)\|\*/.exec(input);
        return match ? match[1].trim() : null;
    }

    /** Simple functional pipe for strings */
    private static pipe(s: string, ...fns: Array<(x: string) => string>): string {
        return fns.reduce((acc, fn) => fn(acc), s);
    }
}
