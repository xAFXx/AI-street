import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'estypes'
})
export class EsTypesPipe implements PipeTransform {
    transform(value: string): string {
        let data = value.split('.');
        if (data.length > 1) {
            return data[data.length - 1];
        }
        return data[0];
    }
}
