import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'highlight'
})
export class HighlightTextPipe implements PipeTransform {
    transform(value: string, search: string = 'test'): string {
        if (!value || !search) {
            return value;
        }

        const regex = new RegExp(`(${search})`, 'gi'); // Case-insensitive search
        return value.replace(regex, `<mark>$1</mark>`);
    }
}
