
export declare type EntityId = number | string | undefined;
export declare type AgentId = EntityId;
export declare type UserId = EntityId;
export declare type SessionId = EntityId;
export declare type MessageId = EntityId;

export type EsPanelMode = 'one' | 'two' | 'three';
export type EsPanelId = 'search-result' | 'ai' | 'preview';
export type UrlUpdateMode = 'router' | 'location' | 'none';
