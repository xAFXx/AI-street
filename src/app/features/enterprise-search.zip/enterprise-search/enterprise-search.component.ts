import {
    Component,
    OnInit,
    Injector,
    ViewEncapsulation,
    OnDestroy,
    ViewChild,
    AfterViewInit,
    ChangeDetectorRef
} from '@angular/core';
import {AppComponentBase, appModuleAnimation, PrimengTableHelper} from '@axilla/axilla-shared';
import {AppConsts} from '@shared/AppConsts';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {distinctUntilChanged, takeUntil} from 'rxjs';
import {EnterpriseSearchDataToElasticModelDto, PreviewItemOutputDto} from '@shared/service-proxies/service-proxies';
import {filter, finalize} from 'rxjs/operators';
import {ContextMenuData, EsPanel} from '@app/enterprise-search/shared/models';
import {ContextMenu} from 'primeng/contextmenu';
import {MenuItem} from 'primeng/api';
import {AuthenticationMethod,} from '@axilla/axilla-appstore';

import {CdkDragDrop, CdkDropList, CdkDrag, moveItemInArray} from '@angular/cdk/drag-drop';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';

import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {BehaviorSubject, Subject} from 'rxjs';

import _ from 'lodash';
import {AiLayoutService} from '@app/enterprise-search/services/layout.service';
import {EsPanelId, EsPanelMode} from '@app/enterprise-search/shared/types';

type AuthKey = keyof typeof AuthenticationMethod;


@Component({
    templateUrl: './enterprise-search.component.html',
    styleUrls: ['./enterprise-search.component.less'],
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class EnterpriseSearchComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    @ViewChild('contextMenu') contextMenu!: ContextMenu; // Get reference to p-contextMenu

    defaultLogo = AppConsts.appBaseUrl + '/assets/common/images/app-logo-on-' + this.currentTheme.baseSettings.menu.asideSkin + '.svg';

    get filtersState(): boolean {
        return this.enterpriseSearchService.filterState;
    }

    isShowSearchResult = false;

    get midLayoutMode(): EsPanelMode {
        return this.aiLayoutService.panelMode;
    }
    get midColumns(): EsPanel[] {
        return this.aiLayoutService.esPanels;
    };
    get visibleMidColumns(): EsPanel[] {
        return this.aiLayoutService.visiblePanels;
    }

    isPreviewAvailable: boolean;
    timeline: boolean;
    isPreviewLoading: boolean;
    isPreviewItemLoading = false;

    contextMenuItems: MenuItem[] = [];

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this._initSubscriptions();
        this._initContextMenu();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
        //reset all search
        this.enterpriseSearchService.flush();
    }

    onColumnDrop(event: CdkDragDrop<EsPanel[]>) {
        const visible = this.visibleMidColumns;
        const fromId = visible[event.previousIndex].id;
        const toId   = visible[event.currentIndex].id;

        const fromIndex = this.midColumns.findIndex(c => c.id === fromId);
        const toIndex   = this.midColumns.findIndex(c => c.id === toId);

        moveItemInArray(this.midColumns, fromIndex, toIndex);
    }

    private _initSubscriptions() {
        this.esPreviewService.isPreviewItemLoading$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe(isPreviewItemLoading => {
                this.isPreviewItemLoading = isPreviewItemLoading;
            });

        this.enterpriseSearchService.isShowSearchResult$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((isShowSearchResult: boolean) => {
                this.isShowSearchResult = isShowSearchResult;
            });

        this.esHistoryService.historyMode$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((historyMode: 'life' | 'historySearch' | 'history') => {
                this.historyMode = historyMode;
            });

        this.esPreviewService.isShowPreviewLoader$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe(isShowPreviewLoader => {
                this.isPreviewLoading = isShowPreviewLoader;
            });

        this.enterpriseSearchService.showTimeLine$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((showTimeLine: boolean) => {
                this.timeline = showTimeLine;
            });

        //#region Preview
        this.esPreviewService.previewItem$
            .pipe(
                takeUntil(this.destroy$),
                filter((item: PreviewItemOutputDto | null) => !!item)
            )
            .subscribe((result: PreviewItemOutputDto) => {
            });

        this.esPreviewService.isShowPreviewItem$
            .pipe(
                takeUntil(this.destroy$),
                filter((item: boolean | null) => !!item)
            )
            .subscribe((result: boolean) => {
            });

        this.esPreviewService.isPreviewAvailable$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((isPreviewAvailable: boolean) => {
                this.isPreviewAvailable = isPreviewAvailable;
            });
        //#endregion Preview
    }

    private _initContextMenu() {
        this.contextMenuItems = [
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                command: () => { }
            },
            {
                label: 'View',
                icon: 'pi pi-eye',
                command: () => { }
            },
            {separator: true}, // Adds a separator line
            {
                label: 'More Actions',
                icon: 'pi pi-cog',
                items: [
                    {
                        label: 'Send to TFS',
                        icon : 'pi pi-server',
                        processor: {
                            id: 'fsdfds',
                            params: {
                                'searchId': 'sdfsdfdsfds'
                            }
                        }
                    },
                    {
                        label: 'Send as mail',
                        icon : 'pi pi-envelope',
                        extern_post_url: {
                            url: 'https://writeme.fan2customer.com',
                            params: {
                                'searchId': 'sdfsdfdsfds'
                            }
                        }
                    }
                ]
            }
        ];
    }

    onItemContextMenu(cmData: ContextMenuData) {
        cmData.event.preventDefault();

        this.contextMenu.show(cmData.event);
    }
}
