import { NgModule } from '@angular/core';
import {CommonModule, NgOptimizedImage} from '@angular/common';

import { HttpClientModule } from '@angular/common/http';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { MenuModule } from 'primeng/menu';
import { TableModule } from 'primeng/table';
import { DataViewModule } from 'primeng/dataview';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ButtonModule } from 'primeng/button';
import { PaginatorModule } from 'primeng/paginator';
import { SpinnerModule } from 'primeng/spinner';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ChartModule } from 'primeng/chart';
import { DividerModule } from 'primeng/divider';
import { ContextMenuModule } from 'primeng/contextmenu';
import { CalendarModule } from 'primeng/calendar';
import { PanelModule } from 'primeng/panel';
import { AccordionModule } from 'primeng/accordion';
import { TabViewModule } from 'primeng/tabview';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { BadgeModule } from 'primeng/badge';
import { TooltipModule } from 'primeng/tooltip';

import { UtilsModule, UblCommonModule } from '@axilla/axilla-shared';
import { AppCommonModule } from '@app/shared/common/app-common.module';

import { EnterpriseSearchService } from './services/enterprise-search.service';
import { EnterpriseSearchComponent } from './enterprise-search.component';
import { EnterpriseSearchRoutes } from './enterprise-search-routing.module';
import { EnterpriseSearchResultContainerComponent } from './components/enterprise-search-result-container/enterprise-search-result-container.component';
import { AxillaUtilsModule } from '@shared/utils/utils.module';
import {TruncateTextPipe} from '@app/enterprise-search/shared/pipes/truncate-text.pipe';
import {HighlightTextPipe} from '@app/enterprise-search/shared/pipes/highlight-text.pipe';
import {
    EnterpriseSearchTimelineChartComponent
} from '@app/enterprise-search/components/timeline-chart/es-timeline-chart.component';
import {EnterpriseSearchSearchBarComponent} from '@app/enterprise-search/components/search-bar/es-search-bar.component';
import {
    EnterpriseSearchFilterSidebarComponent
} from '@app/enterprise-search/components/filter-sidebar/es-filter-sidebar.component';
import {
    EnterpriseSearchHistorySidebarComponent
} from '@app/enterprise-search/components/history-sidebar/es-history-sidebar.component';
import {SearchInputComponent} from '@app/enterprise-search/shared/components/search-input/search-input.component';
import {EsTypesPipe} from '@app/enterprise-search/shared/pipes/es-types.pipe';
import {
    EsPreviewComponent
} from '@app/enterprise-search/components/preview/es-preview.component';
import {
    EsFilesPreviewerComponent
} from '@app/enterprise-search/components/preview/preview-types/files/es-files-previewer.component';
import {
    EsEmailPreviewComponent
} from '@app/enterprise-search/components/preview/preview-types/email/es-email-preview.component';
import {
    EsTfsPreviewComponent
} from '@app/enterprise-search/components/preview/preview-types/tfs/es-tfs-preview.component';
import {
    EsImagePreviewComponent
} from '@app/enterprise-search/components/preview/preview-types/image/es-image-preview.component';
import {
    ESPreviewHeaderComponent
} from '@app/enterprise-search/shared/components/preview-header/es-preview-header.component';
import {
    ESIconPresenterComponent
} from '@app/enterprise-search/shared/components/icons-presenter/icon-presenter.component';
import { ESMetadataComponent } from '@app/enterprise-search/shared/components/metadata/es-metadata.component';
import {ESItemHeaderComponent} from '@app/enterprise-search/shared/components/item-header/es-item-header.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import {EsAttachmentsComponent} from '@app/enterprise-search/shared/components/attachments/es-attachments.component';
import {
    EsPreviewAttachmentsComponent
} from '@app/enterprise-search/components/preview/es-preview-attachments.component';
import {
    EsDataViewComponent
} from '@app/enterprise-search/shared/components/es-data-view/es-data-view.component';
import {EsPreviewContainerComponent} from '@app/enterprise-search/components/preview/es-preview-container.component';
import {
    EsUniversalPreviewComponent
} from '@app/enterprise-search/components/preview/preview-types/universal/es-universal-preview.component';
import {ESHistorySearchComponent} from '@app/enterprise-search/components/history/es-history-search.component';
import {
    AiChatContainerComponent
} from '@app/enterprise-search/components/ai/ai-chat-container/ai-chat-container.component';
import {AiMessageComponent} from '@app/enterprise-search/components/ai/ai-message/ai-message.component';
import {MarkdownModule} from 'ngx-markdown';
import {
    TypingIndicatorContainerComponent
} from '@app/enterprise-search/shared/components/indicators/typing-indicator.component';
import {
    AiChatMetricsContainerComponent
} from '@app/enterprise-search/components/ai/ai-chat-metrics-container/ai-chat-metrics-container.component';
import {
    EsJSONPreviewComponent
} from '@app/enterprise-search/components/preview/preview-types/json/es-json-preview.component';
import { NgJsonEditorModule } from "ang-jsoneditor";
import {ChatStatusComponent} from '@app/enterprise-search/shared/components/chat-status/chat-status.component';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import {AiSessionsComponent} from '@app/enterprise-search/shared/components/ai-sessions/ai-sessions.component';
import {
    AiSessionsListComponent
} from '@app/enterprise-search/shared/components/ai-sessions-list/ai-sessions-list.component';
import {AIContainerComponent} from '@app/enterprise-search/components/ai/ai-container/ai-container.component';

@NgModule({
    declarations: [
        EnterpriseSearchComponent,
        EnterpriseSearchResultContainerComponent,
        EnterpriseSearchTimelineChartComponent,
        EnterpriseSearchSearchBarComponent,
        EnterpriseSearchFilterSidebarComponent,
        EnterpriseSearchHistorySidebarComponent,
        EsPreviewComponent,
        EsPreviewAttachmentsComponent,
        EsPreviewContainerComponent,
        ESHistorySearchComponent

        , ESPreviewHeaderComponent
        , ESMetadataComponent
        , SearchInputComponent
        , EsFilesPreviewerComponent
        , EsEmailPreviewComponent
        , EsTfsPreviewComponent
        , EsJSONPreviewComponent
        , EsImagePreviewComponent
        , EsUniversalPreviewComponent
        , ESIconPresenterComponent
        , ESItemHeaderComponent
        , EsAttachmentsComponent
        , EsDataViewComponent

        , TypingIndicatorContainerComponent
        , AiChatContainerComponent
        , AiChatMetricsContainerComponent
        , AiMessageComponent
        , AiSessionsComponent
        , AiSessionsListComponent
        , AIContainerComponent

        , ChatStatusComponent

        , TruncateTextPipe
        , HighlightTextPipe
        , EsTypesPipe
    ],
    imports: [
        RouterModule.forChild(EnterpriseSearchRoutes),

        CommonModule,
        UtilsModule,
        AxillaUtilsModule,
        UblCommonModule,
        AppCommonModule,

        MarkdownModule.forRoot(),

        ReactiveFormsModule,
        FormsModule,
        DragDropModule,

        CalendarModule,
        TableModule,
        DropdownModule,
        ButtonModule,
        PaginatorModule,
        InputSwitchModule,
        DataViewModule,
        CheckboxModule,
        DividerModule,
        AutoCompleteModule,
        SpinnerModule,
        ChartModule,
        ContextMenuModule,
        TooltipModule,
        AvatarModule,
        AvatarGroupModule,
        BadgeModule,
        OverlayPanelModule,
        MenuModule,

        ProgressSpinnerModule,
        AccordionModule,
        PanelModule,
        TabViewModule,
        InputTextModule,
        HttpClientModule,
        NgOptimizedImage,

        , NgJsonEditorModule
    ],
    exports: [
        SearchInputComponent
        , ChatStatusComponent

        , TruncateTextPipe
        , HighlightTextPipe
        , EsTypesPipe
    ],
    providers: [
        EnterpriseSearchService,
        //ReactiveAIChatService
    ],

})
export class EnterpriseSearchModule { }
