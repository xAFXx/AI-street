import { Routes } from '@angular/router';
import { EnterpriseSearchComponent } from './enterprise-search.component';
import {ESDataResolver} from '@app/enterprise-search/shared/es-data-resolver';
import {NotificationsComponent} from '@appshared/layout/notifications/notifications.component';


export const EnterpriseSearchRoutes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: EnterpriseSearchComponent,
                pathMatch: 'full',
            },
            {
                path: ':sessionId',
                component: EnterpriseSearchComponent,
                runGuardsAndResolvers: 'pathParamsChange',
            },
        ],
        resolve: { data: ESDataResolver }
    }
];
