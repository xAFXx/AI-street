import {Component, Injector, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {filter, take, takeUntil} from 'rxjs/operators';
import {FilterOptionDto, FilterOptionValueDto} from '@shared/service-proxies/service-proxies';
import {ESSorting} from '@app/enterprise-search/shared/models';


@Component({
    selector: 'app-es-filter-sidebar',
    templateUrl: './es-filter-sidebar.component.html',
    styleUrls: ['./es-filter-sidebar.component.less'],
    encapsulation: ViewEncapsulation.None
})
export class EnterpriseSearchFilterSidebarComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {
    timeline: boolean;
    aiChat: boolean;

    filters: FilterOptionDto[];
    selectedFilters: any[] = [];

    exactSearch = false;
    esDateRange: Date[]; // Array of two Dates [startDate, endDate]

    get sorting(): ESSorting[] | undefined {
        return this.enterpriseSearchService.sorting;
    }
    get selectedSorting(): ESSorting | undefined {
        return this.enterpriseSearchService.selectedSorting;
    }

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.enterpriseSearchService.showTimeLine$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((showTimeLine: boolean) => {
                this.timeline = showTimeLine;
            });

        this.enterpriseSearchService.aiChat$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((aiChat: boolean) => {
                this.aiChat = aiChat;
            });

        this.enterpriseSearchService.filters$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
                filter((filters: FilterOptionDto[] | null) => !!filters)
            ).subscribe((result: FilterOptionDto[]) => {
                this.filters = result;
            });

        this.enterpriseSearchService.selectedFilters$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
                filter((filters: FilterOptionValueDto[] | null) => !!filters)
            ).subscribe((result: FilterOptionValueDto[]) => {
                this.selectedFilters = result;
            });

        //#region Filter
        this.enterpriseSearchService.exactSearch$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((result: boolean) => {
            this.exactSearch = result;
        });

        this.enterpriseSearchService.dateRangefilter$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((result: Date[]) => {
            this.esDateRange = result;
        });
        //#endregion Filter

        this.getAvailableFilters();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    onSortingChange(event: any) {
        this.enterpriseSearchService.setSelectedSorting(event?.value);
    }

    getAvailableFilters() {
        this.enterpriseSearchService.onGetAvailableFilters$()
            .pipe(
                take(1)
            )
            .subscribe();
    }

    //#region Clear / Reset
    clearDateRange() {
        this.enterpriseSearchService.resetDateFilter();
    }

    clearFilterByType(type: string): void {
        this.enterpriseSearchService.clearFilterByType(type);
    }

    resetAllFilters(): void {
        this.enterpriseSearchService.resetAllFilters();
    }

    resetExactSearch(): void {
        this.enterpriseSearchService.resetExactSearch();
    }
    get isExactSearchEnabled(): boolean {
        return this.enterpriseSearchService.isExactSearchEnabled();
    }

    isClearDisabled(filter: string): boolean {
        return this.enterpriseSearchService.isClearDisabled(filter);
    }

    isResetFiltersDisabled(): boolean {
        return this.enterpriseSearchService.isResetDisabled();
    }

    resetSorting() {
        this.enterpriseSearchService.resetSorting();
    }
    isResetSortingDisabled(): boolean {
        return this.enterpriseSearchService.isSortingAreSet();
    }
    get isDateRangeSet(): boolean {
        return this.enterpriseSearchService.isDateFilterAreSet();
    }
    //#endregion Clear / Reset


    onTimelineChange(event: any) {
        this.enterpriseSearchService.setTimeLineVisibility(event?.checked);
    }
    onAIChatChange(event: any) {
        this.enterpriseSearchService.setAIChatVisibility(event?.checked);
    }

    onCheckboxChange(event: { checked: boolean }, option: any): void {
        this.enterpriseSearchService.setSelectedFilters(this.selectedFilters);
    }

    onDateSelect(event: any) {
        if (this.esDateRange
                && this.esDateRange.length === 2
                && this.esDateRange.every(date => date !== null)) {
            this.enterpriseSearchService.setDateRangeFilter(this.esDateRange);
        }
    }

    onExactCheckboxChange(event: any) {
        this.enterpriseSearchService.setExactSearch(event.checked);
    }
}
