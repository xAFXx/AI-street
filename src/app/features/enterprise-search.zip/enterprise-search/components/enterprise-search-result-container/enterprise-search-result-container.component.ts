import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    EventEmitter,
    Injector,
    OnDestroy,
    OnInit,
    Output,
    ViewChild,
    ViewEncapsulation
} from '@angular/core';
import { appModuleAnimation} from '@axilla/axilla-shared';

import {concatMap, debounceTime, finalize, take, tap, takeUntil, startWith, filter} from 'rxjs/operators';
import {combineLatest, Subject, withLatestFrom} from 'rxjs';
import {EnterpriseSearchService} from '../../services/enterprise-search.service';
import {LazyLoadEvent, MenuItem} from 'primeng/api';
import {
    AIChatMessageDto, AIChatMetricDto,
    EnterpriseSearchDataToElasticModelDto, EnterpriseSearchMetadataDto, FilterOptionValueDto,
    IEnterpriseSearchItemsInputDto, PreviewItemOutputDto, SearchResultDto
} from '@shared/service-proxies/service-proxies';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {DataViewLazyLoadEvent, DataViewPageEvent} from 'primeng/dataview';
import {ContextMenu} from 'primeng/contextmenu';
import {AIChatMessage, ContextMenuData, CustomHistoryItem, ESResult} from '@app/enterprise-search/shared/models';
import {PaginatorState} from 'primeng/paginator';
import dayjs from 'dayjs';
import _ from 'lodash';
import {EsPanelId} from '@app/enterprise-search/shared/types';

@Component({
    selector: 'app-enterprise-search-result-container',
    templateUrl: './enterprise-search-result-container.component.html',
    styleUrls: ['./enterprise-search-result-container.component.less'],
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class EnterpriseSearchResultContainerComponent extends EnterpriseSearchComponentBase
    implements OnInit, OnDestroy {
    activeIndex: number[] = [1];

    @Output() onOpenContextMenu: EventEmitter<ContextMenuData>
        = new EventEmitter<ContextMenuData>();

    @ViewChild('dv') dataView: DataView;

    first = 0;

    imageDescription: string | undefined;
    aiChat: boolean;

    previewMode: string | undefined;
    searchValue: string;
    isLoading = false;
    isLoadingLastData = false;
    isRequiredToCheckLastEntry = false;
    previewOrigin: EnterpriseSearchDataToElasticModelDto | undefined;

    get searchResult(): EnterpriseSearchDataToElasticModelDto[] | undefined {
        return this.enterpriseSearchService.searchData;
    }
    get totalRecordsCount(): number {
        return this.enterpriseSearchService.totalRecordsCount;
    }

    get imagePreview(): string | undefined {
        return this.enterpriseSearchService.imagePreview;
    }
    get exactSearch(): boolean {
        return this.enterpriseSearchService.exactSearch;
    }

    get layoutMode(): 'list' | 'grid' {
        return this.enterpriseSearchService.layoutMode;
    }
    get searchMode(): 'image' | 'text' | 'combined' {
        return this.enterpriseSearchService.searchMode;
    }

    get isFiltersApplyed(): boolean {
        return this.enterpriseSearchService.isResetDisabled();
    }
    get filtersState(): boolean {
        return this.enterpriseSearchService.filterState;
    }

    constructor(
        injector: Injector,
        private cdRef: ChangeDetectorRef,
    ) {
        super(injector);

    }

    ngOnInit(): void {
        this._initSubscriptions();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    toggleHistorySidebar() {
        this.enterpriseSearchService.toggleFilters();
    }

    private _initSubscriptions() {
        this.esHistoryService.searchId$
            .pipe(
                takeUntil(this.destroy$),
                filter((searchId: string) => !!searchId)
            )
            .subscribe((searchId: string) => {
                this.cdRef.detectChanges();
                //console.log(`searchId$ - ${searchId}`);
                this._loadHistoryDataById(searchId);
            });

        this.enterpriseSearchService.searchData$
            .pipe(
                takeUntil(this.destroy$),
            )
            .subscribe((result: EnterpriseSearchDataToElasticModelDto[] | undefined) => {
                this.cdRef.detectChanges();
            });

        this.enterpriseSearchService.aiChat$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((aiChat: boolean) => {
            this.aiChat = aiChat;

            if (this.aiChat) {
                this.activeIndex = [0, 1];
            } else {
                this.activeIndex = [0];
            }
        });

        this.enterpriseSearchService.basicSearchTrigger$
            .pipe(
                 withLatestFrom(
                    combineLatest([
                        this.enterpriseSearchService.search$.pipe(
                            filter((searchValue: string) => !!searchValue)
                        ),
                        this.enterpriseSearchService.selectedFilters$.pipe(
                            startWith(null), debounceTime(300)),
                        this.enterpriseSearchService.dateRangefilter$.pipe(
                            startWith(null), debounceTime(300)),
                        this.enterpriseSearchService.selectedSorting$.pipe(
                            startWith(null), debounceTime(300)),
                        this.enterpriseSearchService.exactSearch$.pipe(
                            startWith(null), debounceTime(300)),
                        this.enterpriseSearchService.base64Search$.pipe(
                            startWith(null)),
                    ])
                ),
                takeUntil(this.destroy$)
            )
            .subscribe(([_, [searchValue, selectedFilters, dateRange, sorting, exact, base64]]) => {
                const lastElement = this._getFirstNonPointerElement();

                if (lastElement !== null && lastElement.searchTerm === searchValue) {
                    if (!this.enterpriseSearchService.isFilterChanged()) {
                        return;
                    }
                }

                if (!this.isRequiredToCheckLastEntry) {
                    this.loadData();
                }
            });

        // this.enterpriseSearchService.advancedSearchTrigger$
        //     .pipe(
        //         withLatestFrom(
        //             combineLatest([
        //                 this.enterpriseSearchService.search$
        //             ])
        //         ),
        //         takeUntil(this.destroy$)
        //     )
        //     .subscribe(([_, [searchValue]]) => {
        //         // let msg = this.enterpriseSearchService.generateLoremIpsum(1);
        //         // const input = {
        //         //     content: msg,
        //         //     owner: 'ai',
        //         //     timestamp: dayjs()
        //         // } as AIChatMessage;
        //         // this.enterpriseSearchService.setMessageHistory(input);
        //     });

        this.enterpriseSearchService.isShowSearchResult$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((isShowSearchResult: boolean) => {
                this.isShowSearchResult = isShowSearchResult;
            });

        this.enterpriseSearchService.isLoading$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            )
            .subscribe((isLoading: boolean) => {
                setTimeout(() => this.isLoading = isLoading, 0);
            });

        this.esHistoryService.imageDescription$
            .pipe(
                takeUntil(this.destroy$),
                tap((description: string | undefined) => {
                    this.imageDescription = description;
                })
            )
            .subscribe();

        this.esHistoryService.historyMode$
            .pipe(
                takeUntil(this.destroy$),
                tap((historyMode) => {
                    this.historyMode = historyMode;
                })
            )
            .subscribe();

        this.esHistoryService.isRequiredToCheckLastEntry$
            .pipe(
                takeUntil(this.destroy$),
                tap((isRequiredToCheckLastEntry) => {
                    this.isRequiredToCheckLastEntry = isRequiredToCheckLastEntry;
                    if (this.isRequiredToCheckLastEntry) {
                        this._getLastEntry();
                    }
                })
            )
            .subscribe();

        this.enterpriseSearchService.searchMode$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            )
            .subscribe((mode: 'image' | 'text' | 'combined') => {
                const lastElement = this._getFirstNonPointerElement();
                if (lastElement !== null && lastElement.visualSearch === (mode === 'image')) {
                    if (!this.enterpriseSearchService.isFilterChanged()) {
                        return;
                    }
                }

                const contentBase64 = this.enterpriseSearchService.imagePreview || undefined;
                const content = this.enterpriseSearchService.search || undefined;
                if (contentBase64 || content) {
                    this.loadData();
                }
            });

        this.esHistoryService.selectedMetadata$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
                filter((searchValue: EnterpriseSearchMetadataDto | null) => !!searchValue)
            ).subscribe((searchValue: EnterpriseSearchMetadataDto) => {
                this.searchValue = searchValue.searchTerm;
                this._loadHistoryData();
            });

        this.esPreviewService.previewOrigin$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            )
            .subscribe((result: EnterpriseSearchDataToElasticModelDto | undefined) => {
                this.previewOrigin = result;
            });

        this.esPreviewService.previewMode$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            )
            .subscribe((mode: string | undefined) => {
                this.previewMode = mode;
            });
    }

    private _getFirstNonPointerElement(): CustomHistoryItem | null {
        return this.esHistoryService.metadata.find(item => item.isPointer !== true) || null;
    }

    //#region Loading Data
    loadData(event?: PaginatorState |DataViewPageEvent) {
        this._loadData(event);
    }

    lazyLoadData(event?: DataViewLazyLoadEvent) {
        if (this.isLoading || this.searchResult !== undefined) {
            return;
        }

        this._loadData(event);
    }

    private _loadData(event?: PaginatorState | DataViewPageEvent | DataViewLazyLoadEvent) {
        if (this.isLoading) {
            return;
        }

        //enable loading
        this.enterpriseSearchService.showLoadingIndicator();
        //run mode check
        this.enterpriseSearchService.runModeCheck();

        this.esPreviewService.resetPreviewItem();

        const filters = this.enterpriseSearchService.getSelectedFilters();

        this.first = event?.first || 0;

        const visualSearch = this.enterpriseSearchService.isImageSearchMode();
        const contentBase64 = this.enterpriseSearchService.imagePreview || undefined;
        let content = this.enterpriseSearchService.search || undefined;

        if (visualSearch && contentBase64 && contentBase64 === content) {
            content = undefined;
        }

        const sorting = this.enterpriseSearchService.selectedSorting;

        const dateRange = this.enterpriseSearchService.dateRangefilter;
        const [startDate, endDate] = dateRange;

        const input: IEnterpriseSearchItemsInputDto = {
            content: content,
            contentBase64: contentBase64,
            skipCount: this.first,
            maxResultCount: this.rowsAmount,
            filters: filters,
            searchInHistory: false,
            visualSearch: visualSearch,
            searchInHistoryId: undefined,
            exactSearch: this.exactSearch,
            sort: sorting?.order ?? undefined,
            sortByDate: sorting?.value,
            startDate: startDate ? dayjs(startDate) : undefined,
            endDate: endDate ? dayjs(endDate).endOf('day') : undefined
        };

        this.enterpriseSearchService.onSearchData$(input)
            .pipe(
                take(1),
            )
            .subscribe({
                next: (result) => {
                    this.cdRef.detectChanges();
                },
                error: (error) => {
                    console.error('Search failed:', error);
                }
            });
    }

    private _loadHistoryData(event?: DataViewPageEvent | DataViewLazyLoadEvent) {
        if (this.isLoading) {
            return;
        }

        //enable loading
        this.enterpriseSearchService.showLoadingIndicator();
        //run mode check
        this.enterpriseSearchService.runModeCheck();

        this.esPreviewService.resetPreviewItem();
        if (this.esHistoryService.historyMode !== 'history') {
            this.esHistoryService.enableHistoryModeSearch();
        }

        this.first = event?.first || 0;

        if (this.enterpriseSearchService.checkIfItemAvailableInStore()) {
            this.enterpriseSearchService.getFromStore$()
                .pipe(
                    take(1),
                )
                .subscribe();
        } else {
            const searchInHistoryId = this.esHistoryService.selectedMetadata.searchId;
            const content = this.searchValue || this.enterpriseSearchService.search || undefined;
            this._loadHistoryDataById(searchInHistoryId, content);
        }
    }

    private _loadHistoryDataById(
        searchInHistoryId: string,
        content?: string
    ) {
        const visualSearch = this.enterpriseSearchService.isImageSearchMode();

        const input: IEnterpriseSearchItemsInputDto = {
            content: content,
            contentBase64: undefined,
            skipCount: this.first,
            maxResultCount: this.rowsAmount,
            filters: undefined,
            searchInHistory: true,
            visualSearch: visualSearch,
            searchInHistoryId: searchInHistoryId,
            exactSearch: false,
            sort: undefined,
            sortByDate: false,
            startDate: undefined,
            endDate: undefined,
        };

        this.enterpriseSearchService.onSearchData$(input)
            .pipe(
                take(1),
                withLatestFrom(this.esHistoryService.showPreview$),
                filter(([_, showPreview]) => showPreview),
                tap(([searchResult, showPreview]) => {
                    let documentForPreview = searchResult.data[0];
                    const jsonDoc = searchResult.data?.find((item: any) => item.type === 'Document.JSON');
                    if (jsonDoc) {
                        documentForPreview = jsonDoc;
                    }
                    if (documentForPreview) {
                        this.previewSelf(documentForPreview);
                    }
                    this.esHistoryService.setShowPreview(false);
                })
            )
            .subscribe();
    }

    private _getLastEntry() {
        this.enterpriseSearchService.getLastEntry$()
            .pipe(
                take(1)
            )
            .subscribe();
    }

    //#endregion Loading Data

    onItemContextMenu(data: ContextMenuData) {
        this.onOpenContextMenu.emit(data);
    }

    //#region Preview
    //#region preview Attachments
    previewAttachments(origin: EnterpriseSearchDataToElasticModelDto) {
        this._preview(origin, 'attachment');
    }
    //#endregion preview Attachments

    //#region Preview Self
    previewSelf(origin: EnterpriseSearchDataToElasticModelDto) {
        this._preview(origin, 'self');
    }
    //#endregion Preview Self

    private _preview(origin: EnterpriseSearchDataToElasticModelDto, mode: 'attachment' | 'self') {
        this.aiLayoutService.showPanel('preview');
        this.esPreviewService.showPreview(origin, mode);
    }
    //#endregion Preview

    get searchTitle(): string {
        let text = '';

        if (this.historyMode === 'history') {
            text = `${this.translate('Axilla.App.EnterpriseSearch.SearchResultFrom', 'Axilla')} ${this.currentMetadata?.date.format('DD-MM-YYYY HH:mm')}`;
        } else {
            text = `${this.translate('Axilla.App.EnterpriseSearch.SearchResult', 'Axilla')}`;
        }
        return text;
    }

    translate(key: string, source: string) {
        let localizationSources = [];
        _.each(abp.localization.sources, (source) => {
            localizationSources.unshift(source.name);
        });

        let text = abp.localization.localize(key, source);

        for (let source of localizationSources) {
            text = abp.localization.localize(key, source);
            if (text !== key) {
                break;
            }
        }

        return text;
    }
}
