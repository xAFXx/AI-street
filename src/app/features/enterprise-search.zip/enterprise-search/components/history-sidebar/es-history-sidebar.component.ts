import {
    AfterViewInit,
    Component,
    ElementRef,
    Injector,
    NgZone,
    OnInit,
    QueryList,
    Renderer2,
    ViewChild,
    ViewChildren
} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import { CdkDragDrop, CdkDragMove, moveItemInArray } from '@angular/cdk/drag-drop';
import {CustomHistoryItem} from '@app/enterprise-search/shared/models';
import {takeUntil, filter} from 'rxjs/operators';

@Component({
    selector: 'app-es-history-sidebar',
    templateUrl: './es-history-sidebar.component.html',
    styleUrls: ['./es-history-sidebar.component.less']
})
export class EnterpriseSearchHistorySidebarComponent extends EnterpriseSearchComponentBase implements OnInit, AfterViewInit  {
    @ViewChild('historySidebarContainer') historySearchContainer!: ElementRef;
    @ViewChild('historyItemsContainer') historyItemsContainer!: ElementRef;

    @ViewChildren('historyItemRefs', { read: ElementRef }) historyItemElements: QueryList<ElementRef>;

    pointerIndex: number | null = null;
    lastHoveredIndex: number | null = null;

    get historyBarState(): boolean {
        return this.enterpriseSearchService.filterState;
    }
    get metadata(): CustomHistoryItem[] {
        return this.esHistoryService.metadata;
    }
    get currentMetadata(): CustomHistoryItem {
        return this.esHistoryService.selectedMetadata;
    }
    get isFiltersApplyed(): boolean {
        return this.enterpriseSearchService.isResetDisabled();
    }
    get ifMetadataNotEmpty(): boolean {
        return this.metadata?.length > 0;
    }

    isNavigationIconsAvailable = false;
    historyItemsHeight: string | undefined;
    firstMeasure = true;

    isDragging = false;

    canScrollUp = false;
    canScrollDown = false;

    private _historyItemHeight = 48;

    constructor(
        injector: Injector
        , private ngZone: NgZone
        , private renderer: Renderer2
    ) {
        super(injector);
    }

    ngOnInit() {
        this.esHistoryService.isHistoryModeSearch$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((isHistoryMode: boolean) => {
                this.isHistoryMode = isHistoryMode;
            });

        this.enterpriseSearchService.isShowSearchResult$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((isShowSearchResult: boolean) => {
                this.isShowSearchResult = isShowSearchResult;
            });

        this.esHistoryService.historyMode$
            .pipe(
                takeUntil(this.destroy$),
            )
            .subscribe((mode: 'life' | 'historySearch' | 'history') => {
                this.historyMode = mode;
                if ((this.historyMode === 'life' || this.historyMode === 'historySearch')
                    && this.metadata.length > 0) {
                    this.esHistoryService.resetPointerPosition();
                }
            });

        this.esHistoryService.metadata$
            .pipe(
                takeUntil(this.destroy$),
                filter((metadata: CustomHistoryItem[] | null) => !!metadata)
            )
            .subscribe((metadata: CustomHistoryItem[]) => {
                this.checkNavigationVisibility();
            });
    }

    ngAfterViewInit(): void {
        setTimeout(() => {
            this.checkNavigationVisibility();
        }, 0);

        // Optional: Recheck on window resize
        this.renderer.listen(window, 'resize', () => this.checkNavigationVisibility());
    }

    onPointerDragMoved(event: CdkDragMove) {
        this.isDragging = true;

        const pointerY = event.pointerPosition.y;

        const items = this.historyItemElements.toArray();

        const newIndex = items.findIndex((el, i) => {
            const rect = el.nativeElement.getBoundingClientRect();
            const middle = rect.top + rect.height / 2;
            return pointerY < middle;
        });

        if (newIndex !== -1 && newIndex !== this.lastHoveredIndex) {
            this.pointerIndex = newIndex;
            this.lastHoveredIndex = newIndex;

            const newMetadata = this.metadata[newIndex];
            if (newMetadata && newMetadata.searchId !== this.esHistoryService.selectedMetadata?.searchId) {
                //console.clear();
                //console.log('%cFast search to', 'color: lightgreen', newMetadata);
                this.ngZone.runOutsideAngular(() => {
                    this.showHistoryItems(newMetadata);
                });
            }
        }
    }

    onPointerDragReleased() {
        this.isDragging = false;

        this.pointerIndex = null;
        this.lastHoveredIndex = null;
    }

    resetSearch() {
        if (this.historyMode !== 'life') {
            this.esHistoryService.enableLifeMode(true);
        } else {
            abp.message.confirm(
                'All search result and history items will be permanently deleted. Pinned history will remain.'
                , 'Reset search?'
                , (result: boolean) => {
                    if (result) {
                        this.enterpriseSearchService.flush();
                    }
                }
                , {
                    showCloseButton: true,
                    customClass: {
                        container: 'modal-like'
                    }
                });
        }
    }

    checkScroll(container: HTMLElement): void {
        this.canScrollUp = container.scrollTop !== 0;
        this.canScrollDown = container.scrollTop + container.clientHeight !== container.scrollHeight;
        //console.log(`canScrollUp: ${this.canScrollUp}, canScrollDown: ${this.canScrollDown}`);
    }

    private checkNavigationVisibility(): void {
        if (this.historySearchContainer == null || this.firstMeasure) {
            this.firstMeasure = false;
            return;
        }

        this.checkScroll(this.historySearchContainer.nativeElement);

        const containerHeight = this.historySearchContainer.nativeElement.clientHeight;
        const childrenItemsHeight = this.calculateChildrenHeight();

        const historyItemsHeightWithoutNavigation = containerHeight - 96;
        this.historyItemsHeight = `${historyItemsHeightWithoutNavigation - 48}px`;

        this.isNavigationIconsAvailable = childrenItemsHeight > historyItemsHeightWithoutNavigation;
    }

    private calculateChildrenHeight() {
        let height = 0;
        for (let i = 0; i < this.metadata.length; i++) {
            height += this._historyItemHeight;
        }
        return height;
    }

    scrollUp() {
        if (!this.canScrollUp) {
            return;
        }
        const container = this.historyItemsContainer.nativeElement;
        const scrollAmount = 48 * 3; // Minimum scroll of 48px * 3 = 144px
        container.scrollTop = Math.max(container.scrollTop - scrollAmount, 0); // Prevent scroll from going below 0
    }

    scrollDown() {
        if (!this.canScrollDown) {
            return;
        }
        const container = this.historyItemsContainer.nativeElement;
        const scrollAmount = 48 * 3; // Minimum scroll of 48px * 3 = 144px
        container.scrollTop = Math.min(container.scrollTop + scrollAmount, container.scrollHeight - container.clientHeight); // Prevent scrolling beyond content
    }

    drop(event: CdkDragDrop<CustomHistoryItem[]>) {
        this.esHistoryService.drop(event);
    }

    showHistoryItems(metadata: CustomHistoryItem) {
        this.esHistoryService.setCurrentMetadata(metadata);
    }

    // Move the pointer to the next position
    movePointerNext() {
        this.esHistoryService.movePointerNext();
    }

    // Move the pointer to the previous position
    movePointerPrevious() {
        this.esHistoryService.movePointerPrevious();
    }

    toggleHistorySidebar() {
        this.enterpriseSearchService.toggleFilters();
    }

    openHistorySearchResult(item: CustomHistoryItem) {
       this.esHistoryService.setCurrentMetadata(item, true);
    }

    showHistorySearch() {
        this.enterpriseSearchService.enableHistorySearchMode();
    }

    resetHistory() {
        abp.message.confirm(
            'Unpinned items will be permanently deleted. Pinned history will remain.'
            , 'Clear search history?'
            , (result: boolean) => {
                if (result) {
                    this.enterpriseSearchService.resetStore();
                    this.esHistoryService.resetMetadata();
                }
            }
            , {
                showCloseButton: true,
                customClass: {
                    container: 'modal-like'
                }
            });
    }

    get isDragIndicatorAvailable(): boolean {
        return this.isHistoryMode;
    }
}
