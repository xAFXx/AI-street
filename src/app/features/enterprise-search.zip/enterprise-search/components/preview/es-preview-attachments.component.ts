import {Component, EventEmitter, Injector, Input, OnInit, Output} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {filter, takeUntil, finalize, take} from 'rxjs/operators';
import {
    EnterpriseSearchDataToElasticModelDto
} from '@shared/service-proxies/service-proxies';
import {DataViewLazyLoadEvent, DataViewPageEvent} from 'primeng/dataview';

export type PreviewType = 'Mail' | 'WorkItem' | 'Image' | 'Files';

@Component({
    selector: 'app-es-preview-attachments',
    templateUrl: './es-preview-attachments.component.html',
    styleUrls: ['./es-preview-attachments.component.less']
})
export class EsPreviewAttachmentsComponent extends EnterpriseSearchComponentBase implements OnInit  {

    @Input() layoutMode: 'list' | 'grid';

    isLoading = false;
    get data(): EnterpriseSearchDataToElasticModelDto[] | undefined {
        return this.esPreviewService.attachments;
    }

    totalAttachmentsCount = 0;

    constructor(
        injector: Injector
    ) {
        super(injector);
    }

    ngOnInit() {
        this.loadData();

        this.esPreviewService.isPreviewAttachmentsLoading$
            .pipe(
                takeUntil(this.destroy$),
            )
            .subscribe(isLoading => {
                this.isLoading = isLoading;
            });

        this.esPreviewService.totalAttachmentsCount$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe(totalAttachmentsCount => {
                this.totalAttachmentsCount = totalAttachmentsCount;
            });
    }

    loadData(event?: DataViewPageEvent) {
        this._loadData(event);
    }

    private _loadData(event?: DataViewPageEvent | DataViewLazyLoadEvent) {
        if (this.isLoading) {
            return;
        }
        this.esPreviewService.showPreviewAttachmentsLoader();

        const skipCount = event?.first || 0;
        const maxResultCount = this.rowsAmount;

        this.esPreviewService.getAttachmentsData$(
            skipCount
            , maxResultCount
            )
            .pipe(
                take(1),
                finalize(() => this.isLoading = false)
            )
            .subscribe(result => {
                this.esPreviewService.hidePreviewAttachmentsLoader();
            });
    }

    closeAttachments(): void {
        this.closePanel('preview');
        this.esPreviewService.closeAndReset();
    }

    onSelectItem(item: EnterpriseSearchDataToElasticModelDto) {
        console.log('EnterpriseSearchDataToElasticModelDto', item);
        this.enterpriseSearchService.setSearch(item.title);
        if (item.type.includes('JSON')) {
            this.esPreviewService.resetPreviewItem();
            this.esPreviewService.showPreview(item, 'self');
        } else {
            this.closeAttachments();
        }

    }

    showAttachmentsPreview(item: any) {
        console.log(`showAttachmentsPreview: ${item}`);
    }
}
