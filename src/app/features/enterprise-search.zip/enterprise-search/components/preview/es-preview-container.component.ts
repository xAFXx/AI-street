import {Component, EventEmitter, Injector, Input, OnInit, Output} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {filter, takeUntil, finalize, take} from 'rxjs/operators';
import {
    DocumentCountDto,
    EnterpriseSearchDataToElasticModelDto, RelatedDocumentTypes,
} from '@shared/service-proxies/service-proxies';
import {ContextMenuData} from '@app/enterprise-search/shared/models';

@Component({
    selector: 'app-es-preview-container',
    templateUrl: './es-preview-container.component.html',
    styleUrls: ['./es-preview-container.component.less']
})
export class EsPreviewContainerComponent extends EnterpriseSearchComponentBase implements OnInit  {
    @Output() openContextMenu: EventEmitter<ContextMenuData>
        = new EventEmitter<ContextMenuData>();

    isPreviewLoading = false;
    isPreviewItemLoading = false;

    previewMode: 'attachment' | 'self' | undefined;

    layoutMode: 'list' | 'grid' = 'list';

    get data(): EnterpriseSearchDataToElasticModelDto[] | undefined {
        return this.esPreviewService.attachments;
    }

    constructor(
        injector: Injector
    ) {
        super(injector);
    }

    ngOnInit() {
        this.esPreviewService.isShowPreviewLoader$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe(isShowPreviewLoader => {
                this.isPreviewLoading = isShowPreviewLoader;
            });

        this.esPreviewService.isPreviewItemLoading$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe(isPreviewItemLoading => {
                this.isPreviewItemLoading = isPreviewItemLoading;
            });

        this.esPreviewService.previewMode$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((mode: 'attachment' | 'self' | undefined) => {
                this.previewMode = mode;
            });

        this.esPreviewService.selectedAttachmentType$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((attachmentType: DocumentCountDto) => {
                if (attachmentType?.type === RelatedDocumentTypes.TextDocument) {
                    this.layoutMode = 'list';
                } else if (attachmentType?.type === RelatedDocumentTypes.Media) {
                    this.layoutMode = 'grid';
                } else {
                    this.layoutMode = 'list';
                }
            });
    }

    protected onItemContextMenu(data: ContextMenuData) {
        this.openContextMenu.emit(data);
    }

    protected closePreview() {
        this.closePanel('preview');
        this.esPreviewService.closeAndReset();
    }

}
