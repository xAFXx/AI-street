import {Component, EventEmitter, Injector, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import DOMPurify from 'dompurify';
import {EnterpriseSearchDataToElasticModelDto} from '@shared/service-proxies/service-proxies';
import {ContextMenuData} from '@app/enterprise-search/shared/models';
import {
    EsPreviewBaseComponent
} from '@app/enterprise-search/components/preview/preview-types/es-preview-base.component';

@Component({
    selector: 'app-es-universal-preview',
    templateUrl: './es-universal-preview.component.html',
    styleUrls: ['./es-universal-preview.component.less']
})
export class EsUniversalPreviewComponent extends EsPreviewBaseComponent {

    // Email properties
    // The content may contain HTML tags.
    @Input() data = '';

    constructor(
        injector: Injector,

    ) {
        super(injector);
    }
}
