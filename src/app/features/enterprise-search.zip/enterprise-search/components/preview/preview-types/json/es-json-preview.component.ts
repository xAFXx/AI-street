import {Component, EventEmitter, Injector, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {PreviewDocumentOutputDto} from '@shared/service-proxies/service-proxies';
import {
    EsPreviewBaseComponent
} from '@app/enterprise-search/components/preview/preview-types/es-preview-base.component';
import {JsonEditorService} from '@axilla/axilla-appstore';
import {JsonEditorOptions} from 'ang-jsoneditor';
import {filter, takeUntil} from 'rxjs/operators';
import {distinctUntilChanged} from 'rxjs';

@Component({
    selector: 'app-es-json-preview',
    templateUrl: './es-json-preview.component.html',
    styleUrls: ['./es-json-preview.component.less']
})
export class EsJSONPreviewComponent extends EsPreviewBaseComponent  {

    readonly editorOptions: JsonEditorOptions;

    openedValue: any;

    constructor(
        injector: Injector,
        public _jsonEditorService: JsonEditorService
    ) {
        super(injector);

        this.editorOptions = this._jsonEditorService.initEditor();

        this.esPreviewService.previewDocuments$
            .pipe(
                distinctUntilChanged()
                , takeUntil(this.destroy$)
                , filter(documents => !!documents || documents?.length !== 0)
            )
            .subscribe((documents: PreviewDocumentOutputDto[]) => {
                if (documents.length > 0) {
                    this.loadBase64Json(documents[0]);
                }
            });
    }

    private loadBase64Json(document: PreviewDocumentOutputDto): void {
        try {
            const decoded = atob(document.content);
            const parsed = JSON.parse(decoded);
            this.openedValue = parsed; //JSON.stringify(parsed, null, 2); // Pretty print
        } catch (error) {
            console.error('Error decoding base64 JSON:', error);
            this.openedValue = '// Invalid base64 or JSON';
        }
    }
}
