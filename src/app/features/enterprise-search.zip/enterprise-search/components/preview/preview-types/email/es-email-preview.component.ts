import {Component, EventEmitter, Injector, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import DOMPurify from 'dompurify';
import {EnterpriseSearchDataToElasticModelDto} from '@shared/service-proxies/service-proxies';
import {ContextMenuData} from '@app/enterprise-search/shared/models';
import {
    EsPreviewBaseComponent
} from '@app/enterprise-search/components/preview/preview-types/es-preview-base.component';

@Component({
    selector: 'app-es-email-preview',
    templateUrl: './es-email-preview.component.html',
    styleUrls: ['./es-email-preview.component.less']
})
export class EsEmailPreviewComponent extends EsPreviewBaseComponent {

    // Email properties
    @Input() title = '';
    @Input() subject = '';
    @Input() from = '';
    @Input() to = '';
    // The content may contain HTML tags.
    @Input() content = '';

    constructor(
        injector: Injector,

    ) {
        super(injector);
    }
}
