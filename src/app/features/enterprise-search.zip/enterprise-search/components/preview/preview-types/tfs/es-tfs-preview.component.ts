import {Component, Injector, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {
    EsPreviewBaseComponent
} from '@app/enterprise-search/components/preview/preview-types/es-preview-base.component';

@Component({
    selector: 'app-es-tfs-preview',
    templateUrl: './es-tfs-preview.component.html',
    styleUrls: ['./es-tfs-preview.component.less']
})
export class EsTfsPreviewComponent extends EsPreviewBaseComponent {
    @Input() id: number | null = null;
    @Input() title = '';
    @Input() type = ''; // e.g., Bug, Task, User Story
    @Input() state = ''; // e.g., Active, Resolved, Closed
    @Input() assignedTo = ''; // User assigned to the work item
    @Input() description = ''; // May contain HTML content
    @Input() workItemType = ''; // workItemType

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

}
