import {Component, Injector, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {
    EsPreviewBaseComponent
} from '@app/enterprise-search/components/preview/preview-types/es-preview-base.component';

@Component({
    selector: 'app-es-image-preview',
    templateUrl: './es-image-preview.component.html',
    styleUrls: ['./es-image-preview.component.less']
})
export class EsImagePreviewComponent extends EsPreviewBaseComponent implements OnInit, OnChanges {
    // Accept an image as a Base64 string or URL.
    @Input() imageSrc = '';
    // Optional: provide an alt text.
    @Input() altText = 'Image Preview';

    // A flag to check if the image is valid.
    isValidImage = true;

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {

    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.imageSrc) {
            this.validateImage();
        }
    }

    /**
     * Validate the image source.
     * You might extend this method to perform more complex checks,
     * but for this example we simply mark empty sources as invalid.
     */
    validateImage(): void {
        this.isValidImage = this.imageSrc && this.imageSrc.trim().length > 0;
    }
}
