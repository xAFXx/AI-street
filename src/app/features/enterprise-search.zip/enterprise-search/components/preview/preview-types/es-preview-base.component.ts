import {EventEmitter, Injector, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';

import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {ContextMenuData} from '@app/enterprise-search/shared/models';
import {EnterpriseSearchDataToElasticModelDto, PreviewItemOutputDto} from '@shared/service-proxies/service-proxies';
import DOMPurify from '@node_modules/dompurify';

import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

export abstract class EsPreviewBaseComponent extends EnterpriseSearchComponentBase implements  OnInit, OnChanges  {
    @Output() onOpenContextMenu: EventEmitter<ContextMenuData>
        = new EventEmitter<ContextMenuData>();

    sanitizedContent: SafeHtml;

    get item(): EnterpriseSearchDataToElasticModelDto {
        return this.esPreviewService.previewOrigin;
    }

    get previewItem(): PreviewItemOutputDto {
        return this.esPreviewService.previewItem;
    }

    protected sanitizer: DomSanitizer;

    protected constructor(injector: Injector) {
        super(injector);

        this.sanitizer = injector.get(DomSanitizer);
    }

    onItemContextMenu(data: ContextMenuData) {
        this.onOpenContextMenu.emit(data);
    }

    ngOnInit(): void {
        if (this.previewItem?.contentRaw || this.previewItem?.content) {
            this.sanitizeContentWithDOMPurify();
        }
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.description) {
            this.sanitizeContentWithDOMPurify();
        }
    }

    /**
     * Sanitize description by stripping any HTML tags.
     */
    sanitize(): void {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = this.previewItem?.contentRaw || this.previewItem?.content || '';
        this.sanitizedContent = tempElement.textContent || tempElement.innerText || '';
    }

    sanitizeContentWithDOMPurify(): void {
        const rawHtml = this.previewItem?.contentRaw || this.previewItem?.content || '';

        // Convert plain URLs into <a> tags
        const linkifiedHtml = rawHtml.replace(/(\bhttps?:\/\/[^\s<]+)/gi, (url) => {
            const safeUrl = url.replace(/"/g, '&quot;');
            return `<a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${url}</a>`;
        });

        // Sanitize with DOMPurify
        const cleanHtml = DOMPurify.sanitize(linkifiedHtml, {
            ALLOWED_TAGS: ['strong', 'em', 'b', 'i', 'a', 'p', 'br', 'ul', 'ol', 'li', 'span'],
            ALLOWED_ATTR: ['href', 'target', 'rel'],
        });

        this.sanitizedContent =  this.sanitizer.bypassSecurityTrustHtml(cleanHtml);
    }
}

