import {Component, Injector, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {
    EsPreviewBaseComponent
} from '@app/enterprise-search/components/preview/preview-types/es-preview-base.component';

@Component({
    selector: 'app-es-files-previewer',
    templateUrl: './es-files-previewer.component.html',
    styleUrls: ['./es-files-previewer.component.less']
})
export class EsFilesPreviewerComponent extends EsPreviewBaseComponent implements OnInit, OnChanges {
    // The raw content that may contain HTML tags.
    @Input() content = '';

    // The sanitized plain text version of the content.
    sanitizedContent = '';

    // Dummy file content containing HTML tags.
    dummyFileContent = '';

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.dummyFileContent = `
      <h1>Dummy Document Title</h1>
      <p>This is a <strong>dummy document</strong> intended for preview. It includes several HTML tags such as:</p>
      <ul>
        <li><em>Emphasized text</em></li>
        <li><u>Underlined text</u></li>
        <li><a href="https://example.com" target="_blank">A sample link</a></li>
      </ul>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel magna ac felis interdum tristique.</p>
    `;
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.content) {
            this.sanitizeContent();
        }
    }

    /**
     * Sanitize the content by stripping any HTML tags.
     * We create a temporary DOM element, set its innerHTML,
     * and then retrieve the plain text.
     */
    sanitizeContent(): void {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = this.content || '';
        this.sanitizedContent = tempElement.textContent || tempElement.innerText || '';
    }
}
