import {Component, Injector} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';

@Component({
    selector: 'app-es-search-bar',
    templateUrl: './es-search-bar.component.html',
    styleUrls: ['./es-search-bar.component.less']
})
export class EnterpriseSearchSearchBarComponent extends EnterpriseSearchComponentBase {
    query = '';

    activeTab: 'all' | 'image' = 'all';

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    onTabChange(tab: 'all' | 'image') {
        if (this.activeTab !== tab) {
            this.activeTab = tab;
            //this.loadTabData(tab);
        }

        if (this.activeTab === 'image') {
            this.enterpriseSearchService.setImageSearchMode();
        } else {
            this.enterpriseSearchService.setTextMode();
        }
    }
}
