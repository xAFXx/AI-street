import {
    AfterViewInit,
    Component,
    ElementRef,
    Injector,
    NgZone,
    HostListener,
    OnDestroy,
    OnInit,
    ViewChild,
    ViewEncapsulation, Renderer2, ViewChildren, QueryList
} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {
    auditTime, catchError,
    concatMap,
    delay,
    filter,
    map,
    observeOn,
    shareReplay, skipUntil,
    startWith, switchMap, take,
    takeUntil,
    tap
} from 'rxjs/operators';
import {
    AIChatMessageDto, AIChatMessageReadyDto,
    AIChatMetricDto, AIPersonDescriptionDto
} from '@shared/service-proxies/service-proxies';
import {AIChatMessage} from '@app/enterprise-search/shared/models';
import {
    distinctUntilChanged,
    fromEvent,
    Observable,
    merge,
    from,
    of,
    Subject,
    animationFrameScheduler,
    combineLatest
} from 'rxjs';
import {AIChatMetricsService} from '@app/enterprise-search/services/ai-chat-metrics.service';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';
import {Router} from '@angular/router';
import {AiSessionsService} from '@app/enterprise-search/services/ai-sessions.service';
import {ChatMessagesStore} from '@app/enterprise-search/shared/store/ai-message.store';

@Component({
    selector: 'app-ai-chat-container',
    templateUrl: './ai-chat-container.component.html',
    styleUrls: ['./ai-chat-container.component.less'],
    encapsulation: ViewEncapsulation.None
})
export class AiChatContainerComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild('scrollContainer') private scrollContainer!: ElementRef<HTMLElement>;

    /** how close to bottom we consider “at bottom” */
    private readonly bottomThreshold = 56; // px

    // Bind directly to service's messages$ stream
    messages$: Observable<AIChatMessage[]>;
    currentAIAssistant$!: Observable<AIPersonDescriptionDto | undefined>;
    currentAgentId$: Observable<string>;
    lastAgentId$: Observable<string>;

    loading = false;
    aiIsTyping = false;
    connectedAIName: string | undefined;
    protected aiChatMetricsService: AIChatMetricsService;
    protected reactiveAIChatService: ReactiveAIChatService;

    private autoScrollEnabled = true;

    vm$: any;

    constructor(
        injector: Injector,
        private router: Router,
        private _zone: NgZone,
        private messageStore: ChatMessagesStore
    ) {
        super(injector);

        this.aiChatMetricsService = injector.get(AIChatMetricsService);
        this.reactiveAIChatService = injector.get(ReactiveAIChatService);

        this.currentAIAssistant$ = this.reactiveAIChatService.currentAIAssistant$;
        this.currentAgentId$ = this.reactiveAIChatService._currentAgentId$;
        this.lastAgentId$ = this.reactiveAIChatService._lastAgentId$;

        const messagesForCurrent$ = this.messages$ = this.messageStore.messagesForCurrent$;
        const loading$ = this.messageStore.loading$;
        const error$ = this.messageStore.error$;

        this.vm$ = combineLatest([messagesForCurrent$, loading$, error$])
            .pipe(
                map(([messages, loading, error]) => ({ messages, loading, error })),
                tap(({ messages, loading, error }) => console.log({ messages, loading, error }))
            );
    }

    ngOnInit(): void {
        this.init();
    }

    ngAfterViewInit() {
        const el = this.scrollContainer.nativeElement as HTMLElement;

        // Detect user position relative to bottom and lock/unlock autoscroll
        fromEvent(el, 'scroll')
            .pipe(
                // sample ~60fps into ~12fps to stay snappy without spamming change detection
                auditTime(80),
                map(() => this.isNearBottom()),
                distinctUntilChanged(),
                tap((nearBottom) => {
                    this.autoScrollEnabled = nearBottom;
                }),
                takeUntil(this.destroy$)
            )
            .subscribe();

        const scrollUser$ = this.messages$
            .pipe(
                filter(m => m[m.length - 1]?.owner === 'user'),
                tap(m => {
                    if (m) {
                        //const lastMessage = m[m.length - 1];
                        setTimeout(() => {
                            const el = document.querySelector('app-ai-message:last-of-type') as HTMLElement | null;
                            this.scrollChildToTop(el);
                        }, 150);
                    }
                })
            )
        ;
        const scrollAi$ = this.messages$
            .pipe(
                auditTime(80),
                filter(m => m[m.length - 1]?.owner === 'ai'),
                filter(_ => this.autoScrollEnabled),
                tap(m => {
                    if (m) {
                        //const lastMessage = m[m.length - 1];
                        const parent = document.querySelector('app-ai-message:last-of-type') as HTMLElement | null;
                        if (parent) {
                            const child = parent.firstElementChild as HTMLElement | null; // first direct element child
                            if (child) {
                                // console.log('Parent info:', {
                                //     clientHeight: parent.clientHeight,   // visible height
                                //     offsetHeight: parent.offsetHeight,   // includes borders
                                //     scrollHeight: parent.scrollHeight    // full content height
                                // });
                                // console.log('Child info:', {
                                //     clientHeight: child.clientHeight,
                                //     offsetHeight: child.offsetHeight,
                                //     scrollHeight: child.scrollHeight
                                // });

                                if (child.offsetHeight > parent.clientHeight) {
                                    //console.log('✅ Child is taller than parent');
                                    this.scrollToBottom(true);
                                }
                                // else {
                                //     console.log('❌ Child fits within parent');
                                // }
                                return;
                            }
                            //console.log('Parent has no element children');
                            return;
                        }
                        console.warn('Parent not found');
                    }
                })
            )
        ;

        merge(
            scrollUser$
            , scrollAi$
        )
        .pipe(
            takeUntil(this.destroy$)
        )
        .subscribe();

        this.enterpriseSearchService.showTimeLine$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            )
            .subscribe((showTimeLine: boolean) => {
                //this.timeline = showTimeLine;
            });
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    @HostListener('window:keydown', ['$event'])
    handleKeyDown(event: KeyboardEvent) {
        if (event.key === 'F4') {
            event.preventDefault();
            const agentId = this.reactiveAIChatService.currentAgentId ?? this.reactiveAIChatService.lastAgentId;
            this.router.navigate(agentId ? ['/app/ai', encodeURIComponent(agentId)] : ['/app/ai']);
        }
    }

    private init(): void {
        this.registerEvents();
    }

    registerEvents(): void {
        const self = this;

        function onMessageReceived(message: AIChatMessageDto) {
            //self.aiChatService.setMessage(message);
            self.reactiveAIChatService.setReactiveMessages(message);
        }

        function onChatMetricUpdate(metrics: AIChatMetricDto[]) {
            self.aiChatMetricsService.updateMetrics(metrics);
        }

        function onHideIndicator(input: AIChatMessageReadyDto) {
            self.reactiveAIChatService.hideIndicatorByDto(input);
        }

        abp.event.on('app.aichat.messageReceived', (message: AIChatMessageDto) => {
            self._zone.run(() => {
                onMessageReceived(message);
            });
        });

        abp.event.on('app.aichat.chatMetricUpdate', (metrics: AIChatMetricDto[]) => {
            self._zone.run(() => {
                onChatMetricUpdate(metrics);
            });
        });

        abp.event.on('app.aichat.hideIndicator', (input: AIChatMessageReadyDto) => {
            self._zone.run(() => {
                onHideIndicator(input);
            });
        });

        abp.event.on('app.aichat.chatMetricUpdate', (metrics: AIChatMetricDto[]) => {
            self._zone.run(() => {
                onChatMetricUpdate(metrics);
            });
        });
    }

    /** optional: explicit handler if you add (scroll)="onUserScroll()" */
    onUserScroll() {
        // lock when user scrolls up; unlock when they return near bottom
        this.autoScrollEnabled = this.isNearBottom();
    }

    //#region Helpers
    protected scrollToBottom(force = false, minLastMsgHeightPx = 440): void {
        try {
            setTimeout(() => {
                const container = this.scrollContainer.nativeElement;
                if (this.autoScrollEnabled || force) {
                    container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
                }
            }, 0);
        } catch (err) {
            console.warn('Scroll failed:', err);
        }
    }

    // keep your existing helpers
    trackByMessage = (_: number, m: AIChatMessage) => m.id;

    protected getTextAlign(owner: 'user' | 'ai' | 'system'): 'left' | 'center' | 'right' {
        switch (owner) {
            case 'user':
                return 'right';
            case 'ai':
                return 'left';
            case 'system':
                return 'center';
            default:
                return 'left';
        }
    }

    private isNearBottom(): boolean {
        const el = this.scrollContainer.nativeElement as HTMLElement;
        const dist = el.scrollHeight - (el.scrollTop + el.clientHeight);
        return dist <= this.bottomThreshold;
    }

    // Helper: scroll only the given container so that `child` is aligned to its top
    private scrollChildToTop(child: HTMLElement) {
        const scroller = this.getScrollableParent(child);
        scroller.scrollTo({top: child.offsetTop, behavior: 'smooth' });
    }

    private getScrollableParent(el) {
        while (el && el !== document.body) {
            const s = getComputedStyle(el);
            if (/(auto|scroll)/.test(s.overflow + s.overflowY + s.overflowX)) {
                return el;
            }
            el = el.parentElement;
        }
        return document.scrollingElement || document.documentElement;
    }
    //#endregion Helpers
}
