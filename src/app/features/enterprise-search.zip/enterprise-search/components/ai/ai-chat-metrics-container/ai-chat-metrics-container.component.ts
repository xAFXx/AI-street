import {
    AfterViewInit,
    Component, computed, effect,
    ElementRef,
    Injector,
    NgZone,
    OnDestroy,
    OnInit, Signal, signal,
    ViewChild,
    ViewEncapsulation
} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {debounceTime, takeUntil, tap} from 'rxjs/operators';
import {
    ChatSide,
    AIChatMessageDto,
    AIChatMetricDto,
    AIPersonDescriptionDto
} from '@shared/service-proxies/service-proxies';
import {AIChatMessage, AIAgentMetricSummary, AIAgentMetric} from '@app/enterprise-search/shared/models';
import {fromEvent, Observable, timer} from 'rxjs';
import {AIChatMetricsService} from '@app/enterprise-search/services/ai-chat-metrics.service';
import {AiAgentsService} from '@app/enterprise-search/services/ai-agents.service';
import {ReactiveAIChatService} from '@app/enterprise-search/services/reactive-ai-chat.service';

@Component({
    selector: 'app-ai-chat-metrics-container',
    templateUrl: './ai-chat-metrics-container.component.html',
    styleUrls: ['./ai-chat-metrics-container.component.less'],
    encapsulation: ViewEncapsulation.None
})
export class AiChatMetricsContainerComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {

    protected aiChatMetricsService: AIChatMetricsService;
    protected aiChatService: ReactiveAIChatService;

    get metricSummary$(): Observable<AIAgentMetricSummary> {
        return this.aiChatMetricsService.metricSummary$;
    }

    get agents$(): Observable<AIPersonDescriptionDto[]> {
        return this.aiAgentsService.aiAgents$;
    }

    constructor(
        injector: Injector,
        public _zone: NgZone
    ) {
        super(injector);

        this.aiChatMetricsService = injector.get(AIChatMetricsService);
        this.aiChatService = injector.get(ReactiveAIChatService);
    }

    ngOnInit(): void {
        this.init();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    private init(): void {

    }

    loadMessages(agentMetrics: AIAgentMetric) {
        if (!agentMetrics.metric || +agentMetrics.metric.unreadMessages === 0) {
            return;
        }

        this.aiChatService.loadMessages(agentMetrics.metric);
    }

    getAgentAvatar(agent: { name?: string, initials?: string } | undefined): string {
        // Prefer initials if you have them, fallback to first letter of name
        return (agent?.initials || agent?.name?.[0] || '?').toUpperCase();
    }

    trackMetricsByFn = (index: number, metric: AIChatMetricDto): any => metric?.sessionId;
    trackAgentsByFn = (_: number, p: { agent: { id: string } }) => p?.agent?.id ?? _;
}
