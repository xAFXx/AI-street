import {
    ChangeDetectorRef,
    Component,
    Injector,
    OnDestroy,
    OnInit,
    ViewEncapsulation
} from '@angular/core';
import { appModuleAnimation} from '@axilla/axilla-shared';

import {concatMap, debounceTime, finalize, take, tap, takeUntil, filter} from 'rxjs/operators';

import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';

@Component({
    selector: 'app-ai-container',
    templateUrl: './ai-container.component.html',
    styleUrls: ['./ai-container.component.less'],
    encapsulation: ViewEncapsulation.None,
    animations: [appModuleAnimation()]
})
export class AIContainerComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {

    constructor(
        injector: Injector,
        private cdRef: ChangeDetectorRef,
    ) {
        super(injector);

    }

    ngOnInit(): void {
        this._initSubscriptions();
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    private _initSubscriptions() {

    }

}
