import {
    Component,
    EventEmitter,
    Injector,
    Input,
    NgZone,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges
} from '@angular/core';
import {AIChatMessage} from '@app/enterprise-search/shared/models';
import {EsHistoryService} from '@app/enterprise-search/services/es-history.service';
import {AIChatMessageDto, AIChatServiceProxy, AIPersonDescriptionDto} from '@shared/service-proxies/service-proxies';
import {BehaviorSubject} from '@node_modules/rxjs';
import dayjs from '@node_modules/dayjs';

@Component({
    selector: 'app-ai-message',
    templateUrl: './ai-message.component.html',
    styleUrls: ['./ai-message.component.less']
})
export class AiMessageComponent implements OnChanges {
    @Input() message!: AIChatMessage;

    @Output() onScrollToBottom: EventEmitter<any> = new EventEmitter<any>();

    displayedContent = '';
    typingInterval: any;

    private esHistoryService: EsHistoryService;

    constructor(injector: Injector) {
        this.esHistoryService = injector.get(EsHistoryService);
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['message']) {
            if (this.message.owner === 'ai') {
                this.simulateTyping(this.message.content);
            } else {
                this.displayedContent = this.message.content;
            }
        }
    }

    simulateTyping(text: string): void {
        clearInterval(this.typingInterval);
        let index = 0;
        this.displayedContent = '';

        this.typingInterval = setInterval(() => {
            if (index < text.length) {
                this.displayedContent += text[index];
                index++;
                //this.onScrollToBottom.emit();
            } else {
                clearInterval(this.typingInterval);
            }
        }, 20); // Typing speed
    }

    onMarkdownClick(event: MouseEvent): void {
        const target = event.target as HTMLElement;

        if (target.tagName.toLowerCase() === 'span') {
            const anchor = target.closest('a');
            const href = anchor?.getAttribute('href');

            if (href && href.startsWith('trigger://')) {
                event.preventDefault();
                const triggerId = href.replace('trigger://', '');
                this.showResult(triggerId);
            }
        }
    }

    showResult(id: string): void {
        this.esHistoryService.setSearchId(id);
    }
}
