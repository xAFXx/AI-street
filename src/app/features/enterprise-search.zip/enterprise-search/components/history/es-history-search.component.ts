import {Component, Injector, OnDestroy, OnInit} from '@angular/core';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import {filter, takeUntil, take, tap} from 'rxjs/operators';
import {CustomHistoryItem, ESResult} from '@app/enterprise-search/shared/models';
import {Observable} from 'rxjs';

@Component({
    selector: 'app-es-history-search',
    templateUrl: './es-history-search.component.html',
    styleUrls: ['./es-history-search.component.less']
})
export class ESHistorySearchComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy {

    isLoading: boolean;
    searchValue: string;

    results$: Observable<{ items: ESResult[], total: number }>;
    totalRecords = 0;
    currentPage = 0;

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.esHistoryService.historyMode$
            .pipe(
                takeUntil(this.destroy$)
            )
            .subscribe((historyMode: 'life' | 'historySearch' | 'history') => {
                this.historyMode = historyMode;
            });

        this.enterpriseSearchService.search$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
            ).subscribe((searchValue: string) => {
            if (this.historyMode === 'historySearch') {
                this.searchValue = searchValue;

                this.loadData();
            }
        });
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    loadData() {
        this.results$ = this.enterpriseSearchService.getPaginatedResults$(
                this.searchValue,
                this.currentPage * this.rowsAmount,
                this.rowsAmount,
            )
            .pipe(
                tap((response) => {
                    this.totalRecords = response.total;
                }) // Update total records
            );
    }

    onPageChange(event: any) {
        this.currentPage = event.first / event.rows;
        this.loadData();
    }

    onFilterChange() {
        this.currentPage = 0; // Reset to first page when filter changes
        this.loadData();
    }

    openHistorySearchResult(item: CustomHistoryItem) {
        this.esHistoryService.setCurrentMetadata(item);
    }
}
