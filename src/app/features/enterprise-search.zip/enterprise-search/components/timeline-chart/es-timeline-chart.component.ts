import {
    Component,
    OnInit,
    ElementRef,
    ViewChild,
    Injector,
    OnDestroy,
    AfterViewInit,
    HostListener
} from '@angular/core';
import { Chart } from 'chart.js/auto';
import {EnterpriseSearchComponentBase} from '@app/enterprise-search/shared/enterprise-search-base.component';
import { ChartOptions, ChartData } from 'chart.js';
import {filter, takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {PreviewItemOutputDto, TimelineDto} from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'app-es-timeline-chart',
    templateUrl: './es-timeline-chart.component.html',
    styleUrls: ['./es-timeline-chart.component.less']
})
export class EnterpriseSearchTimelineChartComponent extends EnterpriseSearchComponentBase implements OnInit, OnDestroy, AfterViewInit {
    @ViewChild('chartContainer', { static: true }) chartContainer: ElementRef;
    @ViewChild('chartComponent', { static: false }) chartComponent: any;

    chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
            padding: {
                top: 10,
                bottom: 10,
                left: 10,
                right: 10
            }
        },
        plugins: {
            legend: {
                display: false,
                labels: {
                    font: {
                        size: 10 // Smaller font size for the legend
                    }
                }
            },
            tooltip: {
                bodyFont: {
                    size: 10 // Smaller tooltip text
                },
                titleFont: {
                    size: 10
                }
            }
        },
        scales: {
            x: {
                ticks: {
                    font: {
                        size: 10 // Smaller font size for x-axis labels
                    }
                }
            },
            y: {
                ticks: {
                    font: {
                        size: 10 // Smaller font size for y-axis labels
                    }
                },
                beginAtZero: true
            }
        }
    };

    private _timeline: ChartData;
    get timeline(): ChartData {
        return this._timeline;
    }
    set timeline(value: ChartData) {
        this._timeline = value;
    }

    protected readonly destroy$ = new Subject<void>();

    @HostListener('window:resize')
    onResize() {
        this._resizeChart();
    }

    constructor(
        injector: Injector,
    ) {
        super(injector);
    }

    ngOnInit(): void {
        this.enterpriseSearchService.timeLine$
            .pipe(
                takeUntil(this.destroy$), // Automatically unsubscribes when destroy$ emits
                filter((items: TimelineDto[] | null) => !!items)
            )
            .subscribe((timeline: TimelineDto[]) => {
                this.timeline = this.transformData(timeline);
            });
    }

    ngAfterViewInit() {
        // Optional: give a short delay if needed so that the chart is fully rendered
        setTimeout(() => {
            this._resizeChart();
        }, 100);
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    private _resizeChart() {
        if (this.chartComponent && this.chartComponent.chart) {
            // This calls Chart.js resize method on the underlying chart instance
            this.chartComponent.chart.resize();
            this.chartComponent.chart.update();
        }
    }

    private transformData(rawData: TimelineDto[]): ChartData {

        return {
            labels: rawData.map((item: TimelineDto) => item.date.format('DD-MM-YYYY HH:mm')), // Format dates
            datasets: [
                {
                    label: 'Count',
                    data: rawData.map(item => item.items),
                    backgroundColor: '#007ad9'
                }
            ]
        };
    }
}
